# EEMPS — Electronic Examination Management Platform System

A browser-based examination management system for TVTC College, Kamirenda, Luanshya. The application uses Python's standard library and SQLite; no third-party Python packages are required.

## Features in the supplied application

- Role-based dashboards for administrator, examination officer, lecturer, invigilator, and student
- First-run administrator setup, student self-registration, and staff approval
- Academic departments, programmes, sessions, courses, and course registration
- Question bank, exam-paper building and approval, and timetable clash checks
- Timed online exams, answer autosave, automatic submission, and manual essay marking
- Results, moderation/release workflows, appeals, attendance, incidents, notifications
- Analysis, CSV/print reporting, audit logging, and database backups

## Run locally (Windows, macOS, or Linux)

Requires Python 3.8 or newer.

```bash
python eemps.py
```

Open **http://localhost:8000** in your browser. On first run, create the administrator account on the setup screen. The first person to complete setup becomes the sole administrator; keep the credentials safe.

The SQLite database (`eemps.db`) is created automatically beside `eemps.py` unless `EEMPS_DB` is set. Backups are written to `eemps_backups/`.

### Configuration

| Variable | Default | Purpose |
|---|---|---|
| `EEMPS_HOST` | `0.0.0.0` | Interface to bind to |
| `EEMPS_PORT` | `8000` (or hosting platform `PORT`) | HTTP port |
| `EEMPS_DB` | `./eemps.db` | SQLite database file path |
| `EEMPS_NO_BROWSER` | unset | Set to `1` to disable automatic browser launch |

PowerShell example:

```powershell
$env:EEMPS_PORT = "8000"
$env:EEMPS_DB = "$PWD\eemps.db"
python .\eemps.py
```

## Deploy on Render

This repository includes `render.yaml` and a Dockerfile. For a persistent database, deploy using the included Render Blueprint so the SQLite database is stored on a persistent disk.

1. Push this repository to your GitHub account.
2. In Render, choose **New + → Blueprint** and select the repository.
3. Confirm the service and persistent disk settings, then deploy.
4. Open the generated `onrender.com` URL and complete first-run administrator setup.

SQLite is appropriate for a small college deployment with a single app instance. Do not scale this service to multiple instances sharing the same SQLite file.

## Deploy with Docker

```bash
docker build -t eemps .
docker run --rm -p 8000:8000 -e EEMPS_PORT=8000 -v eemps-data:/data -e EEMPS_DB=/data/eemps.db eemps
```

Then open http://localhost:8000.

## GitHub upload

Upload the files in this repository to a new GitHub repository, or push them with:

```bash
git init
git add .
git commit -m "Initial EEMPS repository"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/eemps.git
git push -u origin main
```

## Important deployment/security notes

- The included app is an HTTP application. Put it behind HTTPS using a trusted hosting platform/proxy before real student data is entered.
- Complete a security review before production use, especially for access controls, session cookies, CSRF protection, privacy, backups, and examination integrity.
- First-run setup is intentionally single-admin. Protect access to the public URL during setup so an unintended visitor cannot claim the administrator account.
- Keep database backups encrypted and restrict access to them. Test restoring a backup before relying on it.
- This repository preserves the supplied single-file application. The automated checks validate Python syntax and a basic HTTP response; they do not certify every exam workflow for production use.

## License

No license was supplied with the source. Add a license only after deciding how you want others to use, modify, and redistribute the project.
