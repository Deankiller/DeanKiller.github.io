# Security notes

Please do not use this application with real examination records until it has been reviewed and tested in your deployment environment.

- Restrict public access while completing first-run administrator setup.
- Serve the application over HTTPS through a trusted platform or reverse proxy.
- Keep the SQLite database and backup directory private and backed up.
- Review session-cookie settings, CSRF protection, account recovery, access-control boundaries, and audit logging before production use.
- Report vulnerabilities privately to the repository maintainer rather than publishing student data or exploit details.
