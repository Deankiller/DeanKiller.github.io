#!/usr/bin/env python3

# -*- coding: utf-8 -*-

"""

EEMPS - Electronic Examination Management Platform System

==========================================================

TVTC College, Kamirenda, Luanshya



ONE FILE. NO INSTALLATION. Needs only Python 3.8+ (standard library).



    python eemps.py            ->  then open  http://localhost:8000



* Embedded SQLite database (eemps.db, created automatically) with foreign keys.

* The FIRST person to open the system creates the administrator account.

  Setup then locks permanently (only one administrator exists).

* Self-registration for students (instant) and staff (admin approval).

* Dashboards for: Administrator, Examination Officer, Lecturer, Invigilator, Student.

* Question bank, paper builder, approval, timetable with clash detection,

  timed online exams with auto-save/auto-submit, auto + manual marking,

  moderation, release, appeals, attendance, incidents, notifications,

  analysis dashboard with charts + CSV export + print/PDF, audit log, daily backups.



Options (environment variables): EEMPS_PORT (8000), EEMPS_HOST (0.0.0.0), EEMPS_DB (path)

"""

import csv, hashlib, io, json, os, random, secrets, socket, sqlite3, sys, threading, time, traceback, webbrowser

from datetime import datetime, timedelta

from http.cookies import SimpleCookie

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from urllib.parse import parse_qs, urlparse



HERE = os.path.dirname(os.path.abspath(__file__))

DB_PATH = os.environ.get('EEMPS_DB', os.path.join(HERE, 'eemps.db'))

BACKUP_DIR = os.path.join(os.path.dirname(DB_PATH), 'eemps_backups')

HOST = os.environ.get('EEMPS_HOST', '0.0.0.0')

PORT = int(os.environ.get('EEMPS_PORT', os.environ.get('PORT', '8000')))

SESSION_HOURS = 8

ROLES = ('admin', 'officer', 'lecturer', 'invigilator', 'student')



# ----------------------------------------------------------------------------

# DATABASE

# ----------------------------------------------------------------------------

SCHEMA = """

CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);

CREATE TABLE IF NOT EXISTS departments(id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL);

CREATE TABLE IF NOT EXISTS programmes(

  id INTEGER PRIMARY KEY, department_id INTEGER NOT NULL REFERENCES departments(id),

  code TEXT UNIQUE NOT NULL, name TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS academic_sessions(

  id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL, start_date TEXT, end_date TEXT, is_current INTEGER DEFAULT 0);

CREATE TABLE IF NOT EXISTS users(

  id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL COLLATE NOCASE, full_name TEXT NOT NULL,

  email TEXT, phone TEXT, pw_hash TEXT NOT NULL, salt TEXT NOT NULL,

  role TEXT NOT NULL CHECK(role IN ('admin','officer','lecturer','invigilator','student')),

  status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','pending','disabled')),

  student_no TEXT UNIQUE, programme_id INTEGER REFERENCES programmes(id), year_level INTEGER,

  created_at TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS auth_sessions(

  token TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,

  created_at TEXT, last_seen TEXT);

CREATE TABLE IF NOT EXISTS courses(

  id INTEGER PRIMARY KEY, programme_id INTEGER NOT NULL REFERENCES programmes(id),

  code TEXT UNIQUE NOT NULL, title TEXT NOT NULL, lecturer_id INTEGER REFERENCES users(id), credits REAL DEFAULT 3);

CREATE TABLE IF NOT EXISTS registrations(

  id INTEGER PRIMARY KEY, student_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,

  course_id INTEGER NOT NULL REFERENCES courses(id), session_id INTEGER NOT NULL REFERENCES academic_sessions(id),

  created_at TEXT, UNIQUE(student_id, course_id, session_id));

CREATE TABLE IF NOT EXISTS questions(

  id INTEGER PRIMARY KEY, course_id INTEGER NOT NULL REFERENCES courses(id),

  author_id INTEGER NOT NULL REFERENCES users(id), topic TEXT,

  qtype TEXT NOT NULL CHECK(qtype IN ('mcq','tf','fill','essay')), text TEXT NOT NULL,

  options TEXT, answer TEXT, marks REAL NOT NULL DEFAULT 1,

  difficulty TEXT DEFAULT 'medium' CHECK(difficulty IN ('easy','medium','hard')), created_at TEXT);

CREATE TABLE IF NOT EXISTS exams(

  id INTEGER PRIMARY KEY, course_id INTEGER NOT NULL REFERENCES courses(id),

  session_id INTEGER NOT NULL REFERENCES academic_sessions(id), title TEXT NOT NULL, instructions TEXT,

  duration_min INTEGER NOT NULL, pass_pct REAL NOT NULL DEFAULT 40, shuffle INTEGER DEFAULT 1,

  status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft','pending','approved','rejected')),

  review_note TEXT, created_by INTEGER NOT NULL REFERENCES users(id), approved_by INTEGER REFERENCES users(id),

  created_at TEXT);

CREATE TABLE IF NOT EXISTS exam_questions(

  id INTEGER PRIMARY KEY, exam_id INTEGER NOT NULL REFERENCES exams(id) ON DELETE CASCADE,

  question_id INTEGER NOT NULL REFERENCES questions(id), marks REAL NOT NULL, ord INTEGER DEFAULT 0,

  UNIQUE(exam_id, question_id));

CREATE TABLE IF NOT EXISTS venues(id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL, capacity INTEGER NOT NULL);

CREATE TABLE IF NOT EXISTS schedules(

  id INTEGER PRIMARY KEY, exam_id INTEGER UNIQUE NOT NULL REFERENCES exams(id) ON DELETE CASCADE,

  venue_id INTEGER NOT NULL REFERENCES venues(id), invigilator_id INTEGER NOT NULL REFERENCES users(id),

  start_time TEXT NOT NULL, end_time TEXT NOT NULL, created_at TEXT);

CREATE TABLE IF NOT EXISTS attempts(

  id INTEGER PRIMARY KEY, exam_id INTEGER NOT NULL REFERENCES exams(id),

  student_id INTEGER NOT NULL REFERENCES users(id), started_at TEXT, deadline TEXT, submitted_at TEXT,

  status TEXT NOT NULL DEFAULT 'in_progress' CHECK(status IN ('in_progress','submitted')),

  order_json TEXT, sess_token TEXT, leave_count INTEGER DEFAULT 0,

  auto_score REAL DEFAULT 0, manual_score REAL DEFAULT 0, total REAL, max_marks REAL, pct REAL,

  grade TEXT, passed INTEGER, result_state TEXT NOT NULL DEFAULT 'pending'

    CHECK(result_state IN ('pending','marked','approved','released')), released_at TEXT,

  UNIQUE(exam_id, student_id));

CREATE TABLE IF NOT EXISTS answers(

  id INTEGER PRIMARY KEY, attempt_id INTEGER NOT NULL REFERENCES attempts(id) ON DELETE CASCADE,

  question_id INTEGER NOT NULL REFERENCES questions(id), answer TEXT, score REAL, comment TEXT,

  marked INTEGER DEFAULT 0, UNIQUE(attempt_id, question_id));

CREATE TABLE IF NOT EXISTS attendance(

  id INTEGER PRIMARY KEY, exam_id INTEGER NOT NULL REFERENCES exams(id) ON DELETE CASCADE,

  student_id INTEGER NOT NULL REFERENCES users(id), present INTEGER DEFAULT 1,

  marked_by INTEGER REFERENCES users(id), marked_at TEXT, UNIQUE(exam_id, student_id));

CREATE TABLE IF NOT EXISTS incidents(

  id INTEGER PRIMARY KEY, exam_id INTEGER NOT NULL REFERENCES exams(id) ON DELETE CASCADE,

  student_id INTEGER REFERENCES users(id), invigilator_id INTEGER NOT NULL REFERENCES users(id),

  description TEXT NOT NULL, created_at TEXT);

CREATE TABLE IF NOT EXISTS appeals(

  id INTEGER PRIMARY KEY, attempt_id INTEGER NOT NULL REFERENCES attempts(id),

  student_id INTEGER NOT NULL REFERENCES users(id), reason TEXT NOT NULL,

  status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','accepted','rejected')),

  response TEXT, new_total REAL, handled_by INTEGER REFERENCES users(id), created_at TEXT, handled_at TEXT);

CREATE TABLE IF NOT EXISTS notifications(

  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,

  title TEXT NOT NULL, body TEXT, is_read INTEGER DEFAULT 0, created_at TEXT);

CREATE TABLE IF NOT EXISTS grading_scale(

  id INTEGER PRIMARY KEY, grade TEXT UNIQUE NOT NULL, min_pct REAL NOT NULL, remark TEXT);

CREATE TABLE IF NOT EXISTS audit_log(

  id INTEGER PRIMARY KEY, user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,

  action TEXT NOT NULL, detail TEXT, ip TEXT, created_at TEXT);

CREATE INDEX IF NOT EXISTS ix_att_exam ON attempts(exam_id);

CREATE INDEX IF NOT EXISTS ix_att_stu ON attempts(student_id);

CREATE INDEX IF NOT EXISTS ix_ans_att ON answers(attempt_id);

CREATE INDEX IF NOT EXISTS ix_reg_stu ON registrations(student_id);

CREATE INDEX IF NOT EXISTS ix_reg_course ON registrations(course_id, session_id);

CREATE INDEX IF NOT EXISTS ix_sched_time ON schedules(start_time, end_time);

CREATE INDEX IF NOT EXISTS ix_notif_user ON notifications(user_id, is_read);

"""



DEFAULT_GRADES = [('A', 80, 'Distinction'), ('B', 65, 'Merit'), ('C', 50, 'Credit'), ('D', 40, 'Pass'), ('F', 0, 'Fail')]





def db():

    c = sqlite3.connect(DB_PATH, timeout=30)

    c.row_factory = sqlite3.Row

    c.execute('PRAGMA foreign_keys=ON')

    return c





def init_db():

    con = db()

    con.execute('PRAGMA journal_mode=WAL')

    con.executescript(SCHEMA)

    for k, v in (('setup_complete', '0'), ('allow_registration', '1'), ('college_name', 'TVTC College, Kamirenda, Luanshya')):

        con.execute('INSERT OR IGNORE INTO settings VALUES(?,?)', (k, v))

    if not con.execute('SELECT 1 FROM grading_scale').fetchone():

        con.executemany('INSERT INTO grading_scale(grade,min_pct,remark) VALUES(?,?,?)', DEFAULT_GRADES)

    con.commit()

    con.close()





# ----------------------------------------------------------------------------

# HELPERS

# ----------------------------------------------------------------------------

class Err(Exception):

    def __init__(self, msg, code=400):

        super().__init__(msg)

        self.msg, self.code = msg, code





def now(): return datetime.now().strftime('%Y-%m-%d %H:%M:%S')

def rows(con, sql, a=()): return [dict(r) for r in con.execute(sql, a).fetchall()]

def row(con, sql, a=()):

    r = con.execute(sql, a).fetchone()

    return dict(r) if r else None

def val(con, sql, a=(), default=0):

    r = con.execute(sql, a).fetchone()

    return r[0] if r and r[0] is not None else default

def S(d, k, n=500): return str(d.get(k) if d.get(k) is not None else '').strip()[:n]

def I(d, k, default=None):

    try: return int(d.get(k))

    except Exception: return default

def F(d, k, default=None):

    try: return float(d.get(k))

    except Exception: return default





def pdt(s):

    s = str(s).replace('T', ' ')

    for f in ('%Y-%m-%d %H:%M:%S', '%Y-%m-%d %H:%M'):

        try: return datetime.strptime(s[:19] if len(s) > 16 else s[:16], f)

        except ValueError: pass

    raise Err('Invalid date/time')





def norm_dt(s): return pdt(s).strftime('%Y-%m-%d %H:%M')





def get_setting(con, k, default=''):

    r = con.execute('SELECT value FROM settings WHERE key=?', (k,)).fetchone()

    return r[0] if r else default





def set_setting(con, k, v):

    con.execute('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value', (k, str(v)))





def hash_pw(pw, salt=None):

    salt = salt or secrets.token_hex(16)

    return hashlib.pbkdf2_hmac('sha256', pw.encode(), bytes.fromhex(salt), 150000).hex(), salt





def check_pw(pw, h, salt): return secrets.compare_digest(hash_pw(pw, salt)[0], h)





def audit(ctx, action, detail=''):

    ctx.con.execute('INSERT INTO audit_log(user_id,action,detail,ip,created_at) VALUES(?,?,?,?,?)',

                    (ctx.user['id'] if ctx.user else None, action, str(detail)[:500], ctx.ip, now()))





def notify(con, uids, title, body=''):

    t = now()

    con.executemany('INSERT INTO notifications(user_id,title,body,created_at) VALUES(?,?,?,?)',

                    [(u, title[:150], body[:600], t) for u in set(uids)])





def role_ids(con, role): return [r[0] for r in con.execute("SELECT id FROM users WHERE role=? AND status='active'", (role,))]





def pub(u):

    return {k: u.get(k) for k in ('id', 'username', 'full_name', 'email', 'phone', 'role', 'status', 'student_no', 'programme_id', 'year_level')} if u else None





def add_user(con, username, full_name, role, pw, status='active', email='', phone='', student_no=None, programme_id=None, year=None):

    h, s = hash_pw(pw)

    cur = con.execute('INSERT INTO users(username,full_name,email,phone,pw_hash,salt,role,status,student_no,programme_id,year_level,created_at)'

                      ' VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',

                      (username, full_name, email, phone, h, s, role, status, student_no, programme_id, year, now()))

    return cur.lastrowid





def grade_for(con, pct):

    r = con.execute('SELECT grade FROM grading_scale WHERE min_pct<=? ORDER BY min_pct DESC LIMIT 1', (pct,)).fetchone()

    return r[0] if r else 'F'





def current_session(con):

    return row(con, 'SELECT * FROM academic_sessions WHERE is_current=1')





def check_password_strength(pw):

    if len(pw) < 8: raise Err('Password must be at least 8 characters')

    if pw.isalpha() or pw.isdigit(): raise Err('Password must mix letters and numbers')





def csv_safe(v):

    v = '' if v is None else v

    if isinstance(v, str) and v[:1] in ('=', '+', '-', '@'): return "'" + v

    return v





# ----------------------------------------------------------------------------

# ROUTING

# ----------------------------------------------------------------------------

ROUTES = {}

FAILS = {}





class Ctx:

    def __init__(self, con, user, ip):

        self.con, self.user, self.ip = con, user, ip

        self.cookie = None

        self.clear_cookie = False





def route(name, roles=None, public=False):

    def deco(f):

        ROUTES[name] = (f, set(roles) if roles else None, public)

        return f

    return deco





# ---- auth -------------------------------------------------------------------

@route('boot', public=True)

def boot(ctx, d):

    con = ctx.con

    u = None

    if ctx.user:

        u = pub(ctx.user)

        u['programme'] = val(con, 'SELECT name FROM programmes WHERE id=?', (ctx.user['programme_id'],), '')

    return {'setup_complete': get_setting(con, 'setup_complete') == '1',

            'college': get_setting(con, 'college_name'),

            'allow_registration': get_setting(con, 'allow_registration') == '1',

            'programmes': rows(con, 'SELECT id,code,name FROM programmes ORDER BY code'), 'user': u}





def start_session(ctx, uid):

    tok = secrets.token_urlsafe(32)

    ctx.con.execute('INSERT INTO auth_sessions VALUES(?,?,?,?)', (tok, uid, now(), now()))

    ctx.cookie = tok





@route('setup', public=True)

def setup(ctx, d):

    con = ctx.con

    name, user, pw = S(d, 'full_name', 100), S(d, 'username', 40), str(d.get('password') or '')

    if not name or not user: raise Err('Full name and username are required')

    check_password_strength(pw)

    # atomic claim: only the very first caller can flip this flag

    cur = con.execute("UPDATE settings SET value='1' WHERE key='setup_complete' AND value='0'")

    if cur.rowcount == 0: raise Err('System is already set up and locked to its administrator.', 403)

    uid = add_user(con, user, name, 'admin', pw, email=S(d, 'email', 120))

    if S(d, 'college', 120): set_setting(con, 'college_name', S(d, 'college', 120))

    ctx.user = {'id': uid}

    audit(ctx, 'SETUP', f'First administrator created: {user}')

    start_session(ctx, uid)

    return {'ok': True}





@route('login', public=True)

def login(ctx, d):

    con = ctx.con

    u, p = S(d, 'username', 60), str(d.get('password') or '')

    key = (ctx.ip, u.lower())

    rec = FAILS.get(key)

    if rec and rec[0] >= 5 and rec[1] > time.time(): raise Err('Too many failed attempts. Try again in 5 minutes.', 429)

    r = row(con, 'SELECT * FROM users WHERE username=?', (u,))

    if not r or not check_pw(p, r['pw_hash'], r['salt']):

        c = (rec[0] if rec and rec[1] > time.time() else 0) + 1

        FAILS[key] = (c, time.time() + 300)

        ctx.user = None

        audit(ctx, 'LOGIN_FAILED', u)

        con.commit()

        raise Err('Invalid username or password', 401)

    if r['status'] == 'pending': raise Err('Your account is waiting for administrator approval.', 403)

    if r['status'] == 'disabled': raise Err('This account has been disabled. Contact the administrator.', 403)

    FAILS.pop(key, None)

    ctx.user = r

    start_session(ctx, r['id'])

    audit(ctx, 'LOGIN', u)

    return {'ok': True}





@route('logout', public=True)

def logout(ctx, d):

    if ctx.user:

        ctx.con.execute('DELETE FROM auth_sessions WHERE token=?', (ctx.user['_token'],))

        audit(ctx, 'LOGOUT')

    ctx.clear_cookie = True

    return {'ok': True}





@route('register', public=True)

def register(ctx, d):

    con = ctx.con

    if get_setting(con, 'setup_complete') != '1': raise Err('System not set up yet')

    if get_setting(con, 'allow_registration') != '1': raise Err('Registration is currently closed', 403)

    role = S(d, 'role')

    if role not in ('student', 'lecturer', 'invigilator', 'officer'): raise Err('Choose a valid role')

    name, user, pw = S(d, 'full_name', 100), S(d, 'username', 40), str(d.get('password') or '')

    if not name or not user: raise Err('Full name and username are required')

    if not user.replace('.', '').replace('_', '').replace('-', '').isalnum(): raise Err('Username may contain letters, numbers, . _ - only')

    check_password_strength(pw)

    sno = prog = yr = None

    if role == 'student':

        sno, prog, yr = S(d, 'student_no', 30), I(d, 'programme_id'), I(d, 'year_level', 1)

        if not sno or not prog: raise Err('Student number and programme are required')

    status = 'active' if role == 'student' else 'pending'

    uid = add_user(con, user, name, role, pw, status, S(d, 'email', 120), S(d, 'phone', 30), sno, prog, yr)

    ctx.user = {'id': uid}

    audit(ctx, 'REGISTER', f'{user} as {role} ({status})')

    if status == 'pending': notify(con, role_ids(con, 'admin'), 'New account awaiting approval', f'{name} registered as {role}.')

    return {'ok': True, 'status': status}





@route('change_password')

def change_password(ctx, d):

    u = ctx.user

    if not check_pw(str(d.get('old') or ''), u['pw_hash'], u['salt']): raise Err('Current password is incorrect')

    new = str(d.get('new') or '')

    check_password_strength(new)

    h, s = hash_pw(new)

    ctx.con.execute('UPDATE users SET pw_hash=?, salt=? WHERE id=?', (h, s, u['id']))

    ctx.con.execute('DELETE FROM auth_sessions WHERE user_id=? AND token!=?', (u['id'], u['_token']))

    audit(ctx, 'PASSWORD_CHANGED')

    return {'ok': True}





@route('update_profile')

def update_profile(ctx, d):

    ctx.con.execute('UPDATE users SET full_name=?, email=?, phone=? WHERE id=?',

                    (S(d, 'full_name', 100) or ctx.user['full_name'], S(d, 'email', 120), S(d, 'phone', 30), ctx.user['id']))

    audit(ctx, 'PROFILE_UPDATED')

    return {'ok': True}





# ---- users (admin) ----------------------------------------------------------

@route('users_list', roles={'admin'})

def users_list(ctx, d):

    return {'rows': rows(ctx.con, "SELECT u.id,u.username,u.full_name,u.email,u.phone,u.role,u.status,u.student_no,u.programme_id,u.year_level,u.created_at,p.code programme "

                                  "FROM users u LEFT JOIN programmes p ON p.id=u.programme_id ORDER BY (u.status='pending') DESC, u.role, u.full_name")}





@route('user_create', roles={'admin'})

def user_create(ctx, d):

    role = S(d, 'role')

    if role not in ROLES or role == 'admin': raise Err('The system has a single administrator; choose another role')

    name, user, pw = S(d, 'full_name', 100), S(d, 'username', 40), str(d.get('password') or '')

    if not name or not user: raise Err('Full name and username are required')

    check_password_strength(pw)

    sno = S(d, 'student_no', 30) or None if role == 'student' else None

    if role == 'student' and (not sno or not I(d, 'programme_id')): raise Err('Student number and programme are required')

    uid = add_user(ctx.con, user, name, role, pw, 'active', S(d, 'email', 120), S(d, 'phone', 30), sno,

                   I(d, 'programme_id') if role == 'student' else None, I(d, 'year_level', 1) if role == 'student' else None)

    audit(ctx, 'USER_CREATED', f'{user} ({role})')

    return {'id': uid}





def target_user(ctx, d):

    u = row(ctx.con, 'SELECT * FROM users WHERE id=?', (I(d, 'id'),))

    if not u: raise Err('User not found', 404)

    if u['role'] == 'admin': raise Err('The administrator account cannot be modified here', 403)

    return u





@route('user_status', roles={'admin'})

def user_status(ctx, d):

    u, st = target_user(ctx, d), S(d, 'status')

    if st not in ('active', 'disabled'): raise Err('Invalid status')

    ctx.con.execute('UPDATE users SET status=? WHERE id=?', (st, u['id']))

    if st == 'disabled': ctx.con.execute('DELETE FROM auth_sessions WHERE user_id=?', (u['id'],))

    if u['status'] == 'pending' and st == 'active': notify(ctx.con, [u['id']], 'Account approved', 'You can now sign in to EEMPS.')

    audit(ctx, 'USER_STATUS', f"{u['username']} -> {st}")

    return {'ok': True}





@route('user_reset_pw', roles={'admin'})

def user_reset_pw(ctx, d):

    u = target_user(ctx, d)

    pw = str(d.get('password') or '')

    check_password_strength(pw)

    h, s = hash_pw(pw)

    ctx.con.execute('UPDATE users SET pw_hash=?, salt=? WHERE id=?', (h, s, u['id']))

    ctx.con.execute('DELETE FROM auth_sessions WHERE user_id=?', (u['id'],))

    audit(ctx, 'PASSWORD_RESET', u['username'])

    return {'ok': True}





@route('user_delete', roles={'admin'})

def user_delete(ctx, d):

    u = target_user(ctx, d)

    ctx.con.execute('DELETE FROM users WHERE id=?', (u['id'],))

    audit(ctx, 'USER_DELETED', u['username'])

    return {'ok': True}





# ---- academic structure -----------------------------------------------------

LISTS = {

    'departments': ('SELECT * FROM departments ORDER BY name', None),

    'programmes': ('SELECT p.*, d.name department FROM programmes p JOIN departments d ON d.id=p.department_id ORDER BY p.code', None),

    'sessions': ('SELECT * FROM academic_sessions ORDER BY is_current DESC, id DESC', None),

    'courses': ('SELECT c.*, p.name programme, p.code pcode, u.full_name lecturer FROM courses c JOIN programmes p ON p.id=c.programme_id '

                'LEFT JOIN users u ON u.id=c.lecturer_id ORDER BY c.code', None),

    'venues': ('SELECT * FROM venues ORDER BY name', None),

    'grades': ('SELECT * FROM grading_scale ORDER BY min_pct DESC', None),

    'lecturers': ("SELECT id, full_name FROM users WHERE role='lecturer' AND status='active' ORDER BY full_name", {'admin', 'officer'}),

    'invigilators': ("SELECT id, full_name FROM users WHERE role='invigilator' AND status='active' ORDER BY full_name", {'admin', 'officer'}),

}

SIMPLE = {

    'departments': ('departments', [('name', 's', 1)], {'admin'}),

    'programmes': ('programmes', [('department_id', 'i', 1), ('code', 's', 1), ('name', 's', 1)], {'admin'}),

    'sessions': ('academic_sessions', [('name', 's', 1), ('start_date', 's', 0), ('end_date', 's', 0)], {'admin'}),

    'courses': ('courses', [('programme_id', 'i', 1), ('code', 's', 1), ('title', 's', 1), ('lecturer_id', 'i', 0), ('credits', 'f', 0)], {'admin'}),

    'venues': ('venues', [('name', 's', 1), ('capacity', 'i', 1)], {'admin', 'officer'}),

    'grades': ('grading_scale', [('grade', 's', 1), ('min_pct', 'f', 1), ('remark', 's', 0)], {'admin'}),

}





@route('list')

def list_(ctx, d):

    e = S(d, 'e')

    if e not in LISTS: raise Err('Unknown list')

    sql, roles = LISTS[e]

    if roles and ctx.user['role'] not in roles: raise Err('Not allowed', 403)

    return {'rows': rows(ctx.con, sql)}





@route('ent_save')

def ent_save(ctx, d):

    e = S(d, 'e')

    if e not in SIMPLE: raise Err('Unknown record type')

    table, fields, roles = SIMPLE[e]

    if ctx.user['role'] not in roles: raise Err('Not allowed', 403)

    vals = {}

    for f, t, req in fields:

        if t == 's': v = S(d, f, 200)

        elif t == 'i': v = I(d, f)

        else: v = F(d, f)

        if v in ('', None):

            if req: raise Err(f"{f.replace('_', ' ').capitalize()} is required")

            v = None

        if f in ('code',) and v: v = v.upper()

        vals[f] = v

    if e == 'grades' and not (0 <= vals['min_pct'] <= 100): raise Err('Minimum % must be between 0 and 100')

    if e == 'venues' and vals['capacity'] < 1: raise Err('Capacity must be at least 1')

    if e == 'courses' and vals.get('lecturer_id') and not val(ctx.con, "SELECT 1 FROM users WHERE id=? AND role='lecturer'", (vals['lecturer_id'],), 0):

        raise Err('Selected lecturer is invalid')

    rid = I(d, 'id')

    cols = list(vals)

    if rid:

        ctx.con.execute(f"UPDATE {table} SET {','.join(c + '=?' for c in cols)} WHERE id=?", [vals[c] for c in cols] + [rid])

    else:

        cur = ctx.con.execute(f"INSERT INTO {table}({','.join(cols)}) VALUES({','.join('?' * len(cols))})", [vals[c] for c in cols])

        rid = cur.lastrowid

        if e == 'sessions' and not current_session(ctx.con): ctx.con.execute('UPDATE academic_sessions SET is_current=1 WHERE id=?', (rid,))

    audit(ctx, 'SAVE_' + e.upper(), json.dumps(vals)[:300])

    return {'id': rid}





@route('ent_delete')

def ent_delete(ctx, d):

    e = S(d, 'e')

    if e not in SIMPLE: raise Err('Unknown record type')

    table, _, roles = SIMPLE[e]

    if ctx.user['role'] not in roles: raise Err('Not allowed', 403)

    ctx.con.execute(f'DELETE FROM {table} WHERE id=?', (I(d, 'id'),))

    audit(ctx, 'DELETE_' + e.upper(), d.get('id'))

    return {'ok': True}





@route('session_current', roles={'admin'})

def session_current(ctx, d):

    ctx.con.execute('UPDATE academic_sessions SET is_current=0')

    ctx.con.execute('UPDATE academic_sessions SET is_current=1 WHERE id=?', (I(d, 'id'),))

    audit(ctx, 'CURRENT_SESSION', d.get('id'))

    return {'ok': True}





# ---- student course registration ---------------------------------------------

@route('reg_options', roles={'student'})

def reg_options(ctx, d):

    con, u = ctx.con, ctx.user

    sess = current_session(con)

    if not sess: raise Err('No current academic session has been set yet')

    if not u['programme_id']: raise Err('Your account has no programme')

    cs = rows(con, 'SELECT c.id,c.code,c.title,c.credits,us.full_name lecturer,'

                   '(SELECT 1 FROM registrations r WHERE r.student_id=? AND r.course_id=c.id AND r.session_id=?) registered '

                   'FROM courses c LEFT JOIN users us ON us.id=c.lecturer_id WHERE c.programme_id=? ORDER BY c.code',

              (u['id'], sess['id'], u['programme_id']))

    return {'session': sess, 'courses': cs}





@route('reg_toggle', roles={'student'})

def reg_toggle(ctx, d):

    con, u = ctx.con, ctx.user

    sess = current_session(con)

    cid = I(d, 'course_id')

    if not sess: raise Err('No current academic session')

    c = row(con, 'SELECT * FROM courses WHERE id=?', (cid,))

    if not c or c['programme_id'] != u['programme_id']: raise Err('You are not eligible for this course')

    if d.get('register'):

        con.execute('INSERT OR IGNORE INTO registrations(student_id,course_id,session_id,created_at) VALUES(?,?,?,?)', (u['id'], cid, sess['id'], now()))

        audit(ctx, 'COURSE_REGISTER', c['code'])

    else:

        if val(con, 'SELECT COUNT(*) FROM attempts a JOIN exams e ON e.id=a.exam_id WHERE a.student_id=? AND e.course_id=? AND e.session_id=?', (u['id'], cid, sess['id'])):

            raise Err('You already sat an exam for this course and cannot unregister')

        con.execute('DELETE FROM registrations WHERE student_id=? AND course_id=? AND session_id=?', (u['id'], cid, sess['id']))

        audit(ctx, 'COURSE_UNREGISTER', c['code'])

    return {'ok': True}





# ---- question bank (lecturer) ------------------------------------------------

def own_course(ctx, cid):

    c = row(ctx.con, 'SELECT * FROM courses WHERE id=? AND lecturer_id=?', (cid, ctx.user['id']))

    if not c: raise Err('You can only work with courses assigned to you', 403)

    return c





def qout(r):

    r = dict(r)

    try: r['options'] = json.loads(r['options']) if r.get('options') else []

    except Exception: r['options'] = []

    return r





@route('my_courses', roles={'lecturer'})

def my_courses(ctx, d):

    return {'rows': rows(ctx.con, 'SELECT c.*, p.code pcode, (SELECT COUNT(*) FROM questions q WHERE q.course_id=c.id) nq, '

                                  '(SELECT COUNT(*) FROM registrations r JOIN academic_sessions s ON s.id=r.session_id AND s.is_current=1 WHERE r.course_id=c.id) nstudents '

                                  'FROM courses c JOIN programmes p ON p.id=c.programme_id WHERE c.lecturer_id=? ORDER BY c.code', (ctx.user['id'],))}





@route('q_list', roles={'lecturer'})

def q_list(ctx, d):

    sql = ('SELECT q.*, c.code FROM questions q JOIN courses c ON c.id=q.course_id WHERE c.lecturer_id=?')

    a = [ctx.user['id']]

    if I(d, 'course_id'): sql += ' AND q.course_id=?'; a.append(I(d, 'course_id'))

    return {'rows': [qout(r) for r in ctx.con.execute(sql + ' ORDER BY q.id DESC', a)]}





@route('q_save', roles={'lecturer'})

def q_save(ctx, d):

    con = ctx.con

    own_course(ctx, I(d, 'course_id'))

    qt, text = S(d, 'qtype'), S(d, 'text', 3000)

    if qt not in ('mcq', 'tf', 'fill', 'essay'): raise Err('Invalid question type')

    if not text: raise Err('Question text is required')

    marks = F(d, 'marks', 1)

    if not marks or marks <= 0: raise Err('Marks must be greater than zero')

    diff = S(d, 'difficulty') if S(d, 'difficulty') in ('easy', 'medium', 'hard') else 'medium'

    opts, ans = [], S(d, 'answer', 1000)

    if qt == 'mcq':

        opts = [str(o).strip()[:300] for o in (d.get('options') or [])]

        if len([o for o in opts if o]) < 2: raise Err('Provide at least two options')

        if not ans.isdigit() or int(ans) >= len(opts) or not opts[int(ans)]: raise Err('Select the correct option')

    elif qt == 'tf':

        if ans not in ('True', 'False'): raise Err('Select True or False')

    elif qt == 'fill':

        if not ans: raise Err('Provide the accepted answer(s), separated by |')

    qid = I(d, 'id')

    if qid:

        old = row(con, 'SELECT q.* FROM questions q JOIN courses c ON c.id=q.course_id WHERE q.id=? AND c.lecturer_id=?', (qid, ctx.user['id']))

        if not old: raise Err('Question not found', 404)

        if val(con, 'SELECT COUNT(*) FROM exam_questions eq JOIN attempts a ON a.exam_id=eq.exam_id WHERE eq.question_id=?', (qid,)):

            raise Err('This question was already used in a sat exam and can no longer be edited')

        con.execute('UPDATE questions SET course_id=?,topic=?,qtype=?,text=?,options=?,answer=?,marks=?,difficulty=? WHERE id=?',

                    (I(d, 'course_id'), S(d, 'topic', 100), qt, text, json.dumps(opts), ans, marks, diff, qid))

    else:

        qid = con.execute('INSERT INTO questions(course_id,author_id,topic,qtype,text,options,answer,marks,difficulty,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)',

                          (I(d, 'course_id'), ctx.user['id'], S(d, 'topic', 100), qt, text, json.dumps(opts), ans, marks, diff, now())).lastrowid

    audit(ctx, 'QUESTION_SAVED', qid)

    return {'id': qid}





@route('q_delete', roles={'lecturer'})

def q_delete(ctx, d):

    q = row(ctx.con, 'SELECT q.id FROM questions q JOIN courses c ON c.id=q.course_id WHERE q.id=? AND c.lecturer_id=?', (I(d, 'id'), ctx.user['id']))

    if not q: raise Err('Question not found', 404)

    ctx.con.execute('DELETE FROM questions WHERE id=?', (q['id'],))

    audit(ctx, 'QUESTION_DELETED', q['id'])

    return {'ok': True}





# ---- exams -------------------------------------------------------------------

EXAM_SQL = ("SELECT e.*, c.code, c.title ctitle, c.lecturer_id, u.full_name lecturer, ss.name session, "

            "(SELECT COUNT(*) FROM exam_questions q WHERE q.exam_id=e.id) nq, "

            "(SELECT COALESCE(SUM(marks),0) FROM exam_questions q WHERE q.exam_id=e.id) total_marks, "

            "(SELECT COUNT(*) FROM attempts a WHERE a.exam_id=e.id) nattempts, sc.id sid, sc.start_time, sc.end_time "

            "FROM exams e JOIN courses c ON c.id=e.course_id LEFT JOIN users u ON u.id=c.lecturer_id "

            "JOIN academic_sessions ss ON ss.id=e.session_id LEFT JOIN schedules sc ON sc.exam_id=e.id")





@route('exam_list', roles={'lecturer', 'officer', 'admin'})

def exam_list(ctx, d):

    if ctx.user['role'] == 'lecturer':

        return {'rows': rows(ctx.con, EXAM_SQL + ' WHERE c.lecturer_id=? ORDER BY e.id DESC', (ctx.user['id'],))}

    return {'rows': rows(ctx.con, EXAM_SQL + ' ORDER BY e.id DESC')}





def exam_access(ctx, eid, owner_only=False):

    ex = row(ctx.con, 'SELECT e.*, c.lecturer_id, c.code FROM exams e JOIN courses c ON c.id=e.course_id WHERE e.id=?', (eid,))

    if not ex: raise Err('Exam not found', 404)

    if ctx.user['role'] == 'lecturer' and ex['lecturer_id'] != ctx.user['id']: raise Err('Not your exam', 403)

    if owner_only and ctx.user['role'] != 'lecturer': raise Err('Only the course lecturer can do this', 403)

    return ex





@route('exam_save', roles={'lecturer'})

def exam_save(ctx, d):

    con = ctx.con

    own_course(ctx, I(d, 'course_id'))

    title = S(d, 'title', 150)

    dur, pas = I(d, 'duration_min'), F(d, 'pass_pct', 40)

    if not title: raise Err('Title is required')

    if not dur or not (5 <= dur <= 480): raise Err('Duration must be between 5 and 480 minutes')

    if pas is None or not (0 <= pas <= 100): raise Err('Pass mark must be between 0 and 100')

    if not val(con, 'SELECT 1 FROM academic_sessions WHERE id=?', (I(d, 'session_id'),), 0): raise Err('Choose an academic session')

    eid = I(d, 'id')

    shuffle = 1 if str(d.get('shuffle', '1')) in ('1', 'true', 'on', 'True') else 0

    if eid:

        ex = exam_access(ctx, eid, True)

        if ex['status'] not in ('draft', 'rejected'): raise Err('Only draft or rejected papers can be edited')

        con.execute('UPDATE exams SET course_id=?,session_id=?,title=?,instructions=?,duration_min=?,pass_pct=?,shuffle=? WHERE id=?',

                    (I(d, 'course_id'), I(d, 'session_id'), title, S(d, 'instructions', 2000), dur, pas, shuffle, eid))

    else:

        eid = con.execute('INSERT INTO exams(course_id,session_id,title,instructions,duration_min,pass_pct,shuffle,created_by,created_at) VALUES(?,?,?,?,?,?,?,?,?)',

                          (I(d, 'course_id'), I(d, 'session_id'), title, S(d, 'instructions', 2000), dur, pas, shuffle, ctx.user['id'], now())).lastrowid

    audit(ctx, 'EXAM_SAVED', f'{eid} {title}')

    return {'id': eid}





@route('exam_delete', roles={'lecturer'})

def exam_delete(ctx, d):

    ex = exam_access(ctx, I(d, 'id'), True)

    if ex['status'] not in ('draft', 'rejected'): raise Err('Only draft or rejected papers can be deleted')

    ctx.con.execute('DELETE FROM exams WHERE id=?', (ex['id'],))

    audit(ctx, 'EXAM_DELETED', ex['title'])

    return {'ok': True}





@route('exam_paper', roles={'lecturer', 'officer', 'admin'})

def exam_paper(ctx, d):

    con = ctx.con

    ex = exam_access(ctx, I(d, 'exam_id'))

    paper = [qout(r) for r in con.execute('SELECT q.id,q.qtype,q.text,q.options,q.answer,q.topic,q.difficulty,eq.marks FROM exam_questions eq '

                                          'JOIN questions q ON q.id=eq.question_id WHERE eq.exam_id=? ORDER BY eq.ord', (ex['id'],))]

    bank = []

    if ctx.user['role'] == 'lecturer':

        bank = [qout(r) for r in con.execute('SELECT * FROM questions WHERE course_id=? AND id NOT IN (SELECT question_id FROM exam_questions WHERE exam_id=?) ORDER BY id DESC',

                                             (ex['course_id'], ex['id']))]

    ex = row(con, EXAM_SQL + ' WHERE e.id=?', (ex['id'],))

    return {'exam': ex, 'paper': paper, 'bank': bank}





@route('exam_set_questions', roles={'lecturer'})

def exam_set_questions(ctx, d):

    con = ctx.con

    ex = exam_access(ctx, I(d, 'exam_id'), True)

    if ex['status'] not in ('draft', 'rejected'): raise Err('Paper is locked (already submitted/approved)')

    items = d.get('items') or []

    seen = set()

    con.execute('DELETE FROM exam_questions WHERE exam_id=?', (ex['id'],))

    for i, it in enumerate(items):

        qid, m = I(it, 'question_id'), F(it, 'marks')

        if qid in seen: continue

        seen.add(qid)

        if not m or m <= 0: raise Err('Every question needs marks greater than zero')

        if not val(con, 'SELECT 1 FROM questions WHERE id=? AND course_id=?', (qid, ex['course_id']), 0): raise Err('A selected question is not from this course')

        con.execute('INSERT INTO exam_questions(exam_id,question_id,marks,ord) VALUES(?,?,?,?)', (ex['id'], qid, m, i))

    audit(ctx, 'PAPER_BUILT', f"{ex['id']} ({len(seen)} questions)")

    return {'ok': True}





@route('exam_submit', roles={'lecturer'})

def exam_submit(ctx, d):

    con = ctx.con

    ex = exam_access(ctx, I(d, 'id'), True)

    if ex['status'] not in ('draft', 'rejected'): raise Err('Paper already submitted')

    if not val(con, 'SELECT COUNT(*) FROM exam_questions WHERE exam_id=?', (ex['id'],)): raise Err('Add questions to the paper first')

    con.execute("UPDATE exams SET status='pending', review_note=NULL WHERE id=?", (ex['id'],))

    notify(con, role_ids(con, 'officer'), 'Exam paper awaiting approval', f"{ex['title']} ({ex['code']}) was submitted for approval.")

    audit(ctx, 'EXAM_SUBMITTED', ex['title'])

    return {'ok': True}





@route('exam_review', roles={'officer'})

def exam_review(ctx, d):

    con = ctx.con

    ex = row(con, 'SELECT e.*, c.lecturer_id FROM exams e JOIN courses c ON c.id=e.course_id WHERE e.id=?', (I(d, 'id'),))

    if not ex: raise Err('Exam not found', 404)

    if ex['status'] != 'pending': raise Err('This paper is not awaiting review')

    ok = S(d, 'decision') == 'approve'

    note = S(d, 'note', 500)

    if not ok and not note: raise Err('Please give a reason when rejecting a paper')

    con.execute('UPDATE exams SET status=?, review_note=?, approved_by=? WHERE id=?', ('approved' if ok else 'rejected', note, ctx.user['id'] if ok else None, ex['id']))

    if ex['lecturer_id']:

        notify(con, [ex['lecturer_id']], f"Paper {'approved' if ok else 'rejected'}: {ex['title']}", note)

    audit(ctx, 'EXAM_APPROVED' if ok else 'EXAM_REJECTED', ex['title'])

    return {'ok': True}





# ---- timetable ---------------------------------------------------------------

SCHED_COLS = ("s.id sid, s.exam_id, s.start_time, s.end_time, s.venue_id, s.invigilator_id, v.name venue, v.capacity, u.full_name invigilator, "

              "e.title, e.instructions, e.duration_min, c.code, c.title ctitle, c.programme_id, c.lecturer_id, p.code programme, "

              "(SELECT COUNT(*) FROM registrations r WHERE r.course_id=c.id AND r.session_id=e.session_id) registered")

SCHED_FROM = ("FROM schedules s JOIN exams e ON e.id=s.exam_id JOIN courses c ON c.id=e.course_id JOIN programmes p ON p.id=c.programme_id "

              "JOIN venues v ON v.id=s.venue_id JOIN users u ON u.id=s.invigilator_id")





def exam_state(r, t):

    if r.get('astatus') == 'submitted': return 'submitted'

    if r.get('astatus') == 'in_progress': return 'in_progress'

    return 'upcoming' if t < pdt(r['start_time']) else ('open' if t <= pdt(r['end_time']) else 'missed')





def student_exams(con, uid):

    t = datetime.now()

    out = rows(con, f"SELECT {SCHED_COLS}, a.id attempt_id, a.status astatus FROM schedules s JOIN exams e ON e.id=s.exam_id "

                    f"JOIN courses c ON c.id=e.course_id JOIN programmes p ON p.id=c.programme_id JOIN venues v ON v.id=s.venue_id "

                    f"JOIN users u ON u.id=s.invigilator_id JOIN registrations rg ON rg.course_id=c.id AND rg.session_id=e.session_id AND rg.student_id=? "

                    f"LEFT JOIN attempts a ON a.exam_id=e.id AND a.student_id=rg.student_id WHERE e.status='approved' ORDER BY s.start_time", (uid,))

    for r in out: r['state'] = exam_state(r, t)

    return out





@route('timetable')

def timetable(ctx, d):

    con, u = ctx.con, ctx.user

    if u['role'] == 'student': return {'rows': student_exams(con, u['id'])}

    sql, a = f'SELECT {SCHED_COLS} {SCHED_FROM}', []

    if u['role'] == 'lecturer': sql += ' WHERE c.lecturer_id=?'; a.append(u['id'])

    elif u['role'] == 'invigilator': sql += ' WHERE s.invigilator_id=?'; a.append(u['id'])

    out = rows(con, sql + ' ORDER BY s.start_time', a)

    t = datetime.now()

    for r in out: r['state'] = exam_state(r, t)

    return {'rows': out}





@route('schedule_save', roles={'officer'})

def schedule_save(ctx, d):

    con = ctx.con

    ex = row(con, 'SELECT e.*, c.programme_id, c.code FROM exams e JOIN courses c ON c.id=e.course_id WHERE e.id=?', (I(d, 'exam_id'),))

    if not ex: raise Err('Choose an exam')

    if ex['status'] != 'approved': raise Err('Only approved papers can be scheduled')

    vid, iid = I(d, 'venue_id'), I(d, 'invigilator_id')

    v = row(con, 'SELECT * FROM venues WHERE id=?', (vid,))

    if not v or not val(con, "SELECT 1 FROM users WHERE id=? AND role='invigilator' AND status='active'", (iid,), 0): raise Err('Choose a venue and an invigilator')

    st, en = norm_dt(d.get('start_time')), norm_dt(d.get('end_time'))

    if en <= st: raise Err('End time must be after the start time')

    if (pdt(en) - pdt(st)).total_seconds() / 60 < ex['duration_min']: raise Err(f"The window must be at least as long as the exam duration ({ex['duration_min']} min)")

    if pdt(en) < datetime.now(): raise Err('The exam window is already in the past')

    if val(con, 'SELECT COUNT(*) FROM attempts WHERE exam_id=?', (ex['id'],)): raise Err('Students have already started this exam; it cannot be rescheduled')

    reg = val(con, 'SELECT COUNT(*) FROM registrations WHERE course_id=? AND session_id=?', (ex['course_id'], ex['session_id']))

    if reg > v['capacity']: raise Err(f"Venue capacity ({v['capacity']}) is smaller than registered students ({reg})")

    ov = 'AND s.start_time<? AND s.end_time>? AND s.exam_id!=?'

    base = f'SELECT e.title, c.code FROM schedules s JOIN exams e ON e.id=s.exam_id JOIN courses c ON c.id=e.course_id WHERE '

    c1 = row(con, base + f's.venue_id=? {ov}', (vid, en, st, ex['id']))

    if c1: raise Err(f"Clash: venue already booked for {c1['code']} - {c1['title']} at that time")

    c2 = row(con, base + f's.invigilator_id=? {ov}', (iid, en, st, ex['id']))

    if c2: raise Err(f"Clash: invigilator already assigned to {c2['code']} - {c2['title']} at that time")

    c3 = row(con, base + f'c.programme_id=? {ov}', (ex['programme_id'], en, st, ex['id']))

    if c3: raise Err(f"Clash: students of this programme already have {c3['code']} - {c3['title']} at that time")

    old = row(con, 'SELECT id FROM schedules WHERE exam_id=?', (ex['id'],))

    if old: con.execute('UPDATE schedules SET venue_id=?,invigilator_id=?,start_time=?,end_time=? WHERE id=?', (vid, iid, st, en, old['id']))

    else: con.execute('INSERT INTO schedules(exam_id,venue_id,invigilator_id,start_time,end_time,created_at) VALUES(?,?,?,?,?,?)', (ex['id'], vid, iid, st, en, now()))

    studs = [r[0] for r in con.execute('SELECT student_id FROM registrations WHERE course_id=? AND session_id=?', (ex['course_id'], ex['session_id']))]

    msg = f"{ex['code']} - {ex['title']}: {st} to {en}, {v['name']}"

    notify(con, studs, 'Exam timetable published', msg)

    notify(con, [iid], 'Invigilation assignment', msg)

    lec = val(con, 'SELECT lecturer_id FROM courses WHERE id=?', (ex['course_id'],), None)

    if lec: notify(con, [lec], 'Your exam has been scheduled', msg)

    audit(ctx, 'SCHEDULE_SAVED', msg)

    return {'ok': True}





@route('schedule_delete', roles={'officer'})

def schedule_delete(ctx, d):

    s = row(ctx.con, 'SELECT * FROM schedules WHERE id=?', (I(d, 'id'),))

    if not s: raise Err('Not found', 404)

    if val(ctx.con, 'SELECT COUNT(*) FROM attempts WHERE exam_id=?', (s['exam_id'],)): raise Err('Students already started this exam')

    ctx.con.execute('DELETE FROM schedules WHERE id=?', (s['id'],))

    audit(ctx, 'SCHEDULE_DELETED', s['exam_id'])

    return {'ok': True}





# ---- taking exams --------------------------------------------------------------

def check_answer(q, given):

    g = (given or '').strip().lower()

    if not g: return False

    if q['qtype'] in ('mcq', 'tf'): return g == str(q['answer']).strip().lower()

    if q['qtype'] == 'fill': return g in [x.strip().lower() for x in str(q['answer']).split('|') if x.strip()]

    return False





def recompute(con, aid):

    a = row(con, 'SELECT a.*, e.pass_pct FROM attempts a JOIN exams e ON e.id=a.exam_id WHERE a.id=?', (aid,))

    if not a or a['status'] != 'submitted': return

    mx = val(con, 'SELECT SUM(marks) FROM exam_questions WHERE exam_id=?', (a['exam_id'],))

    auto = val(con, "SELECT SUM(COALESCE(an.score,0)) FROM answers an JOIN questions q ON q.id=an.question_id WHERE an.attempt_id=? AND q.qtype!='essay'", (aid,))

    man = val(con, "SELECT SUM(COALESCE(an.score,0)) FROM answers an JOIN questions q ON q.id=an.question_id WHERE an.attempt_id=? AND q.qtype='essay'", (aid,))

    unmarked = val(con, 'SELECT COUNT(*) FROM answers WHERE attempt_id=? AND marked=0', (aid,))

    if unmarked == 0:

        total = auto + man

        pct = round(total / mx * 100, 1) if mx else 0

        state = 'marked' if a['result_state'] == 'pending' else a['result_state']

        con.execute('UPDATE attempts SET auto_score=?,manual_score=?,total=?,max_marks=?,pct=?,grade=?,passed=?,result_state=? WHERE id=?',

                    (auto, man, total, mx, pct, grade_for(con, pct), 1 if pct >= a['pass_pct'] else 0, state, aid))

    else:

        con.execute("UPDATE attempts SET auto_score=?,manual_score=?,max_marks=?,total=NULL,pct=NULL,grade=NULL,passed=NULL,result_state='pending' WHERE id=?", (auto, man, mx, aid))





def submit_attempt(con, aid):

    a = row(con, 'SELECT * FROM attempts WHERE id=?', (aid,))

    if not a or a['status'] != 'in_progress': return

    con.execute("UPDATE attempts SET status='submitted', submitted_at=? WHERE id=?", (now(), aid))

    qs = rows(con, 'SELECT eq.question_id, eq.marks, q.qtype, q.answer FROM exam_questions eq JOIN questions q ON q.id=eq.question_id WHERE eq.exam_id=?', (a['exam_id'],))

    for q in qs:

        an = row(con, 'SELECT * FROM answers WHERE attempt_id=? AND question_id=?', (aid, q['question_id']))

        if not an:

            con.execute('INSERT INTO answers(attempt_id,question_id,answer,marked) VALUES(?,?,?,0)', (aid, q['question_id'], ''))

            an = {'answer': ''}

        if q['qtype'] == 'essay':

            if not (an['answer'] or '').strip():

                con.execute('UPDATE answers SET score=0, marked=1 WHERE attempt_id=? AND question_id=?', (aid, q['question_id']))

        else:

            sc = q['marks'] if check_answer(q, an['answer']) else 0

            con.execute('UPDATE answers SET score=?, marked=1 WHERE attempt_id=? AND question_id=?', (sc, aid, q['question_id']))

    recompute(con, aid)

    e = row(con, 'SELECT e.title, c.lecturer_id FROM exams e JOIN courses c ON c.id=e.course_id WHERE e.id=?', (a['exam_id'],))

    if e and e['lecturer_id'] and val(con, "SELECT COUNT(*) FROM answers WHERE attempt_id=? AND marked=0", (aid,)):

        pass  # lecturers see essay answers in their marking queue





def finalize_expired(con):

    limit = (datetime.now() - timedelta(seconds=25)).strftime('%Y-%m-%d %H:%M:%S')

    for r in con.execute("SELECT id FROM attempts WHERE status='in_progress' AND deadline<?", (limit,)).fetchall():

        submit_attempt(con, r[0])





def attempt_payload(con, a):

    ex = row(con, 'SELECT e.id,e.title,e.instructions,e.duration_min,c.code,c.title ctitle FROM exams e JOIN courses c ON c.id=e.course_id WHERE e.id=?', (a['exam_id'],))

    qs = []

    for eqid in json.loads(a['order_json']):

        q = row(con, 'SELECT q.id,q.qtype,q.text,q.options,eq.marks FROM exam_questions eq JOIN questions q ON q.id=eq.question_id WHERE eq.id=?', (eqid,))

        if q: qs.append(qout(q))

    saved = {r['question_id']: r['answer'] for r in con.execute('SELECT question_id, answer FROM answers WHERE attempt_id=?', (a['id'],))}

    return {'attempt_id': a['id'], 'token': a['sess_token'], 'exam': ex, 'questions': qs, 'saved': saved,

            'remaining': max(0, int((pdt(a['deadline']) - datetime.now()).total_seconds()))}





@route('my_exams', roles={'student'})

def my_exams(ctx, d):

    return {'rows': student_exams(ctx.con, ctx.user['id'])}





@route('exam_start', roles={'student'})

def exam_start(ctx, d):

    con, u = ctx.con, ctx.user

    eid = I(d, 'exam_id')

    r = next((x for x in student_exams(con, u['id']) if x['exam_id'] == eid), None)

    if not r: raise Err('You are not registered for this exam, or it is not scheduled', 403)

    a = row(con, 'SELECT * FROM attempts WHERE exam_id=? AND student_id=?', (eid, u['id']))

    tok = secrets.token_hex(12)

    if a:

        if a['status'] == 'submitted': raise Err('You have already submitted this exam')

        con.execute('UPDATE attempts SET sess_token=? WHERE id=?', (tok, a['id']))

        a['sess_token'] = tok

        audit(ctx, 'EXAM_RESUMED', eid)

        return attempt_payload(con, a)

    t = datetime.now()

    if t < pdt(r['start_time']): raise Err('This exam has not started yet')

    if t > pdt(r['end_time']): raise Err('The exam window has closed')

    eqs = rows(con, 'SELECT id FROM exam_questions WHERE exam_id=? ORDER BY ord', (eid,))

    if not eqs: raise Err('This exam has no questions')

    ids = [x['id'] for x in eqs]

    if val(con, 'SELECT shuffle FROM exams WHERE id=?', (eid,)): random.shuffle(ids)

    dl = min(t + timedelta(minutes=r['duration_min']), pdt(r['end_time']))

    aid = con.execute('INSERT INTO attempts(exam_id,student_id,started_at,deadline,order_json,sess_token) VALUES(?,?,?,?,?,?)',

                      (eid, u['id'], now(), dl.strftime('%Y-%m-%d %H:%M:%S'), json.dumps(ids), tok)).lastrowid

    con.execute('INSERT INTO attendance(exam_id,student_id,present,marked_at) VALUES(?,?,1,?) ON CONFLICT(exam_id,student_id) DO UPDATE SET present=1', (eid, u['id'], now()))

    audit(ctx, 'EXAM_STARTED', eid)

    return attempt_payload(con, row(con, 'SELECT * FROM attempts WHERE id=?', (aid,)))





def live_attempt(ctx, d):

    a = row(ctx.con, 'SELECT * FROM attempts WHERE id=? AND student_id=?', (I(d, 'attempt_id'), ctx.user['id']))

    if not a: raise Err('Attempt not found', 404)

    if a['status'] != 'in_progress': raise Err('This exam was already submitted', 409)

    if a['sess_token'] != d.get('token'): raise Err('This exam was opened in another window or device. Only one session is allowed.', 409)

    return a





def save_answers(con, a, answers):

    if datetime.now() > pdt(a['deadline']) + timedelta(seconds=20): return

    valid = {r[0] for r in con.execute('SELECT question_id FROM exam_questions WHERE exam_id=?', (a['exam_id'],))}

    for qid, ans in (answers or {}).items():

        try: qid = int(qid)

        except Exception: continue

        if qid in valid:

            con.execute('INSERT INTO answers(attempt_id,question_id,answer,marked) VALUES(?,?,?,0) ON CONFLICT(attempt_id,question_id) DO UPDATE SET answer=excluded.answer',

                        (a['id'], qid, str(ans)[:20000]))





@route('answer_save', roles={'student'})

def answer_save(ctx, d):

    a = live_attempt(ctx, d)

    save_answers(ctx.con, a, d.get('answers'))

    return {'ok': True, 'remaining': max(0, int((pdt(a['deadline']) - datetime.now()).total_seconds()))}





@route('attempt_event', roles={'student'})

def attempt_event(ctx, d):

    a = live_attempt(ctx, d)

    ctx.con.execute('UPDATE attempts SET leave_count=leave_count+1 WHERE id=?', (a['id'],))

    return {'ok': True}





@route('attempt_submit', roles={'student'})

def attempt_submit(ctx, d):

    a = row(ctx.con, 'SELECT * FROM attempts WHERE id=? AND student_id=?', (I(d, 'attempt_id'), ctx.user['id']))

    if not a: raise Err('Attempt not found', 404)

    if a['status'] == 'submitted': return {'ok': True}

    if a['sess_token'] != d.get('token'): raise Err('This exam is open in another window', 409)

    save_answers(ctx.con, a, d.get('answers'))

    submit_attempt(ctx.con, a['id'])

    audit(ctx, 'EXAM_SUBMITTED_BY_STUDENT', a['exam_id'])

    return {'ok': True}





# ---- marking & results ----------------------------------------------------------

@route('mark_list', roles={'lecturer'})

def mark_list(ctx, d):

    sql = ("SELECT an.id, an.answer, an.score, an.comment, an.marked, q.text qtext, q.answer guide, eq.marks maxm, s.full_name student, s.student_no, "

           "e.id exam_id, e.title exam, c.code, a.result_state FROM answers an JOIN attempts a ON a.id=an.attempt_id JOIN exams e ON e.id=a.exam_id "

           "JOIN courses c ON c.id=e.course_id JOIN questions q ON q.id=an.question_id JOIN exam_questions eq ON eq.exam_id=e.id AND eq.question_id=q.id "

           "JOIN users s ON s.id=a.student_id WHERE q.qtype='essay' AND a.status='submitted' AND TRIM(an.answer)!='' AND c.lecturer_id=?")

    a = [ctx.user['id']]

    if I(d, 'exam_id'): sql += ' AND e.id=?'; a.append(I(d, 'exam_id'))

    if d.get('pending'): sql += ' AND an.marked=0'

    return {'rows': rows(ctx.con, sql + ' ORDER BY e.id DESC, s.full_name LIMIT 300', a)}





@route('mark_save', roles={'lecturer'})

def mark_save(ctx, d):

    con = ctx.con

    r = row(con, "SELECT an.id, an.attempt_id, eq.marks maxm, a.result_state FROM answers an JOIN attempts a ON a.id=an.attempt_id JOIN exams e ON e.id=a.exam_id "

                 "JOIN courses c ON c.id=e.course_id JOIN exam_questions eq ON eq.exam_id=e.id AND eq.question_id=an.question_id "

                 "WHERE an.id=? AND c.lecturer_id=? AND a.status='submitted'", (I(d, 'id'), ctx.user['id']))

    if not r: raise Err('Answer not found', 404)

    if r['result_state'] in ('approved', 'released'): raise Err('Results are already approved; marks are locked. Use the appeals process.')

    sc = F(d, 'score')

    if sc is None or sc < 0 or sc > r['maxm']: raise Err(f"Score must be between 0 and {r['maxm']}")

    con.execute('UPDATE answers SET score=?, comment=?, marked=1 WHERE id=?', (sc, S(d, 'comment', 1000), r['id']))

    recompute(con, r['attempt_id'])

    audit(ctx, 'ANSWER_MARKED', f"{r['id']} = {sc}")

    return {'ok': True}





RES_SQL = ("SELECT a.id, a.exam_id, s.full_name student, s.student_no, p.code programme, c.code, c.title ctitle, e.title exam, a.total, a.max_marks, a.pct, "

           "a.grade, a.passed, a.result_state, a.leave_count, a.submitted_at FROM attempts a JOIN exams e ON e.id=a.exam_id JOIN courses c ON c.id=e.course_id "

           "JOIN users s ON s.id=a.student_id LEFT JOIN programmes p ON p.id=s.programme_id WHERE a.status='submitted'")





@route('result_list', roles={'lecturer', 'officer', 'admin'})

def result_list(ctx, d):

    sql, a = RES_SQL, []

    if ctx.user['role'] == 'lecturer': sql += ' AND c.lecturer_id=?'; a.append(ctx.user['id'])

    if I(d, 'exam_id'): sql += ' AND e.id=?'; a.append(I(d, 'exam_id'))

    return {'rows': rows(ctx.con, sql + ' ORDER BY e.id DESC, s.full_name', a)}





@route('result_approve', roles={'officer'})

def result_approve(ctx, d):

    eid = I(d, 'exam_id')

    cur = ctx.con.execute("UPDATE attempts SET result_state='approved' WHERE exam_id=? AND result_state='marked'", (eid,))

    left = val(ctx.con, "SELECT COUNT(*) FROM attempts WHERE exam_id=? AND status='submitted' AND result_state='pending'", (eid,))

    audit(ctx, 'RESULTS_APPROVED', f'exam {eid}: {cur.rowcount}')

    return {'approved': cur.rowcount, 'still_pending': left}





@route('result_release', roles={'officer'})

def result_release(ctx, d):

    con, eid = ctx.con, I(d, 'exam_id')

    ids = [r[0] for r in con.execute("SELECT student_id FROM attempts WHERE exam_id=? AND result_state='approved'", (eid,))]

    con.execute("UPDATE attempts SET result_state='released', released_at=? WHERE exam_id=? AND result_state='approved'", (now(), eid))

    t = val(con, 'SELECT title FROM exams WHERE id=?', (eid,), '')

    notify(con, ids, 'Results released', f'Your result for "{t}" is now available.')

    audit(ctx, 'RESULTS_RELEASED', f'exam {eid}: {len(ids)}')

    return {'released': len(ids)}





@route('my_results', roles={'student'})

def my_results(ctx, d):

    return {'rows': rows(ctx.con, "SELECT a.id, e.title exam, c.code, c.title ctitle, a.total, a.max_marks, a.pct, a.grade, a.passed, a.released_at, "

                                  "(SELECT status FROM appeals ap WHERE ap.attempt_id=a.id ORDER BY ap.id DESC LIMIT 1) appeal, "

                                  "(SELECT remark FROM grading_scale g WHERE g.grade=a.grade) remark "

                                  "FROM attempts a JOIN exams e ON e.id=a.exam_id JOIN courses c ON c.id=e.course_id "

                                  "WHERE a.student_id=? AND a.result_state='released' ORDER BY a.released_at DESC", (ctx.user['id'],))}





@route('result_detail', roles={'student', 'lecturer', 'officer', 'admin'})

def result_detail(ctx, d):

    con, u = ctx.con, ctx.user

    a = row(con, RES_SQL + ' AND a.id=?', (I(d, 'id'),))

    if not a: raise Err('Not found', 404)

    full = row(con, 'SELECT student_id FROM attempts WHERE id=?', (a['id'],))

    if u['role'] == 'student' and (full['student_id'] != u['id'] or a['result_state'] != 'released'): raise Err('Not allowed', 403)

    if u['role'] == 'lecturer' and not val(con, 'SELECT 1 FROM exams e JOIN courses c ON c.id=e.course_id WHERE e.id=? AND c.lecturer_id=?', (a['exam_id'], u['id']), 0): raise Err('Not allowed', 403)

    items = rows(con, 'SELECT q.text, q.qtype, an.answer, an.score, an.comment, eq.marks FROM answers an JOIN questions q ON q.id=an.question_id '

                      'JOIN exam_questions eq ON eq.exam_id=? AND eq.question_id=q.id WHERE an.attempt_id=? ORDER BY eq.ord', (a['exam_id'], a['id']))

    return {'result': a, 'items': items}





# ---- appeals -----------------------------------------------------------------------

@route('appeal_create', roles={'student'})

def appeal_create(ctx, d):

    con = ctx.con

    a = row(con, "SELECT a.*, c.lecturer_id FROM attempts a JOIN exams e ON e.id=a.exam_id JOIN courses c ON c.id=e.course_id WHERE a.id=? AND a.student_id=? AND a.result_state='released'",

            (I(d, 'attempt_id'), ctx.user['id']))

    if not a: raise Err('Only your released results can be appealed')

    reason = S(d, 'reason', 1000)

    if len(reason) < 10: raise Err('Please explain your appeal (at least 10 characters)')

    if val(con, "SELECT COUNT(*) FROM appeals WHERE attempt_id=? AND status='pending'", (a['id'],)): raise Err('You already have a pending appeal for this result')

    con.execute('INSERT INTO appeals(attempt_id,student_id,reason,created_at) VALUES(?,?,?,?)', (a['id'], ctx.user['id'], reason, now()))

    notify(con, role_ids(con, 'officer') + ([a['lecturer_id']] if a['lecturer_id'] else []), 'New result appeal', f"{ctx.user['full_name']} requested a review.")

    audit(ctx, 'APPEAL_CREATED', a['id'])

    return {'ok': True}





@route('appeal_list', roles={'student', 'officer', 'admin', 'lecturer'})

def appeal_list(ctx, d):

    sql = ("SELECT ap.*, s.full_name student, s.student_no, e.title exam, c.code, a.total, a.max_marks, a.pct, a.grade FROM appeals ap JOIN attempts a ON a.id=ap.attempt_id "

           "JOIN exams e ON e.id=a.exam_id JOIN courses c ON c.id=e.course_id JOIN users s ON s.id=ap.student_id WHERE 1=1")

    a = []

    if ctx.user['role'] == 'student': sql += ' AND ap.student_id=?'; a.append(ctx.user['id'])

    if ctx.user['role'] == 'lecturer': sql += ' AND c.lecturer_id=?'; a.append(ctx.user['id'])

    return {'rows': rows(ctx.con, sql + ' ORDER BY (ap.status=\'pending\') DESC, ap.id DESC', a)}





@route('appeal_handle', roles={'officer'})

def appeal_handle(ctx, d):

    con = ctx.con

    ap = row(con, 'SELECT ap.*, a.max_marks, a.exam_id, e.pass_pct FROM appeals ap JOIN attempts a ON a.id=ap.attempt_id JOIN exams e ON e.id=a.exam_id WHERE ap.id=?', (I(d, 'id'),))

    if not ap or ap['status'] != 'pending': raise Err('Appeal not found or already handled')

    accept = S(d, 'decision') == 'accept'

    resp, nt = S(d, 'response', 1000), F(d, 'new_total')

    if not resp: raise Err('A written response is required')

    if accept and nt is not None:

        if nt < 0 or nt > ap['max_marks']: raise Err(f"New total must be between 0 and {ap['max_marks']}")

        pct = round(nt / ap['max_marks'] * 100, 1) if ap['max_marks'] else 0

        con.execute('UPDATE attempts SET total=?, pct=?, grade=?, passed=? WHERE id=?', (nt, pct, grade_for(con, pct), 1 if pct >= ap['pass_pct'] else 0, ap['attempt_id']))

    con.execute('UPDATE appeals SET status=?, response=?, new_total=?, handled_by=?, handled_at=? WHERE id=?',

                ('accepted' if accept else 'rejected', resp, nt if accept else None, ctx.user['id'], now(), ap['id']))

    notify(con, [ap['student_id']], f"Appeal {'accepted' if accept else 'rejected'}", resp)

    audit(ctx, 'APPEAL_HANDLED', f"{ap['id']} {'accepted' if accept else 'rejected'}")

    return {'ok': True}





# ---- invigilation -----------------------------------------------------------------------

def inv_schedule(ctx, eid):

    s = row(ctx.con, 'SELECT s.*, e.title, e.course_id, e.session_id, e.duration_min FROM schedules s JOIN exams e ON e.id=s.exam_id WHERE s.exam_id=?', (eid,))

    if not s: raise Err('Exam is not scheduled', 404)

    if ctx.user['role'] == 'invigilator' and s['invigilator_id'] != ctx.user['id']: raise Err('You are not assigned to this exam', 403)

    return s





@route('attendance_list', roles={'invigilator', 'officer', 'admin'})

def attendance_list(ctx, d):

    s = inv_schedule(ctx, I(d, 'exam_id'))

    nq = val(ctx.con, 'SELECT COUNT(*) FROM exam_questions WHERE exam_id=?', (s['exam_id'],))

    r = rows(ctx.con, "SELECT u.id student_id, u.full_name, u.student_no, at.present, a.status astatus, a.leave_count, a.deadline, "

                      "(SELECT COUNT(*) FROM answers an WHERE an.attempt_id=a.id AND TRIM(an.answer)!='') answered "

                      "FROM registrations r JOIN users u ON u.id=r.student_id LEFT JOIN attendance at ON at.exam_id=? AND at.student_id=u.id "

                      "LEFT JOIN attempts a ON a.exam_id=? AND a.student_id=u.id WHERE r.course_id=? AND r.session_id=? ORDER BY u.full_name",

             (s['exam_id'], s['exam_id'], s['course_id'], s['session_id']))

    return {'rows': r, 'nq': nq, 'exam': s['title']}





@route('attendance_mark', roles={'invigilator'})

def attendance_mark(ctx, d):

    s = inv_schedule(ctx, I(d, 'exam_id'))

    ctx.con.execute('INSERT INTO attendance(exam_id,student_id,present,marked_by,marked_at) VALUES(?,?,?,?,?) '

                    'ON CONFLICT(exam_id,student_id) DO UPDATE SET present=excluded.present, marked_by=excluded.marked_by, marked_at=excluded.marked_at',

                    (s['exam_id'], I(d, 'student_id'), 1 if d.get('present') else 0, ctx.user['id'], now()))

    audit(ctx, 'ATTENDANCE', f"exam {s['exam_id']} student {d.get('student_id')} present={1 if d.get('present') else 0}")

    return {'ok': True}





@route('incident_save', roles={'invigilator'})

def incident_save(ctx, d):

    s = inv_schedule(ctx, I(d, 'exam_id'))

    desc = S(d, 'description', 1500)

    if len(desc) < 5: raise Err('Describe the incident')

    ctx.con.execute('INSERT INTO incidents(exam_id,student_id,invigilator_id,description,created_at) VALUES(?,?,?,?,?)', (s['exam_id'], I(d, 'student_id'), ctx.user['id'], desc, now()))

    notify(ctx.con, role_ids(ctx.con, 'officer'), 'Exam incident reported', f"{s['title']}: {desc[:150]}")

    audit(ctx, 'INCIDENT', f"exam {s['exam_id']}")

    return {'ok': True}





INC_SQL = ("SELECT i.id, i.created_at, e.title exam, c.code, st.full_name student, st.student_no, iv.full_name invigilator, i.description "

           "FROM incidents i JOIN exams e ON e.id=i.exam_id JOIN courses c ON c.id=e.course_id LEFT JOIN users st ON st.id=i.student_id JOIN users iv ON iv.id=i.invigilator_id")





@route('incident_list', roles={'invigilator', 'officer', 'admin'})

def incident_list(ctx, d):

    if ctx.user['role'] == 'invigilator':

        return {'rows': rows(ctx.con, INC_SQL + ' WHERE i.invigilator_id=? ORDER BY i.id DESC', (ctx.user['id'],))}

    return {'rows': rows(ctx.con, INC_SQL + ' ORDER BY i.id DESC')}





# ---- notifications / announcements ------------------------------------------------------------

@route('notif_list')

def notif_list(ctx, d):

    r = rows(ctx.con, 'SELECT * FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 60', (ctx.user['id'],))

    return {'rows': r, 'unread': val(ctx.con, 'SELECT COUNT(*) FROM notifications WHERE user_id=? AND is_read=0', (ctx.user['id'],))}





@route('notif_read')

def notif_read(ctx, d):

    ctx.con.execute('UPDATE notifications SET is_read=1 WHERE user_id=?', (ctx.user['id'],))

    return {'ok': True}





@route('announce', roles={'admin', 'officer'})

def announce(ctx, d):

    title, body, aud = S(d, 'title', 150), S(d, 'body', 600), S(d, 'audience')

    if not title: raise Err('Title is required')

    if aud == 'all': ids = [r[0] for r in ctx.con.execute("SELECT id FROM users WHERE status='active'")]

    elif aud in ROLES: ids = role_ids(ctx.con, aud)

    else: raise Err('Choose an audience')

    notify(ctx.con, ids, title, body)

    audit(ctx, 'ANNOUNCEMENT', f'{title} -> {aud} ({len(ids)})')

    return {'sent': len(ids)}





# ---- dashboards ---------------------------------------------------------------------------------

@route('home')

def home(ctx, d):

    con, u = ctx.con, ctx.user

    r, cards, lists = u['role'], [], []

    c = lambda l, n, go=None, col='': cards.append({'l': l, 'n': n, 'go': go, 'c': col})

    unread = val(con, 'SELECT COUNT(*) FROM notifications WHERE user_id=? AND is_read=0', (u['id'],))

    if r == 'student':

        sess = current_session(con)

        ex = student_exams(con, u['id'])

        c('Registered courses', val(con, 'SELECT COUNT(*) FROM registrations WHERE student_id=? AND session_id=?', (u['id'], sess['id'] if sess else 0)), 'register', 'teal')

        c('Exams open / upcoming', len([x for x in ex if x['state'] in ('open', 'upcoming', 'in_progress')]), 'myexams', 'indigo')

        c('Results released', val(con, "SELECT COUNT(*) FROM attempts WHERE student_id=? AND result_state='released'", (u['id'],)), 'myresults', 'amber')

        c('Average score %', round(val(con, "SELECT AVG(pct) FROM attempts WHERE student_id=? AND result_state='released'", (u['id'],)), 1), 'myresults', 'green')

        lists.append({'title': 'Your exams', 'items': [{'t': f"{x['code']} - {x['title']}", 's': f"{x['start_time']} - {x['venue']}", 'tag': x['state'], 'go': 'myexams'} for x in ex if x['state'] in ('open', 'in_progress', 'upcoming')][:6]})

        lists.append({'title': 'Latest results', 'items': [{'t': f"{x['code']} - {x['exam']}", 's': f"{x['pct']}% - Grade {x['grade']}", 'tag': 'passed' if x['passed'] else 'failed', 'go': 'myresults'} for x in my_results(ctx, {})['rows'][:5]]})

    elif r == 'lecturer':

        c('My courses', val(con, 'SELECT COUNT(*) FROM courses WHERE lecturer_id=?', (u['id'],)), 'courses', 'teal')

        c('Questions in bank', val(con, 'SELECT COUNT(*) FROM questions q JOIN courses c ON c.id=q.course_id WHERE c.lecturer_id=?', (u['id'],)), 'bank', 'indigo')

        c('My exams', val(con, 'SELECT COUNT(*) FROM exams e JOIN courses c ON c.id=e.course_id WHERE c.lecturer_id=?', (u['id'],)), 'exams', 'amber')

        pm = val(con, "SELECT COUNT(*) FROM answers an JOIN attempts a ON a.id=an.attempt_id JOIN exams e ON e.id=a.exam_id JOIN courses c ON c.id=e.course_id WHERE c.lecturer_id=? AND an.marked=0 AND a.status='submitted' AND TRIM(an.answer)!=''", (u['id'],))

        c('Answers to mark', pm, 'marking', 'rose' if pm else 'green')

        lists.append({'title': 'Papers needing attention', 'items': [{'t': f"{x['code']} - {x['title']}", 's': x['review_note'] or 'Draft', 'tag': x['status'], 'go': 'exams'} for x in exam_list(ctx, {})['rows'] if x['status'] in ('draft', 'rejected', 'pending')][:6]})

    elif r == 'officer':

        c('Papers awaiting approval', val(con, "SELECT COUNT(*) FROM exams WHERE status='pending'"), 'exams', 'amber')

        c('Approved, not scheduled', val(con, "SELECT COUNT(*) FROM exams e WHERE status='approved' AND NOT EXISTS(SELECT 1 FROM schedules s WHERE s.exam_id=e.id)"), 'timetable', 'indigo')

        c('Results awaiting approval', val(con, "SELECT COUNT(*) FROM attempts WHERE result_state='marked'"), 'results', 'teal')

        c('Pending appeals', val(con, "SELECT COUNT(*) FROM appeals WHERE status='pending'"), 'appeals', 'rose')

        lists.append({'title': 'Papers to review', 'items': [{'t': f"{x['code']} - {x['title']}", 's': x['lecturer'] or '', 'tag': 'pending', 'go': 'exams'} for x in exam_list(ctx, {})['rows'] if x['status'] == 'pending'][:6]})

        lists.append({'title': 'Upcoming exams', 'items': [{'t': f"{x['code']} - {x['title']}", 's': f"{x['start_time']} - {x['venue']}", 'tag': x['state'], 'go': 'timetable'} for x in timetable(ctx, {})['rows'] if x['state'] in ('upcoming', 'open')][:6]})

    elif r == 'invigilator':

        tt = timetable(ctx, {})['rows']

        c('Assigned exams', len(tt), 'timetable', 'teal')

        c('Upcoming / open', len([x for x in tt if x['state'] in ('upcoming', 'open')]), 'attendance', 'indigo')

        c('Incidents reported', val(con, 'SELECT COUNT(*) FROM incidents WHERE invigilator_id=?', (u['id'],)), 'incidents', 'amber')

        lists.append({'title': 'My invigilation duties', 'items': [{'t': f"{x['code']} - {x['title']}", 's': f"{x['start_time']} - {x['venue']} ({x['registered']} students)", 'tag': x['state'], 'go': 'attendance'} for x in tt if x['state'] in ('upcoming', 'open')][:6]})

    else:

        c('Active users', val(con, "SELECT COUNT(*) FROM users WHERE status='active'"), 'users', 'teal')

        pend = val(con, "SELECT COUNT(*) FROM users WHERE status='pending'")

        c('Awaiting approval', pend, 'users', 'rose' if pend else 'green')

        c('Courses', val(con, 'SELECT COUNT(*) FROM courses'), 'academic', 'indigo')

        c('Exam attempts', val(con, "SELECT COUNT(*) FROM attempts WHERE status='submitted'"), 'analysis', 'amber')

        lists.append({'title': 'Accounts awaiting approval', 'items': [{'t': f"{x['full_name']} ({x['role']})", 's': x['username'], 'tag': 'pending', 'go': 'users'} for x in rows(con, "SELECT * FROM users WHERE status='pending' LIMIT 6")]})

        lists.append({'title': 'Recent activity', 'items': [{'t': x['action'], 's': f"{x['created_at']} - {x['detail'] or ''}"[:90], 'go': 'audit'} for x in rows(con, 'SELECT * FROM audit_log ORDER BY id DESC LIMIT 6')]})

    return {'cards': cards, 'lists': lists, 'unread': unread, 'session': (current_session(con) or {}).get('name')}





# ---- analytics ---------------------------------------------------------------------------------

def att_filter(user, d):

    w, a = ["a.status='submitted'", 'a.total IS NOT NULL'], []

    if user['role'] == 'lecturer': w.append('c.lecturer_id=?'); a.append(user['id'])

    for k, col in (('session_id', 'e.session_id'), ('course_id', 'c.id'), ('exam_id', 'e.id')):

        if I(d, k): w.append(col + '=?'); a.append(I(d, k))

    return ' AND '.join(w), a





def compute_analytics(con, user, d):

    w, a = att_filter(user, d)

    frm = 'FROM attempts a JOIN exams e ON e.id=a.exam_id JOIN courses c ON c.id=e.course_id'

    lec, la = ('', [])

    if user['role'] == 'lecturer': lec, la = ' AND c.lecturer_id=?', [user['id']]

    ew = ' WHERE 1=1' + lec

    ea = list(la)

    for k, col in (('session_id', 'e.session_id'), ('course_id', 'c.id'), ('exam_id', 'e.id')):

        if I(d, k): ew += f' AND {col}=?'; ea.append(I(d, k))

    efrm = 'FROM exams e JOIN courses c ON c.id=e.course_id'

    n = val(con, f'SELECT COUNT(*) {frm} WHERE {w}', a)

    passed = val(con, f'SELECT SUM(a.passed) {frm} WHERE {w}', a)

    kpi = {

        'students': val(con, f"SELECT COUNT(DISTINCT r.student_id) FROM registrations r JOIN courses c ON c.id=r.course_id WHERE 1=1{lec}", la) if user['role'] == 'lecturer'

        else val(con, "SELECT COUNT(*) FROM users WHERE role='student' AND status='active'"),

        'courses': val(con, f'SELECT COUNT(*) FROM courses c WHERE 1=1{lec}', la),

        'exams': val(con, f'SELECT COUNT(*) {efrm}{ew}', ea),

        'sat': n, 'avg': round(val(con, f'SELECT AVG(a.pct) {frm} WHERE {w}', a), 1),

        'pass_rate': round(passed / n * 100, 1) if n else 0,

        'highest': val(con, f'SELECT MAX(a.pct) {frm} WHERE {w}', a), 'lowest': val(con, f'SELECT MIN(a.pct) {frm} WHERE {w}', a),

        'to_mark': val(con, f"SELECT COUNT(*) FROM answers an JOIN attempts a ON a.id=an.attempt_id JOIN exams e ON e.id=a.exam_id JOIN courses c ON c.id=e.course_id WHERE an.marked=0 AND a.status='submitted' AND TRIM(an.answer)!=''{lec}", la),

        'flagged': val(con, f'SELECT COUNT(*) {frm} WHERE a.status=\'submitted\' AND a.leave_count>=3{lec}', la),

        'incidents': val(con, 'SELECT COUNT(*) FROM incidents') if user['role'] != 'lecturer' else 0,

    }

    grades = rows(con, f'SELECT a.grade label, COUNT(*) n {frm} WHERE {w} GROUP BY a.grade ORDER BY MIN(a.pct) DESC', a)

    bins = [0] * 10

    for (p,) in con.execute(f'SELECT a.pct {frm} WHERE {w}', a):

        bins[min(int(p // 10), 9)] += 1

    courses = rows(con, f'SELECT c.code label, COUNT(*) sat, ROUND(AVG(a.pct),1) avg, ROUND(100.0*SUM(a.passed)/COUNT(*),1) pass_rate {frm} WHERE {w} GROUP BY c.id ORDER BY c.code', a)

    ex_status = rows(con, f'SELECT e.status label, COUNT(*) n {efrm}{ew} GROUP BY e.status', ea)

    regs = rows(con, f'SELECT p.code label, COUNT(*) n FROM registrations r JOIN courses c ON c.id=r.course_id JOIN programmes p ON p.id=c.programme_id WHERE 1=1{lec} GROUP BY p.id', la)

    tr = {r['d']: r['n'] for r in rows(con, f'SELECT substr(a.started_at,1,10) d, COUNT(*) n {frm} WHERE a.started_at>=? {lec.replace("AND", "AND") if lec else ""} GROUP BY d',

                                      [(datetime.now() - timedelta(days=13)).strftime('%Y-%m-%d')] + la)}

    trend = [{'label': (datetime.now() - timedelta(days=i)).strftime('%d %b'), 'n': tr.get((datetime.now() - timedelta(days=i)).strftime('%Y-%m-%d'), 0)} for i in range(13, -1, -1)]

    summary = rows(con, f"SELECT e.id, e.title exam, c.code, c.title ctitle, "

                        f"(SELECT COUNT(*) FROM registrations r WHERE r.course_id=c.id AND r.session_id=e.session_id) registered, "

                        f"COUNT(a.id) sat, ROUND(AVG(a.pct),1) avg, MAX(a.pct) highest, MIN(a.pct) lowest, COALESCE(SUM(a.passed),0) passed "

                        f"FROM exams e JOIN courses c ON c.id=e.course_id LEFT JOIN attempts a ON a.exam_id=e.id AND a.status='submitted' AND a.total IS NOT NULL "

                        f"{ew} AND e.status='approved' GROUP BY e.id ORDER BY e.id DESC", ea)

    for s in summary:

        s['absent'] = max(0, s['registered'] - s['sat'])

        s['pass_rate'] = round(s['passed'] / s['sat'] * 100, 1) if s['sat'] else 0

    return {'kpi': kpi, 'grades': grades, 'hist': bins, 'courses': courses, 'exam_status': ex_status, 'regs': regs, 'trend': trend, 'summary': summary}





@route('analytics', roles={'admin', 'officer', 'lecturer'})

def analytics(ctx, d):

    out = compute_analytics(ctx.con, ctx.user, d)

    if ctx.user['role'] == 'lecturer':

        out['filters'] = {'courses': rows(ctx.con, 'SELECT id, code, title FROM courses WHERE lecturer_id=? ORDER BY code', (ctx.user['id'],)),

                          'exams': rows(ctx.con, 'SELECT e.id, e.title FROM exams e JOIN courses c ON c.id=e.course_id WHERE c.lecturer_id=? ORDER BY e.id DESC', (ctx.user['id'],))}

    else:

        out['filters'] = {'courses': rows(ctx.con, 'SELECT id, code, title FROM courses ORDER BY code'), 'exams': rows(ctx.con, 'SELECT id, title FROM exams ORDER BY id DESC')}

    out['filters']['sessions'] = rows(ctx.con, 'SELECT id, name FROM academic_sessions ORDER BY id DESC')

    return out





@route('audit_list', roles={'admin'})

def audit_list(ctx, d):

    return {'rows': rows(ctx.con, 'SELECT a.id, a.created_at, COALESCE(u.username,\'-\') username, a.action, a.detail, a.ip FROM audit_log a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.id DESC LIMIT 500')}





# ---- settings, backup, demo ------------------------------------------------------------------------

def backup_db(tag='auto'):

    os.makedirs(BACKUP_DIR, exist_ok=True)

    dest = os.path.join(BACKUP_DIR, f"eemps_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{tag}.db")

    src, dst = sqlite3.connect(DB_PATH), sqlite3.connect(dest)

    with dst: src.backup(dst)

    src.close(); dst.close()

    files = sorted(f for f in os.listdir(BACKUP_DIR) if f.endswith('.db'))

    for f in files[:-21]: os.remove(os.path.join(BACKUP_DIR, f))

    return dest





def backups_info():

    if not os.path.isdir(BACKUP_DIR): return {'count': 0, 'last': None}

    fs = sorted(f for f in os.listdir(BACKUP_DIR) if f.endswith('.db'))

    return {'count': len(fs), 'last': fs[-1] if fs else None}





def backup_loop():

    while True:

        try:

            today = datetime.now().strftime('%Y%m%d')

            if not any(f.startswith('eemps_' + today) for f in (os.listdir(BACKUP_DIR) if os.path.isdir(BACKUP_DIR) else [])):

                if get_setting(db(), 'setup_complete') == '1': backup_db()

        except Exception: traceback.print_exc()

        time.sleep(3600)





@route('settings_get', roles={'admin'})

def settings_get(ctx, d):

    return {'college': get_setting(ctx.con, 'college_name'), 'allow_registration': get_setting(ctx.con, 'allow_registration') == '1', 'backups': backups_info(),

            'counts': {t: val(ctx.con, f'SELECT COUNT(*) FROM {t}') for t in ('users', 'courses', 'questions', 'exams', 'attempts', 'answers', 'audit_log')}}





@route('settings_save', roles={'admin'})

def settings_save(ctx, d):

    set_setting(ctx.con, 'college_name', S(d, 'college', 120) or 'EEMPS')

    set_setting(ctx.con, 'allow_registration', '1' if d.get('allow_registration') else '0')

    audit(ctx, 'SETTINGS_SAVED')

    return {'ok': True}





@route('backup_now', roles={'admin'})

def backup_now(ctx, d):

    ctx.con.commit()

    p = backup_db('manual')

    audit(ctx, 'BACKUP', os.path.basename(p))

    return {'file': os.path.basename(p)}





@route('demo_load', roles={'admin'})

def demo_load(ctx, d):

    con = ctx.con

    if val(con, 'SELECT COUNT(*) FROM courses') or val(con, "SELECT COUNT(*) FROM users WHERE username='officer1'"): raise Err('Demo data can only be loaded into an empty system')

    pw = 'Pass@1234'

    dep1 = con.execute("INSERT INTO departments(name) VALUES('Information and Communication Technology')").lastrowid

    dep2 = con.execute("INSERT INTO departments(name) VALUES('Business Studies')").lastrowid

    p1 = con.execute("INSERT INTO programmes(department_id,code,name) VALUES(?,?,?)", (dep1, 'DICT', 'Diploma in ICT')).lastrowid

    con.execute("INSERT INTO programmes(department_id,code,name) VALUES(?,?,?)", (dep2, 'DBM', 'Diploma in Business Management'))

    sess = con.execute("INSERT INTO academic_sessions(name,start_date,end_date,is_current) VALUES('2026 Term 3','2026-09-01','2026-12-18',1)").lastrowid

    v1 = con.execute("INSERT INTO venues(name,capacity) VALUES('Computer Lab 1',40)").lastrowid

    con.execute("INSERT INTO venues(name,capacity) VALUES('Computer Lab 2',30)")

    add_user(con, 'officer1', 'Grace Mulenga (Exam Officer)', 'officer', pw)

    l1 = add_user(con, 'lecturer1', 'Peter Banda (Lecturer)', 'lecturer', pw)

    l2 = add_user(con, 'lecturer2', 'Mary Phiri (Lecturer)', 'lecturer', pw)

    inv = add_user(con, 'invig1', 'John Zulu (Invigilator)', 'invigilator', pw)

    studs = [add_user(con, f'student{i}', n, 'student', pw, student_no=f'S2026{i:03d}', programme_id=p1, year=1)

             for i, n in ((1, 'Chanda Mwila'), (2, 'Mutale Tembo'), (3, 'Natasha Kunda'))]

    c1 = con.execute("INSERT INTO courses(programme_id,code,title,lecturer_id,credits) VALUES(?,?,?,?,3)", (p1, 'ICT101', 'Introduction to Programming', l1)).lastrowid

    c2 = con.execute("INSERT INTO courses(programme_id,code,title,lecturer_id,credits) VALUES(?,?,?,?,3)", (p1, 'ICT102', 'Database Systems', l2)).lastrowid

    for s in studs:

        for c in (c1, c2): con.execute('INSERT INTO registrations(student_id,course_id,session_id,created_at) VALUES(?,?,?,?)', (s, c, sess, now()))

    Q = [(c1, l1, 'mcq', 'Which symbol starts a single-line comment in Python?', ['//', '#', '--', '/*'], '1', 1),

         (c1, l1, 'mcq', 'Which data type stores True or False?', ['int', 'str', 'bool', 'float'], '2', 1),

         (c1, l1, 'mcq', 'What does a loop do?', ['Stores data', 'Repeats instructions', 'Prints a page', 'Deletes a file'], '1', 1),

         (c1, l1, 'tf', 'A variable name can start with a digit in most languages.', [], 'False', 1),

         (c1, l1, 'fill', 'The keyword used to define a function in Python is ____.', [], 'def', 2),

         (c1, l1, 'essay', 'Explain the difference between a compiler and an interpreter.', [], 'Compiler translates whole program; interpreter executes line by line.', 6),

         (c2, l2, 'mcq', 'What does SQL stand for?', ['Structured Query Language', 'Simple Question List', 'Sequential Query Logic', 'Standard Quick Link'], '0', 1),

         (c2, l2, 'tf', 'A primary key can contain duplicate values.', [], 'False', 1),

         (c2, l2, 'fill', 'The SQL command used to retrieve data is ____.', [], 'select', 2)]

    qids = [con.execute('INSERT INTO questions(course_id,author_id,topic,qtype,text,options,answer,marks,difficulty,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)',

                        (c, a, 'General', t, tx, json.dumps(o), an, m, 'medium', now())).lastrowid for c, a, t, tx, o, an, m in Q]

    eid = con.execute("INSERT INTO exams(course_id,session_id,title,instructions,duration_min,pass_pct,shuffle,status,created_by,created_at) VALUES(?,?,?,?,45,40,1,'approved',?,?)",

                      (c1, sess, 'ICT101 Mid-Term Test', 'Answer all questions. Do not leave the exam page.', l1, now())).lastrowid

    for i, qi in enumerate(qids[:6]): con.execute('INSERT INTO exam_questions(exam_id,question_id,marks,ord) VALUES(?,?,?,?)', (eid, qi, Q[i][6], i))

    st = datetime.now() - timedelta(minutes=5)

    con.execute('INSERT INTO schedules(exam_id,venue_id,invigilator_id,start_time,end_time,created_at) VALUES(?,?,?,?,?,?)',

                (eid, v1, inv, st.strftime('%Y-%m-%d %H:%M'), (st + timedelta(hours=4)).strftime('%Y-%m-%d %H:%M'), now()))

    con.execute("INSERT INTO exams(course_id,session_id,title,instructions,duration_min,pass_pct,status,created_by,created_at) VALUES(?,?,?,?,30,40,'draft',?,?)",

                (c2, sess, 'ICT102 Quiz 1', 'Short quiz', l2, now()))

    audit(ctx, 'DEMO_LOADED')

    return {'password': pw}





# ---- exports -----------------------------------------------------------------------------------------

def export_rows(con, user, kind, q):

    r, d = user['role'], {k: v[0] for k, v in q.items()}

    if kind == 'results' and r in ('admin', 'officer', 'lecturer'):

        sql, a = RES_SQL, []

        if r == 'lecturer': sql += ' AND c.lecturer_id=?'; a.append(user['id'])

        if I(d, 'exam_id'): sql += ' AND e.id=?'; a.append(I(d, 'exam_id'))

        data = rows(con, sql + ' ORDER BY e.id DESC, s.full_name', a)

        return 'results', ['Student No', 'Student', 'Programme', 'Course', 'Exam', 'Score', 'Max', 'Percent', 'Grade', 'Passed', 'State', 'Tab leaves', 'Submitted'], \
            [[x['student_no'], x['student'], x['programme'], x['code'], x['exam'], x['total'], x['max_marks'], x['pct'], x['grade'], {1: 'Yes', 0: 'No'}.get(x['passed'], ''), x['result_state'], x['leave_count'], x['submitted_at']] for x in data]

    if kind in ('summary', 'report') and r in ('admin', 'officer', 'lecturer'):

        an = compute_analytics(con, user, d)

        h = ['Exam', 'Course', 'Registered', 'Sat', 'Absent', 'Average %', 'Highest %', 'Lowest %', 'Passed', 'Pass rate %']

        body = [[s['exam'], s['code'], s['registered'], s['sat'], s['absent'], s['avg'], s['highest'], s['lowest'], s['passed'], s['pass_rate']] for s in an['summary']]

        if kind == 'report':

            k = an['kpi']

            body = [['KEY INDICATORS'], ['Students', k['students']], ['Courses', k['courses']], ['Exams', k['exams']], ['Scripts marked', k['sat']], ['Average %', k['avg']], ['Pass rate %', k['pass_rate']],

                    [], ['GRADE DISTRIBUTION']] + [[g['label'], g['n']] for g in an['grades']] + [[], ['PER COURSE (code, sat, average %, pass rate %)']] + \
                [[c['label'], c['sat'], c['avg'], c['pass_rate']] for c in an['courses']] + [[], ['PER EXAM'], h] + body

            return 'analysis_report', ['EEMPS Analysis Report', datetime.now().strftime('%Y-%m-%d %H:%M')], body

        return 'exam_summary', h, body

    if kind == 'users' and r == 'admin':

        return 'users', ['Username', 'Full name', 'Role', 'Status', 'Student No', 'Programme', 'Email', 'Phone', 'Created'], \
            [[u['username'], u['full_name'], u['role'], u['status'], u['student_no'], u['programme'], u['email'], u['phone'], u['created_at']] for u in

             rows(con, 'SELECT u.*, p.code programme FROM users u LEFT JOIN programmes p ON p.id=u.programme_id ORDER BY u.role, u.full_name')]

    if kind == 'audit' and r == 'admin':

        return 'audit_log', ['Time', 'User', 'Action', 'Detail', 'IP'], [[x['created_at'], x['username'], x['action'], x['detail'], x['ip']] for x in

                                                                    rows(con, "SELECT a.*, COALESCE(u.username,'-') username FROM audit_log a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.id DESC")]

    if kind == 'registrations' and r in ('admin', 'officer'):

        return 'registrations', ['Student No', 'Student', 'Programme', 'Course', 'Session'], [[x['student_no'], x['full_name'], x['pcode'], x['code'], x['session']] for x in

                                                                                               rows(con, 'SELECT u.student_no, u.full_name, p.code pcode, c.code, s.name session FROM registrations r JOIN users u ON u.id=r.student_id JOIN courses c ON c.id=r.course_id JOIN programmes p ON p.id=c.programme_id JOIN academic_sessions s ON s.id=r.session_id ORDER BY s.id DESC, c.code, u.full_name')]

    if kind == 'attendance' and r in ('admin', 'officer', 'invigilator'):

        class C: pass

        c = C(); c.con, c.user = con, user

        data = attendance_list(c, {'exam_id': d.get('exam_id')})

        return 'attendance', ['Student No', 'Student', 'Present', 'Exam status', 'Answered', 'Tab leaves'], \
            [[x['student_no'], x['full_name'], 'Yes' if x['present'] else 'No', x['astatus'] or 'not started', x['answered'], x['leave_count']] for x in data['rows']]

    if kind == 'incidents' and r in ('admin', 'officer', 'invigilator'):

        sql = INC_SQL + (' WHERE i.invigilator_id=?' if r == 'invigilator' else '')

        return 'incidents', ['Time', 'Exam', 'Student', 'Invigilator', 'Description'], [[x['created_at'], x['exam'], x['student'], x['invigilator'], x['description']] for x in rows(con, sql + ' ORDER BY i.id DESC', (user['id'],) if r == 'invigilator' else ())]

    if kind == 'appeals' and r in ('admin', 'officer'):

        return 'appeals', ['Created', 'Student', 'Exam', 'Status', 'Reason', 'Response'], [[x['created_at'], x['student'], x['exam'], x['status'], x['reason'], x['response']] for x in appeal_list(type('C', (), {'con': con, 'user': user}), {})['rows']]

    raise Err('Export not available', 403)





# ----------------------------------------------------------------------------

# HTTP SERVER

# ----------------------------------------------------------------------------

class Handler(BaseHTTPRequestHandler):

    server_version = 'EEMPS/1.0'

    protocol_version = 'HTTP/1.1'



    def log_message(self, *a): pass



    def ip(self): return self.client_address[0]



    def send_bytes(self, code, body, ctype, extra=None):

        self.send_response(code)

        self.send_header('Content-Type', ctype)

        self.send_header('Content-Length', str(len(body)))

        self.send_header('Cache-Control', 'no-store')

        self.send_header('X-Content-Type-Options', 'nosniff')

        self.send_header('X-Frame-Options', 'DENY')

        self.send_header('Referrer-Policy', 'same-origin')

        self.send_header('Content-Security-Policy', "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; img-src 'self' data:")

        for k, v in (extra or []): self.send_header(k, v)

        self.end_headers()

        self.wfile.write(body)



    def json(self, code, obj, extra=None):

        self.send_bytes(code, json.dumps(obj, default=str).encode('utf-8'), 'application/json; charset=utf-8', extra)



    def session_user(self, con):

        m = SimpleCookie(self.headers.get('Cookie', '')).get('eemps_sid')

        if not m: return None

        r = row(con, 'SELECT u.*, s.last_seen, s.token _token FROM auth_sessions s JOIN users u ON u.id=s.user_id WHERE s.token=?', (m.value,))

        if not r or r['status'] != 'active': return None

        if datetime.now() - pdt(r['last_seen']) > timedelta(hours=SESSION_HOURS):

            con.execute('DELETE FROM auth_sessions WHERE token=?', (m.value,))

            con.commit()

            return None

        if (datetime.now() - pdt(r['last_seen'])).total_seconds() > 60:

            con.execute('UPDATE auth_sessions SET last_seen=? WHERE token=?', (now(), m.value))

        return r



    def do_GET(self):

        u = urlparse(self.path)

        if u.path in ('/', '/index.html'):

            return self.send_bytes(200, INDEX_HTML.encode('utf-8'), 'text/html; charset=utf-8')

        if u.path.startswith('/export/'):

            return self.export(u)

        self.send_bytes(404, b'Not found', 'text/plain')



    def export(self, u):

        con = db()

        try:

            user = self.session_user(con)

            if not user: return self.send_bytes(401, b'Please sign in', 'text/plain')

            kind = u.path.split('/export/')[1].replace('.csv', '')

            if kind == 'backup':

                if user['role'] != 'admin': return self.send_bytes(403, b'Forbidden', 'text/plain')

                con.commit()

                p = backup_db('download')

                data = open(p, 'rb').read()

                return self.send_bytes(200, data, 'application/octet-stream', [('Content-Disposition', 'attachment; filename="eemps_backup.db"')])

            name, header, body = export_rows(con, user, kind, parse_qs(u.query))

            buf = io.StringIO()

            w = csv.writer(buf)

            w.writerow(header)

            for r in body: w.writerow([csv_safe(c) for c in r])

            ctx = Ctx(con, user, self.ip())

            audit(ctx, 'EXPORT', kind)

            con.commit()

            data = ('\ufeff' + buf.getvalue()).encode('utf-8')

            self.send_bytes(200, data, 'text/csv; charset=utf-8', [('Content-Disposition', f'attachment; filename="eemps_{name}_{datetime.now():%Y%m%d}.csv"')])

        except Err as e:

            self.send_bytes(e.code, e.msg.encode(), 'text/plain')

        except Exception:

            traceback.print_exc()

            self.send_bytes(500, b'Server error', 'text/plain')

        finally:

            con.close()



    def do_POST(self):

        u = urlparse(self.path)

        if not u.path.startswith('/api/'): return self.send_bytes(404, b'{}', 'application/json')

        if self.headers.get('X-Requested-With') != 'EEMPS': return self.json(403, {'error': 'Forbidden'})

        try:

            n = int(self.headers.get('Content-Length') or 0)

            if n > 2_000_000: return self.json(413, {'error': 'Request too large'})

            d = json.loads(self.rfile.read(n) or b'{}')

            if not isinstance(d, dict): d = {}

        except Exception:

            return self.json(400, {'error': 'Bad request'})

        action = u.path[5:]

        if action not in ROUTES: return self.json(404, {'error': 'Unknown action'})

        fn, roles, public = ROUTES[action]

        con = db()

        try:

            user = self.session_user(con)

            if not public and not user: raise Err('Please sign in', 401)

            if roles and (not user or user['role'] not in roles): raise Err('You are not allowed to do this', 403)

            try: finalize_expired(con)

            except Exception: traceback.print_exc()

            ctx = Ctx(con, user, self.ip())

            res = fn(ctx, d)

            con.commit()

            extra = []

            if ctx.cookie: extra.append(('Set-Cookie', f'eemps_sid={ctx.cookie}; HttpOnly; SameSite=Strict; Path=/; Max-Age={SESSION_HOURS * 3600}'))

            if ctx.clear_cookie: extra.append(('Set-Cookie', 'eemps_sid=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'))

            self.json(200, res, extra)

        except Err as e:

            con.rollback()

            self.json(e.code, {'error': e.msg})

        except sqlite3.IntegrityError as e:

            con.rollback()

            m = str(e)

            if 'users.username' in m: msg = 'That username is already taken'

            elif 'users.student_no' in m: msg = 'That student number is already registered'

            elif 'FOREIGN KEY' in m: msg = 'This record is linked to other records and cannot be changed or deleted'

            elif 'UNIQUE' in m: msg = 'A record with the same unique value already exists'

            else: msg = 'Invalid data: ' + m

            self.json(409, {'error': msg})

        except Exception:

            con.rollback()

            traceback.print_exc()

            self.json(500, {'error': 'Server error. Please try again.'})

        finally:

            con.close()





def lan_ip():

    try:

        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

        s.connect(('10.255.255.255', 1))

        ip = s.getsockname()[0]

        s.close()

        return ip

    except Exception:

        return '127.0.0.1'





def main():

    init_db()

    threading.Thread(target=backup_loop, daemon=True).start()

    srv = ThreadingHTTPServer((HOST, PORT), Handler)

    srv.daemon_threads = True

    print('=' * 64)

    print(' EEMPS - Electronic Examination Management Platform System')

    print('=' * 64)

    print(f' Open on this computer :  http://localhost:{PORT}')

    if HOST == '0.0.0.0': print(f' Open on the college LAN:  http://{lan_ip()}:{PORT}')

    con = db()

    if get_setting(con, 'setup_complete') != '1':

        print('\n *** FIRST RUN: the first person to open the page becomes the administrator. ***')

    con.close()

    print(f' Database: {DB_PATH}\n Press Ctrl+C to stop.\n')

    if os.environ.get('EEMPS_NO_BROWSER') != '1':

        threading.Timer(1.0, lambda: webbrowser.open(f'http://localhost:{PORT}')).start()

    try:

        srv.serve_forever()

    except KeyboardInterrupt:

        print('\nStopped.')





# ----------------------------------------------------------------------------

# FRONT END (single page application)

# ----------------------------------------------------------------------------

INDEX_HTML = r'''<!DOCTYPE html>

<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">

<title>EEMPS - Examination Management</title>

<style>

:root{--bg:#f1f5f9;--card:#fff;--text:#0f172a;--muted:#64748b;--line:#e2e8f0;--pri:#0d9488;--pri2:#0f766e;--acc:#6366f1;--warn:#f59e0b;--bad:#e11d48;--ok:#16a34a;--side:#10263a;--sidetxt:#b6c4d3;--soft:#f8fafc;--shadow:0 1px 3px rgba(15,23,42,.08),0 8px 24px rgba(15,23,42,.05)}

[data-theme=dark]{--bg:#0b1220;--card:#121c31;--text:#e5e7eb;--muted:#94a3b8;--line:#22304d;--side:#08111f;--soft:#0f1830;--shadow:0 1px 3px rgba(0,0,0,.4)}

*{box-sizing:border-box}html,body{margin:0;font-family:Inter,Segoe UI,system-ui,-apple-system,Roboto,sans-serif;background:var(--bg);color:var(--text);font-size:14.5px}

h1,h2,h3,h4{margin:0 0 .4em}p{margin:.3em 0}.muted{color:var(--muted)}b{font-weight:650}

button,input,select,textarea{font:inherit;color:inherit}

.btn{background:linear-gradient(135deg,var(--pri),var(--pri2));color:#fff;border:0;border-radius:10px;padding:.6em 1.1em;cursor:pointer;font-weight:600;transition:.15s;box-shadow:0 2px 6px rgba(13,148,136,.25)}

.btn:hover{transform:translateY(-1px);filter:brightness(1.07)}.btn:active{transform:none}.btn:disabled{opacity:.5;cursor:not-allowed}

.btn.ghost{background:transparent;color:var(--text);border:1px solid var(--line);box-shadow:none}.btn.ghost:hover{background:var(--soft)}

.btn.bad{background:linear-gradient(135deg,#f43f5e,var(--bad))}.btn.ind{background:linear-gradient(135deg,#818cf8,var(--acc))}.btn.amb{background:linear-gradient(135deg,#fbbf24,#d97706)}

.btn.sm{padding:.38em .8em;font-size:13px}.btn.xs{padding:.2em .6em;font-size:12px;border-radius:8px}.row{display:flex;gap:.6rem;align-items:center;flex-wrap:wrap}.row.end{justify-content:flex-end;margin-top:1rem}

input,select,textarea{width:100%;padding:.6em .8em;border:1px solid var(--line);border-radius:10px;background:var(--card);outline:none;transition:.15s}

input:focus,select:focus,textarea:focus{border-color:var(--pri);box-shadow:0 0 0 3px rgba(13,148,136,.18)}

.fld{display:flex;flex-direction:column;gap:.3rem}.fld span{font-size:12.5px;font-weight:600;color:var(--muted)}.fld small{color:var(--muted);font-size:12px}

.grid2{display:grid;grid-template-columns:1fr 1fr;gap:.9rem}.grid2 .w2{grid-column:1/-1}

.card{background:var(--card);border-radius:16px;box-shadow:var(--shadow);border:1px solid var(--line)}.pad{padding:1.2rem}

.shell{display:flex;min-height:100vh}aside{width:250px;background:linear-gradient(180deg,var(--side),#0b1b2b);color:var(--sidetxt);padding:1rem .8rem;position:sticky;top:0;height:100vh;overflow:auto;flex-shrink:0}

.brand{display:flex;align-items:center;gap:.6rem;padding:.4rem .6rem 1rem;color:#fff;font-weight:800;font-size:19px;letter-spacing:.5px}.brand i{font-style:normal;background:linear-gradient(135deg,var(--pri),var(--acc));border-radius:10px;padding:.2rem .45rem}

.nav a{display:flex;gap:.7rem;align-items:center;padding:.65rem .8rem;border-radius:10px;color:var(--sidetxt);text-decoration:none;cursor:pointer;margin-bottom:2px;transition:.15s}

.nav a:hover{background:rgba(255,255,255,.07);color:#fff}.nav a.on{background:linear-gradient(135deg,rgba(13,148,136,.9),rgba(99,102,241,.8));color:#fff;box-shadow:0 4px 12px rgba(0,0,0,.25)}

.who{margin-top:1rem;padding:.8rem;background:rgba(255,255,255,.06);border-radius:12px;font-size:13px}.who b{color:#fff;display:block}

.content{flex:1;min-width:0}header{display:flex;align-items:center;gap:.8rem;padding:.8rem 1.4rem;background:var(--card);border-bottom:1px solid var(--line);position:sticky;top:0;z-index:5}

header h1{font-size:18px;margin:0;flex:1}.ibtn{background:var(--soft);border:1px solid var(--line);border-radius:10px;width:38px;height:38px;cursor:pointer;position:relative;font-size:16px}

.badge{position:absolute;top:-6px;right:-6px;background:var(--bad);color:#fff;border-radius:99px;font-size:11px;padding:1px 6px;font-weight:700}

main{padding:1.4rem;max-width:1400px;animation:fade .25s}@keyframes fade{from{opacity:0;transform:translateY(6px)}to{opacity:1}}

.ph{margin-bottom:1rem}.ph h2{font-size:22px;margin:0}.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:1rem;margin-bottom:1.2rem}

.stat{background:var(--card);border-radius:16px;padding:1.1rem 1.2rem;border:1px solid var(--line);box-shadow:var(--shadow);border-left:5px solid var(--pri);cursor:default;transition:.2s}

.stat[data-go]{cursor:pointer}.stat:hover{transform:translateY(-3px)}.stat .n{font-size:30px;font-weight:800;line-height:1.1}.stat .l{color:var(--muted);font-size:13px;margin-top:.2rem}

.stat.indigo{border-color:var(--acc)}.stat.amber{border-color:var(--warn)}.stat.rose{border-color:var(--bad)}.stat.green{border-color:var(--ok)}

.cols{display:grid;grid-template-columns:repeat(auto-fit,minmax(340px,1fr));gap:1rem}.list-item{display:flex;gap:.7rem;align-items:center;padding:.65rem .2rem;border-bottom:1px solid var(--line);cursor:pointer}.list-item:last-child{border:0}.list-item:hover{background:var(--soft)}.list-item .t{flex:1;min-width:0}.list-item .t div:first-child{font-weight:600}

.tbl .tbar{display:flex;gap:.6rem;align-items:center;padding:.8rem 1rem;border-bottom:1px solid var(--line);flex-wrap:wrap}.search{max-width:260px}.scroll{overflow:auto;max-height:68vh}

table{border-collapse:collapse;width:100%}th{position:sticky;top:0;background:var(--soft);text-align:left;font-size:12px;text-transform:uppercase;letter-spacing:.04em;color:var(--muted);padding:.7rem 1rem;white-space:nowrap}

td{padding:.65rem 1rem;border-top:1px solid var(--line);vertical-align:middle}tbody tr:hover{background:var(--soft)}td.empty{text-align:center;color:var(--muted);padding:2rem}

.pill{display:inline-block;padding:.15em .7em;border-radius:99px;font-size:12px;font-weight:650;background:#e2e8f0;color:#334155;white-space:nowrap}

.pill.ok{background:#dcfce7;color:#166534}.pill.warn{background:#fef3c7;color:#92400e}.pill.bad{background:#ffe4e6;color:#9f1239}.pill.info{background:#e0e7ff;color:#3730a3}.pill.teal{background:#ccfbf1;color:#115e59}

[data-theme=dark] .pill{filter:brightness(.92)}

.tabs{display:flex;gap:.4rem;flex-wrap:wrap;margin-bottom:1rem}.tab{padding:.5rem 1rem;border-radius:99px;background:var(--card);border:1px solid var(--line);cursor:pointer;font-weight:600;color:var(--muted)}.tab.on{background:var(--pri);color:#fff;border-color:var(--pri)}

.mback{position:fixed;inset:0;background:rgba(15,23,42,.55);display:flex;align-items:flex-start;justify-content:center;padding:4vh 1rem;overflow:auto;z-index:50;animation:fade .15s}

.mbox{background:var(--card);border-radius:18px;padding:1.4rem;width:min(560px,100%);box-shadow:0 20px 60px rgba(0,0,0,.4)}.mbox.wide{width:min(1000px,100%)}

#toast{position:fixed;bottom:1.2rem;right:1.2rem;z-index:99;display:flex;flex-direction:column;gap:.5rem}.toast{background:#0f172a;color:#fff;padding:.8rem 1.1rem;border-radius:12px;box-shadow:0 8px 24px rgba(0,0,0,.3);border-left:5px solid var(--ok);animation:fade .2s;max-width:380px}.toast.err{border-color:var(--bad)}

.auth{min-height:100vh;display:grid;grid-template-columns:1.1fr 1fr}.hero{background:linear-gradient(135deg,#0f766e 0%,#115e59 35%,#4338ca 100%);color:#fff;padding:3rem;display:flex;flex-direction:column;justify-content:center;position:relative;overflow:hidden}

.hero:before,.hero:after{content:"";position:absolute;border-radius:50%;background:rgba(255,255,255,.07)}.hero:before{width:420px;height:420px;top:-120px;right:-120px}.hero:after{width:300px;height:300px;bottom:-100px;left:-60px}

.hero h1{font-size:34px;line-height:1.15;position:relative}.hero .logo{font-size:22px;font-weight:800;margin-bottom:1.5rem;position:relative}.hero ul{padding-left:1.1rem;line-height:1.9;opacity:.95;position:relative}

.panel{display:flex;align-items:center;justify-content:center;padding:2rem}.panel .box{width:min(440px,100%)}.panel form{display:grid;gap:.9rem;margin-top:1rem}

.note{background:#fef3c7;color:#78350f;border-radius:10px;padding:.7rem .9rem;font-size:13px}.note.info{background:#e0e7ff;color:#312e81}

.qcard{padding:1.2rem;border:1px solid var(--line);border-radius:14px;margin-bottom:.8rem;background:var(--card)}

.cbox{padding:1rem 1.2rem}.cbox h3{font-size:15px}canvas{width:100%;height:260px;display:block}.chead{display:flex;justify-content:space-between;align-items:center}

#tip{position:fixed;background:#0f172a;color:#fff;padding:.35rem .6rem;border-radius:8px;font-size:12px;pointer-events:none;display:none;z-index:200}

#exam{position:fixed;inset:0;background:var(--bg);z-index:80;display:none;overflow:auto}.eh{position:sticky;top:0;background:var(--card);border-bottom:1px solid var(--line);padding:.8rem 1.4rem;display:flex;align-items:center;gap:1rem;z-index:3;flex-wrap:wrap}

.timer{font-size:24px;font-weight:800;font-variant-numeric:tabular-nums;padding:.2rem .9rem;border-radius:12px;background:#ccfbf1;color:#115e59}.timer.low{background:#ffe4e6;color:#9f1239;animation:pulse 1s infinite}@keyframes pulse{50%{opacity:.6}}

.eb{display:grid;grid-template-columns:230px 1fr;gap:1.2rem;padding:1.2rem 1.4rem;max-width:1200px;margin:auto}.qnav{display:grid;grid-template-columns:repeat(5,1fr);gap:.4rem;align-content:start}

.qn{padding:.5rem 0;text-align:center;border-radius:8px;border:1px solid var(--line);cursor:pointer;font-weight:600;background:var(--card)}.qn.done{background:#ccfbf1;border-color:var(--pri)}.qn.cur{outline:3px solid var(--acc)}.qn.flag{background:#fef3c7;border-color:var(--warn)}

.opt{display:flex;gap:.7rem;align-items:center;padding:.8rem 1rem;border:1.5px solid var(--line);border-radius:12px;margin:.5rem 0;cursor:pointer;transition:.15s}.opt:hover{border-color:var(--pri);background:var(--soft)}.opt.sel{border-color:var(--pri);background:rgba(13,148,136,.1)}.opt input{width:auto}

.warnbar{background:#ffe4e6;color:#9f1239;padding:.5rem 1rem;border-radius:10px;font-size:13px;display:none}

.pb .cols2{display:grid;grid-template-columns:1fr 1fr;gap:1rem}.pb .list{max-height:48vh;overflow:auto;border:1px solid var(--line);border-radius:12px;padding:.4rem}.qi{display:flex;gap:.5rem;align-items:center;padding:.4rem;border-bottom:1px solid var(--line);font-size:13px}.qi .mk{width:64px;padding:.25em}.tag{background:var(--soft);border:1px solid var(--line);padding:0 .45em;border-radius:6px;font-size:11px;text-transform:uppercase}

#printarea{display:none}.ans{white-space:pre-wrap;background:var(--soft);border-radius:10px;padding:.7rem;border:1px solid var(--line)}

@media(max-width:900px){.auth{grid-template-columns:1fr}.hero{display:none}aside{position:fixed;z-index:30;left:-270px;transition:.25s}aside.open{left:0}.eb{grid-template-columns:1fr}.grid2,.pb .cols2{grid-template-columns:1fr}main{padding:.9rem}#menu{display:inline-block!important}}

@media print{body>*:not(#printarea){display:none!important}#printarea{display:block!important;color:#000;background:#fff;padding:10px}#printarea table{width:100%;font-size:11px}#printarea th,#printarea td{border:1px solid #999;padding:4px}#printarea img{max-width:48%;margin:4px}}

</style></head>

<body>

<div id="app"></div><div id="modal"></div><div id="exam"></div><div id="toast"></div><div id="tip"></div><div id="printarea"></div>

<script>

const $=(s,e=document)=>e.querySelector(s),$$=(s,e=document)=>[...e.querySelectorAll(s)];

const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

const S={user:null,boot:null,tab:{},ent:'departments',f:{}},D={},T={},ACT={},PAGES={};

const ROLES={admin:'Administrator',officer:'Examination Officer',lecturer:'Lecturer',invigilator:'Invigilator',student:'Student'};

const MENU={

admin:[['home','Dashboard','🏠'],['analysis','Analysis & Reports','📊'],['users','Users','👥'],['academic','Academic Setup','🏫'],['timetable','Timetable','🗓️'],['results','Results','🧾'],['incidents','Incidents','🚨'],['announce','Announcements','📣'],['audit','Audit Log','🔍'],['settings','Settings & Backup','⚙️']],

officer:[['home','Dashboard','🏠'],['analysis','Analysis & Reports','📊'],['exams','Exam Papers','📝'],['timetable','Timetable','🗓️'],['venues','Venues','📍'],['results','Results','🧾'],['appeals','Appeals','⚖️'],['incidents','Incidents','🚨'],['announce','Announcements','📣']],

lecturer:[['home','Dashboard','🏠'],['courses','My Courses','📚'],['bank','Question Bank','🗃️'],['exams','Exams','📝'],['timetable','Timetable','🗓️'],['marking','Marking','✍️'],['results','Results','🧾'],['appeals','Appeals','⚖️'],['analysis','Analysis','📊']],

invigilator:[['home','Dashboard','🏠'],['timetable','My Assignments','🗓️'],['attendance','Attendance & Monitor','✅'],['incidents','Incidents','🚨']],

student:[['home','Dashboard','🏠'],['register','Course Registration','📋'],['timetable','Timetable','🗓️'],['myexams','My Exams','🖥️'],['myresults','My Results','🎓'],['appeals','My Appeals','⚖️']]};

const PILL={active:'ok',pending:'warn',disabled:'bad',draft:'',approved:'ok',rejected:'bad',marked:'info',released:'ok',open:'ok',upcoming:'info',missed:'bad',in_progress:'warn',submitted:'teal',passed:'ok',failed:'bad',accepted:'ok'};

const pill=s=>`<span class="pill ${PILL[s]??''}">${esc(String(s||'').replace('_',' '))}</span>`;

const byId=(a,id)=>(a||[]).find(x=>String(x.id)===String(id));

const money=n=>n==null?'-':n;

function toast(m,t){const d=document.createElement('div');d.className='toast '+(t||'');d.textContent=m;$('#toast').appendChild(d);setTimeout(()=>d.remove(),t?5000:3200)}

async function api(a,d={}){let r;try{r=await fetch('/api/'+a,{method:'POST',headers:{'Content-Type':'application/json','X-Requested-With':'EEMPS'},body:JSON.stringify(d)})}catch(e){throw new Error('Network error - check your connection')}

 let j={};try{j=await r.json()}catch(e){} if(!r.ok){if(r.status===401&&S.user&&a!=='login'){S.user=null;render()} const er=new Error(j.error||'Request failed');er.status=r.status;throw er} return j}

const call=async(a,d,ok)=>{try{const r=await api(a,d);if(ok)toast(ok);return r}catch(e){toast(e.message,'err');return null}};

function openModal(h,w){$('#modal').innerHTML=`<div class="mback" data-bd="1"><div class="mbox ${w?'wide':''}">${h}</div></div>`}

function closeModal(){$('#modal').innerHTML=''}

const main=h=>{$('#main').innerHTML=h;window.scrollTo(0,0)};

function fld(x,v){const val=v!=null?v:(x.d??'');let i;

 if(x.t==='select')i=`<select name="${x.n}" ${x.req?'required':''}>${x.req?'':'<option value="">- none -</option>'}${x.o.map(([a,b])=>`<option value="${esc(a)}" ${String(a)===String(val)?'selected':''}>${esc(b)}</option>`).join('')}</select>`;

 else if(x.t==='textarea')i=`<textarea name="${x.n}" rows="${x.rows||3}" ${x.req?'required':''}>${esc(val)}</textarea>`;

 else i=`<input name="${x.n}" type="${x.t||'text'}" value="${esc(val)}" ${x.req?'required':''} ${x.min!=null?`min="${x.min}"`:''} ${x.max!=null?`max="${x.max}"`:''} ${x.step?`step="${x.step}"`:''} placeholder="${esc(x.ph||'')}" ${x.t==='password'?'autocomplete="new-password"':''}>`;

 return `<label class="fld ${x.w?'w2':''}"><span>${esc(x.l)}${x.req?' *':''}</span>${i}${x.h?`<small>${esc(x.h)}</small>`:''}</label>`}

function formModal(o){openModal(`<form id="mf"><h3>${esc(o.title)}</h3>${o.intro?`<p class="muted">${esc(o.intro)}</p>`:''}<div class="grid2">${o.fields.map(x=>fld(x,(o.values||{})[x.n])).join('')}</div><div class="row end"><button type="button" class="btn ghost" data-act="close">Cancel</button><button class="btn">${esc(o.ok||'Save')}</button></div></form>`);

 $('#mf').onsubmit=async e=>{e.preventDefault();const d={};new FormData(e.target).forEach((v,k)=>d[k]=v);const b=$('#mf .btn:not(.ghost)');b.disabled=true;const r=await o.onSave(d);if(r===false)b.disabled=false;else closeModal()}}

let TID=0;

function dtable(cols,rows,o={}){const id='t'+(++TID);T[id]={cols,rows,name:o.name||'export'};const v=(c,r)=>c.v?c.v(r):'';

 const body=rows.map(r=>`<tr data-q="${esc(cols.map(c=>v(c,r)).join(' ').toLowerCase())}">${cols.map(c=>`<td>${c.h?c.h(r):esc(v(c,r))}</td>`).join('')}</tr>`).join('');

 return `<div class="card tbl" id="${id}"><div class="tbar"><input class="search" placeholder="🔎 Search..." data-search="${id}"><span class="muted">${rows.length} record(s)</span><span style="flex:1"></span>${o.extra||''}${o.add?`<button class="btn sm" data-act="${o.add[0]}" ${o.add[2]?`data-id="${esc(o.add[2])}"`:''}>${o.add[1]}</button>`:''}${o.noexport?'':`<button class="btn ghost sm" data-export="${id}">⬇ CSV</button><button class="btn ghost sm" data-print="${id}">🖨 Print</button>`}</div><div class="scroll"><table><thead><tr>${cols.map(c=>`<th>${esc(c.t)}</th>`).join('')}</tr></thead><tbody>${body||`<tr><td colspan="${cols.length}" class="empty">Nothing here yet</td></tr>`}</tbody></table></div></div>`}

function csvOf(id){const t=T[id],cs=t.cols.filter(c=>c.v);const q=x=>'"'+String(x??'').replace(/"/g,'""')+'"';return '\ufeff'+[cs.map(c=>q(c.t)).join(',')].concat(t.rows.map(r=>cs.map(c=>q(c.v(r))).join(','))).join('\r\n')}

function download(name,text,type){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([text],{type:type||'text/csv'}));a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),2000)}

function printHTML(title,inner){$('#printarea').innerHTML=`<h2>${esc(S.boot.college)}</h2><h3>${esc(title)}</h3><p>Printed ${new Date().toLocaleString()} by ${esc(S.user.full_name)}</p>${inner}`;setTimeout(()=>window.print(),150)}

function printTable(id){const t=T[id],cs=t.cols.filter(c=>c.v);printHTML(t.name,`<table><thead><tr>${cs.map(c=>`<th>${esc(c.t)}</th>`).join('')}</tr></thead><tbody>${t.rows.map(r=>`<tr>${cs.map(c=>`<td>${esc(c.v(r))}</td>`).join('')}</tr>`).join('')}</tbody></table>`)}

document.addEventListener('click',e=>{const b=e.target.closest('[data-act],[data-export],[data-print],[data-go],[data-tab]');

 if(e.target.dataset.bd&&!$('#exam').style.display.includes('block')){closeModal();return} if(!b)return;

 if(b.dataset.go){go(b.dataset.go);return} if(b.dataset.export){download('eemps_'+T[b.dataset.export].name+'.csv',csvOf(b.dataset.export));return}

 if(b.dataset.print){printTable(b.dataset.print);return} if(b.dataset.tab){const[k,v]=b.dataset.tab.split(':');S.tab[k]=v;route();return}

 const f=ACT[b.dataset.act];if(f)f(b.dataset.id,b)});

document.addEventListener('input',e=>{const t=e.target;if(t.dataset.search){const q=t.value.toLowerCase();$$('#'+t.dataset.search+' tbody tr').forEach(tr=>tr.style.display=(tr.dataset.q||'').includes(q)?'':'none')}

 if(t.dataset.mk!=null&&PB.paper[t.dataset.mk])PB.paper[t.dataset.mk].marks=t.value});

document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!EX)closeModal()});

ACT.close=()=>closeModal();

// ---------- charts ----------

const PAL=['#0d9488','#6366f1','#f59e0b','#e11d48','#16a34a','#0ea5e9','#a855f7','#64748b','#f97316','#14b8a6'];

const CH=[];

function chart(cv,type,labels,vals,o={}){CH.push([cv,type,labels,vals,o]);draw(cv,type,labels,vals,o)}

function draw(cv,type,labels,vals,o){const dpr=window.devicePixelRatio||1,w=cv.clientWidth,h=cv.clientHeight;cv.width=w*dpr;cv.height=h*dpr;const g=cv.getContext('2d');g.scale(dpr,dpr);

 const cs=getComputedStyle(document.documentElement),fg=cs.getPropertyValue('--muted').trim(),gr=cs.getPropertyValue('--line').trim(),tx=cs.getPropertyValue('--text').trim();const reg=[];cv._reg=reg;

 const tot=vals.reduce((a,b)=>a+b,0);g.font='12px sans-serif';

 if(!vals.length||!tot){g.fillStyle=fg;g.font='14px sans-serif';g.textAlign='center';g.fillText('No data yet',w/2,h/2);return}

 if(type==='donut'){const cx=Math.min(w*.36,h/2+10),cy=h/2,R=Math.min(cx,h/2)-8,r=R*.6;let a0=-Math.PI/2;

  vals.forEach((v,i)=>{const a1=a0+v/tot*Math.PI*2;g.beginPath();g.arc(cx,cy,R,a0,a1);g.arc(cx,cy,r,a1,a0,true);g.closePath();g.fillStyle=PAL[i%PAL.length];g.fill();reg.push({k:'a',cx,cy,R,r,a0,a1,tip:`${labels[i]}: ${v} (${(v/tot*100).toFixed(1)}%)`});a0=a1});

  g.fillStyle=tx;g.font='bold 20px sans-serif';g.textAlign='center';g.fillText(tot,cx,cy+7);g.font='12px sans-serif';g.textAlign='left';

  labels.forEach((l,i)=>{const y=22+i*21;if(y>h-4)return;g.fillStyle=PAL[i%PAL.length];g.fillRect(cx*2+14,y-10,12,12);g.fillStyle=tx;g.fillText(`${l} (${vals[i]})`,cx*2+32,y)});return}

 const L=40,R2=12,Tp=14,B=36,pw=w-L-R2,ph=h-Tp-B,mx=o.max||Math.max(...vals)*1.18||1;

 g.strokeStyle=gr;g.fillStyle=fg;g.textAlign='right';for(let i=0;i<=4;i++){const y=Tp+ph-ph*i/4;g.beginPath();g.moveTo(L,y);g.lineTo(w-R2,y);g.stroke();g.fillText(Math.round(mx*i/4*10)/10,L-6,y+4)}

 const n=vals.length,bw=pw/n;g.textAlign='center';

 const lab=(i)=>{if(n>8&&i%Math.ceil(n/8))return;let t=String(labels[i]);if(t.length>9)t=t.slice(0,8)+'…';g.fillStyle=fg;g.fillText(t,L+bw*i+bw/2,h-14)};

 if(type==='bar'){vals.forEach((v,i)=>{const bh=ph*v/mx,x=L+bw*i+bw*.18,y=Tp+ph-bh,ww=bw*.64;const gd=g.createLinearGradient(0,y,0,y+bh);gd.addColorStop(0,o.c||PAL[i%PAL.length]);gd.addColorStop(1,(o.c||PAL[i%PAL.length])+'99');g.fillStyle=gd;g.beginPath();g.roundRect?g.roundRect(x,y,ww,bh,6):g.rect(x,y,ww,bh);g.fill();reg.push({k:'r',x,y,w:ww,h:bh,tip:`${labels[i]}: ${v}${o.u||''}`});lab(i)})}

 else{g.beginPath();vals.forEach((v,i)=>{const x=L+bw*i+bw/2,y=Tp+ph-ph*v/mx;i?g.lineTo(x,y):g.moveTo(x,y)});g.strokeStyle=o.c||PAL[1];g.lineWidth=2.5;g.stroke();g.lineWidth=1;

  g.lineTo(L+bw*(n-1)+bw/2,Tp+ph);g.lineTo(L+bw/2,Tp+ph);g.closePath();g.fillStyle=(o.c||PAL[1])+'22';g.fill();

  vals.forEach((v,i)=>{const x=L+bw*i+bw/2,y=Tp+ph-ph*v/mx;g.beginPath();g.arc(x,y,4,0,7);g.fillStyle=o.c||PAL[1];g.fill();reg.push({k:'c',x,y,tip:`${labels[i]}: ${v}`});lab(i)})}}

document.addEventListener('mousemove',e=>{const cv=e.target;const tip=$('#tip');if(!cv||cv.tagName!=='CANVAS'||!cv._reg){tip.style.display='none';return}

 const b=cv.getBoundingClientRect(),x=e.clientX-b.left,y=e.clientY-b.top;let hit=null;

 for(const r of cv._reg){if(r.k==='r'&&x>=r.x&&x<=r.x+r.w&&y>=r.y&&y<=r.y+r.h)hit=r;else if(r.k==='c'&&Math.hypot(x-r.x,y-r.y)<9)hit=r;else if(r.k==='a'){const dx=x-r.cx,dy=y-r.cy,d=Math.hypot(dx,dy);let an=Math.atan2(dy,dx);if(an<-Math.PI/2)an+=Math.PI*2;if(d>=r.r&&d<=r.R&&an>=r.a0&&an<=r.a1)hit=r}}

 if(hit){tip.textContent=hit.tip;tip.style.display='block';tip.style.left=e.clientX+12+'px';tip.style.top=e.clientY+12+'px'}else tip.style.display='none'});

let rz;window.addEventListener('resize',()=>{clearTimeout(rz);rz=setTimeout(()=>{CH.forEach(c=>{if(document.body.contains(c[0]))draw(...c)})},200)});

// ---------- auth ----------

async function boot(){try{S.boot=await api('boot');S.user=S.boot.user}catch(e){document.body.innerHTML='<p style="padding:2rem">Cannot reach the server.</p>';return}render()}

function render(){if(!S.boot)return;if(!S.boot.setup_complete)return authView('setup');if(!S.user){$('#app').innerHTML='';return authView('login')}if(!$('#main'))shell();route()}

function authView(mode){const b=S.boot;const tab=S.authTab||'login';

 const hero=`<div class="hero"><div class="logo">📝 EEMPS</div><h1>Electronic Examination Management Platform</h1><p style="opacity:.9">${esc(b.college)}</p><ul><li>Registration, timetabling and clash detection</li><li>Question bank &amp; secure timed online exams</li><li>Automatic + manual marking, moderation, release</li><li>Analysis dashboard with exports and full audit trail</li></ul></div>`;

 let form='';

 if(mode==='setup')form=`<h2>Welcome 👋 First-time setup</h2><div class="note">You are the <b>first person</b> to open this system, so you become its <b>Administrator</b>. Once created, setup locks permanently and no one else can claim the admin role.</div><form id="af">${fld({n:'college',l:'Institution name',d:b.college,req:1})}${fld({n:'full_name',l:'Your full name',req:1})}${fld({n:'username',l:'Admin username',req:1})}${fld({n:'email',l:'Email',t:'email'})}${fld({n:'password',l:'Password',t:'password',req:1,h:'At least 8 characters, letters and numbers'})}<button class="btn">Create administrator &amp; lock system</button></form>`;

 else if(tab==='login')form=`<h2>Sign in</h2><p class="muted">Use the account you registered with.</p><form id="af">${fld({n:'username',l:'Username',req:1})}${fld({n:'password',l:'Password',t:'password',req:1})}<button class="btn">Sign in</button></form>${b.allow_registration?'<p>No account? <a href="#" data-act="authtab" data-id="reg">Register here</a></p>':''}`;

 else form=`<h2>Create an account</h2><form id="af">${fld({n:'role',l:'I am a',t:'select',req:1,o:[['student','Student'],['lecturer','Lecturer'],['invigilator','Invigilator'],['officer','Examination Officer']]})}${fld({n:'full_name',l:'Full name',req:1})}${fld({n:'username',l:'Username',req:1})}${fld({n:'email',l:'Email',t:'email'})}

  <div id="stf" style="display:grid;gap:.9rem">${fld({n:'student_no',l:'Student number'})}${fld({n:'programme_id',l:'Programme',t:'select',o:b.programmes.map(p=>[p.id,p.code+' - '+p.name])})}${fld({n:'year_level',l:'Year of study',t:'number',min:1,max:6,d:1})}</div>

  ${fld({n:'password',l:'Password',t:'password',req:1,h:'At least 8 characters, letters and numbers'})}<div class="note info" id="pn" style="display:none">Staff accounts must be approved by the administrator before you can sign in.</div><button class="btn">Register</button></form><p>Already registered? <a href="#" data-act="authtab" data-id="login">Sign in</a></p>`;

 $('#app').innerHTML=`<div class="auth">${hero}<div class="panel"><div class="box">${form}</div></div></div>`;

 const f=$('#af');const rs=f.elements.role;if(rs){const upd=()=>{const s=rs.value==='student';$('#stf').style.display=s?'grid':'none';$('#pn').style.display=s?'none':'block'};rs.onchange=upd;upd()}

 f.onsubmit=async e=>{e.preventDefault();const d={};new FormData(f).forEach((v,k)=>d[k]=v);const act=mode==='setup'?'setup':(tab==='login'?'login':'register');

  const r=await call(act,d);if(!r)return;if(act==='register'){toast(r.status==='pending'?'Registered! Wait for administrator approval.':'Registered! You can sign in now.');S.authTab='login';authView('login');return}

  S.boot=await api('boot');S.user=S.boot.user;location.hash='home';render()}}

ACT.authtab=(id,b)=>{S.authTab=id;authView('login')};

document.addEventListener('click',e=>{if(e.target.matches('a[href="#"]'))e.preventDefault()});

async function logout(){await call('logout');S.user=null;$('#app').innerHTML='';S.boot=await api('boot');render()}

// ---------- shell ----------

function shell(){const u=S.user,m=MENU[u.role];

 $('#app').innerHTML=`<div class="shell"><aside id="side"><div class="brand"><i>📝</i> EEMPS</div><nav class="nav">${m.map(x=>`<a data-nav="${x[0]}" data-go="${x[0]}"><span>${x[2]}</span>${x[1]}</a>`).join('')}</nav>

 <div class="who"><b>${esc(u.full_name)}</b>${ROLES[u.role]}<br>${esc(S.boot.college)}</div></aside>

 <div class="content"><header><button class="ibtn" id="menu" style="display:none" data-act="menu">☰</button><h1 id="title"></h1><button class="ibtn" data-act="theme" title="Theme">🌓</button><button class="ibtn" data-go="notifications" title="Notifications">🔔<span class="badge" id="bd" style="display:none"></span></button><button class="ibtn" data-act="profile" title="My profile">👤</button><button class="btn ghost sm" data-act="logout">Sign out</button></header><main id="main"></main></div></div>`;

 setInterval(()=>{if(S.user&&!EX)bell()},30000)}

ACT.menu=()=>$('#side').classList.toggle('open');ACT.logout=logout;

ACT.theme=()=>{const d=document.documentElement.dataset.theme==='dark'?'':'dark';document.documentElement.dataset.theme=d;try{localStorage.setItem('eemps_theme',d)}catch(e){}CH.forEach(c=>{if(document.body.contains(c[0]))draw(...c)})};

try{document.documentElement.dataset.theme=localStorage.getItem('eemps_theme')||''}catch(e){}

async function bell(){try{const r=await api('notif_list');const b=$('#bd');if(b){b.style.display=r.unread?'block':'none';b.textContent=r.unread}}catch(e){}}

function go(p){if(location.hash.slice(1)===p)route();else location.hash=p;$('#side')?.classList.remove('open')}

window.addEventListener('hashchange',()=>{if(S.user&&!EX)route()});

const TITLES={notifications:'Notifications'};

async function route(){if(!S.user)return;let p=location.hash.slice(1)||'home';const m=MENU[S.user.role];if(!m.some(x=>x[0]===p)&&p!=='notifications')p='home';

 clearInterval(S.timer);CH.length=0;$$('[data-nav]').forEach(a=>a.classList.toggle('on',a.dataset.nav===p));const mi=m.find(x=>x[0]===p);$('#title').textContent=mi?mi[1]:TITLES[p]||'';

 main('<p class="muted">Loading...</p>');try{await PAGES[p]\()}catch(e){main(`<div class="card pad"><h3>Could not load this page</h3><p>${esc(e.message)}</p></div>`)}bell()}

// ---------- pages: common ----------

PAGES.home=async()=>{const h=await api('home');const u=S.user;

 main(`<div class="ph"><h2>Welcome back, ${esc(u.full_name.split(' ')[0])} 👋</h2><p class="muted">${ROLES[u.role]} dashboard${h.session?' - current session: <b>'+esc(h.session)+'</b>':''}</p></div>

 <div class="stats">${h.cards.map(c=>`<div class="stat ${c.c||''}" ${c.go?`data-go="${c.go}"`:''}><div class="n">${esc(c.n)}</div><div class="l">${esc(c.l)}</div></div>`).join('')}</div>

 <div class="cols">${h.lists.map(l=>`<div class="card pad"><h3>${esc(l.title)}</h3>${l.items.map(i=>`<div class="list-item" ${i.go?`data-go="${i.go}"`:''}><div class="t"><div>${esc(i.t)}</div><div class="muted">${esc(i.s||'')}</div></div>${i.tag?pill(i.tag):''}</div>`).join('')||'<p class="muted">Nothing to show yet.</p>'}</div>`).join('')}</div>`)};

PAGES.notifications=async()=>{const r=await api('notif_list');await api('notif_read');

 main(`<div class="ph"><h2>Notifications</h2></div><div class="card pad">${r.rows.map(n=>`<div class="list-item" style="cursor:default"><div class="t"><div>${n.is_read?'':'🔵 '}${esc(n.title)}</div><div class="muted">${esc(n.body||'')}</div></div><span class="muted">${esc(n.created_at)}</span></div>`).join('')||'<p class="muted">No notifications.</p>'}</div>`)};

ACT.profile=()=>{const u=S.user;formModal({title:'My profile',fields:[{n:'full_name',l:'Full name',req:1,w:1},{n:'email',l:'Email',t:'email'},{n:'phone',l:'Phone'}],values:u,onSave:async d=>{if(!await call('update_profile',d,'Profile updated'))return false;S.boot=await api('boot');S.user=S.boot.user},ok:'Save'});

 $('#mf .row').insertAdjacentHTML('afterbegin','<button type="button" class="btn ghost" data-act="chpw" style="margin-right:auto">Change password</button>')};

ACT.chpw=()=>formModal({title:'Change password',fields:[{n:'old',l:'Current password',t:'password',req:1,w:1},{n:'new',l:'New password',t:'password',req:1,w:1}],onSave:async d=>!!await call('change_password',d,'Password changed')&&undefined||false});

// ---------- admin: users ----------

PAGES.users=async()=>{const[us,pr]=await Promise.all([api('users_list'),api('list',{e:'programmes'})]);D.users=us.rows;D.programmes=pr.rows;const pend=D.users.filter(u=>u.status==='pending').length;

 main(`<div class="ph"><h2>Users</h2><p class="muted">${pend?`<b>${pend}</b> account(s) are waiting for your approval.`:'Create, approve and manage accounts.'}</p></div>`+dtable([

 {t:'Name',v:r=>r.full_name},{t:'Username',v:r=>r.username},{t:'Role',v:r=>ROLES[r.role],h:r=>`<span class="pill info">${ROLES[r.role]}</span>`},{t:'Status',v:r=>r.status,h:r=>pill(r.status)},{t:'Student No',v:r=>r.student_no||''},{t:'Programme',v:r=>r.programme||''},{t:'Email',v:r=>r.email||''},

 {t:'Actions',h:r=>r.role==='admin'?'<span class="muted">Owner</span>':`<div class="row">${r.status==='pending'?`<button class="btn xs" data-act="u_ok" data-id="${r.id}">Approve</button>`:''}${r.status==='active'?`<button class="btn ghost xs" data-act="u_off" data-id="${r.id}">Disable</button>`:''}${r.status==='disabled'?`<button class="btn ghost xs" data-act="u_ok" data-id="${r.id}">Enable</button>`:''}<button class="btn ghost xs" data-act="u_pw" data-id="${r.id}">Reset PW</button><button class="btn bad xs" data-act="u_del" data-id="${r.id}">Delete</button></div>`}],D.users,{name:'users',add:['u_add','＋ New user'],extra:'<a class="btn ghost sm" href="/export/users.csv">⬇ Server export</a>'}))};

ACT.u_add=()=>{formModal({title:'Create user',fields:[{n:'role',l:'Role',t:'select',req:1,o:[['student','Student'],['lecturer','Lecturer'],['invigilator','Invigilator'],['officer','Examination Officer']]},{n:'full_name',l:'Full name',req:1},{n:'username',l:'Username',req:1},{n:'password',l:'Temporary password',t:'password',req:1},{n:'email',l:'Email',t:'email'},{n:'phone',l:'Phone'},{n:'student_no',l:'Student number (students)'},{n:'programme_id',l:'Programme (students)',t:'select',o:D.programmes.map(p=>[p.id,p.code+' - '+p.name])},{n:'year_level',l:'Year (students)',t:'number',d:1}],onSave:async d=>{if(!await call('user_create',d,'User created'))return false;PAGES.users()}})};

ACT.u_ok=async id=>{if(await call('user_status',{id,status:'active'},'Account active'))PAGES.users()};

ACT.u_off=async id=>{if(confirm('Disable this account?')&&await call('user_status',{id,status:'disabled'},'Account disabled'))PAGES.users()};

ACT.u_del=async id=>{if(confirm('Delete this user permanently? (only possible if they have no exam records)')&&await call('user_delete',{id},'User deleted'))PAGES.users()};

ACT.u_pw=id=>formModal({title:'Reset password',fields:[{n:'password',l:'New temporary password',t:'password',req:1,w:1}],onSave:async d=>{if(!await call('user_reset_pw',{id,...d},'Password reset'))return false}});

// ---------- admin/officer: academic setup ----------

const ENT={

departments:{t:'Departments',one:'department',cols:()=>[{t:'Name',v:r=>r.name}],f:()=>[{n:'name',l:'Department name',req:1,w:1}]},

programmes:{t:'Programmes',one:'programme',cols:()=>[{t:'Code',v:r=>r.code},{t:'Name',v:r=>r.name},{t:'Department',v:r=>r.department}],f:()=>[{n:'department_id',l:'Department',t:'select',req:1,o:D.departments.map(x=>[x.id,x.name])},{n:'code',l:'Code (e.g. DICT)',req:1},{n:'name',l:'Programme name',req:1,w:1}]},

sessions:{t:'Sessions',one:'academic session',cols:()=>[{t:'Name',v:r=>r.name},{t:'Start',v:r=>r.start_date||''},{t:'End',v:r=>r.end_date||''},{t:'Current',v:r=>r.is_current?'Yes':'No',h:r=>r.is_current?'<span class="pill ok">Current</span>':`<button class="btn ghost xs" data-act="ent_cur" data-id="${r.id}">Make current</button>`}],f:()=>[{n:'name',l:'Session name (e.g. 2026 Term 3)',req:1,w:1},{n:'start_date',l:'Start',t:'date'},{n:'end_date',l:'End',t:'date'}]},

courses:{t:'Courses',one:'course',cols:()=>[{t:'Code',v:r=>r.code},{t:'Title',v:r=>r.title},{t:'Programme',v:r=>r.pcode},{t:'Lecturer',v:r=>r.lecturer||'-'},{t:'Credits',v:r=>r.credits}],f:()=>[{n:'programme_id',l:'Programme',t:'select',req:1,o:D.programmes.map(x=>[x.id,x.code+' - '+x.name])},{n:'code',l:'Course code',req:1},{n:'title',l:'Course title',req:1,w:1},{n:'lecturer_id',l:'Lecturer',t:'select',o:D.lecturers.map(x=>[x.id,x.full_name])},{n:'credits',l:'Credits',t:'number',d:3,step:.5}]},

venues:{t:'Venues',one:'venue',cols:()=>[{t:'Venue',v:r=>r.name},{t:'Capacity',v:r=>r.capacity}],f:()=>[{n:'name',l:'Venue / laboratory',req:1},{n:'capacity',l:'Capacity (seats)',t:'number',req:1,min:1}]},

grades:{t:'Grading scale',one:'grade',cols:()=>[{t:'Grade',v:r=>r.grade},{t:'Minimum %',v:r=>r.min_pct},{t:'Remark',v:r=>r.remark||''}],f:()=>[{n:'grade',l:'Grade',req:1},{n:'min_pct',l:'Minimum percentage',t:'number',req:1,min:0,max:100,step:.5},{n:'remark',l:'Remark',w:1}]}};

async function entPage(names,title,sub){const need=['departments','programmes','sessions','courses','venues','grades'];const res=await Promise.all(need.map(e=>api('list',{e})));need.forEach((e,i)=>D[e]=res[i].rows);

 if(S.user.role==='admin')D.lecturers=(await api('list',{e:'lecturers'})).rows;else D.lecturers=[];

 const k='ent'+names[0];if(!names.includes(S.tab[k]))S.tab[k]=names[0];S.ent=S.tab[k];const e=ENT[S.ent];

 main(`<div class="ph"><h2>${title}</h2><p class="muted">${sub}</p></div>${names.length>1?`<div class="tabs">${names.map(n=>`<div class="tab ${n===S.ent?'on':''}" data-tab="${k}:${n}">${ENT[n].t}</div>`).join('')}</div>`:''}`+

 dtable(e.cols().concat([{t:'',h:r=>`<div class="row"><button class="btn ghost xs" data-act="ent_edit" data-id="${r.id}">Edit</button><button class="btn bad xs" data-act="ent_del" data-id="${r.id}">Delete</button></div>`}]),D[S.ent],{name:S.ent,add:['ent_edit','＋ Add '+e.one,'']}))}

PAGES.academic=()=>entPage(['departments','programmes','sessions','courses','venues','grades'],'Academic Setup','Departments, programmes, sessions, courses, venues and the grading scale - everything else links to these.');

PAGES.venues=()=>entPage(['venues'],'Venues','Examination rooms and laboratories with their seating capacity.');

ACT.ent_edit=id=>{const e=ENT[S.ent],r=id?byId(D[S.ent],id):null;formModal({title:(r?'Edit ':'Add ')+e.one,fields:e.f(),values:r||{},onSave:async d=>{if(!await call('ent_save',{...d,e:S.ent,id:r?r.id:null},'Saved'))return false;route()}})};

ACT.ent_del=async id=>{if(confirm('Delete this record?')&&await call('ent_delete',{e:S.ent,id},'Deleted'))route()};

ACT.ent_cur=async id=>{if(await call('session_current',{id},'Current session updated'))route()};

// ---------- lecturer: courses, question bank ----------

PAGES.courses=async()=>{const r=await api('my_courses');main(`<div class="ph"><h2>My Courses</h2><p class="muted">Courses assigned to you by the administrator.</p></div>`+dtable([{t:'Code',v:r=>r.code},{t:'Title',v:r=>r.title},{t:'Programme',v:r=>r.pcode},{t:'Credits',v:r=>r.credits},{t:'Questions',v:r=>r.nq},{t:'Registered students',v:r=>r.nstudents}],r.rows,{name:'my_courses'}))};

PAGES.bank=async()=>{D.mycourses=(await api('my_courses')).rows;const cid=S.f.qc||'';const r=await api('q_list',{course_id:cid||null});D.qs=r.rows;const TN={mcq:'Multiple choice',tf:'True/False',fill:'Fill-in',essay:'Essay'};

 main(`<div class="ph"><h2>Question Bank</h2><p class="muted">Reusable questions by course, topic, type and difficulty.</p></div><div class="row" style="margin-bottom:.8rem"><select id="qcf" style="max-width:300px"><option value="">All my courses</option>${D.mycourses.map(c=>`<option value="${c.id}" ${String(c.id)===String(cid)?'selected':''}>${esc(c.code)} - ${esc(c.title)}</option>`).join('')}</select></div>`+

 dtable([{t:'Course',v:r=>r.code},{t:'Type',v:r=>TN[r.qtype]},{t:'Question',v:r=>r.text,h:r=>esc(r.text.length>110?r.text.slice(0,110)+'…':r.text)},{t:'Topic',v:r=>r.topic||''},{t:'Difficulty',v:r=>r.difficulty},{t:'Marks',v:r=>r.marks},{t:'',h:r=>`<div class="row"><button class="btn ghost xs" data-act="q_edit" data-id="${r.id}">Edit</button><button class="btn bad xs" data-act="q_del" data-id="${r.id}">Delete</button></div>`}],D.qs,{name:'questions',add:['q_edit','＋ New question','']}));

 $('#qcf').onchange=e=>{S.f.qc=e.target.value;PAGES.bank()}};

ACT.q_edit=id=>{const q=id?byId(D.qs,id):null;const v=q||{qtype:'mcq',marks:1,difficulty:'medium',options:['','','',''],course_id:S.f.qc||(D.mycourses[0]||{}).id,answer:'0'};if(!D.mycourses.length)return toast('No course is assigned to you yet','err');

 const opts=[...v.options];while(opts.length<4)opts.push('');

 openModal(`<form id="qf"><h3>${q?'Edit':'New'} question</h3><div class="grid2">

 ${fld({n:'course_id',l:'Course',t:'select',req:1,o:D.mycourses.map(c=>[c.id,c.code+' - '+c.title])},v.course_id)}${fld({n:'topic',l:'Topic'},v.topic)}

 ${fld({n:'qtype',l:'Type',t:'select',req:1,o:[['mcq','Multiple choice'],['tf','True / False'],['fill','Fill in the blank'],['essay','Essay (manual marking)']]},v.qtype)}${fld({n:'difficulty',l:'Difficulty',t:'select',req:1,o:[['easy','Easy'],['medium','Medium'],['hard','Hard']]},v.difficulty)}

 ${fld({n:'marks',l:'Marks',t:'number',req:1,min:.5,step:.5},v.marks)}<span></span>${fld({n:'text',l:'Question',t:'textarea',req:1,w:1,rows:3},v.text)}

 <div class="w2" id="g_mcq">${opts.map((o,i)=>`<div class="row" style="margin:.3rem 0"><input type="radio" name="mc" value="${i}" style="width:auto" ${String(v.answer)===String(i)?'checked':''}><input class="mo" placeholder="Option ${'ABCD'[i]}" value="${esc(o)}"></div>`).join('')}<small class="muted">Select the radio button of the correct option.</small></div>

 <div class="w2" id="g_tf">${fld({n:'tfa',l:'Correct answer',t:'select',o:[['True','True'],['False','False']],req:1},v.answer)}</div>

 <div class="w2" id="g_fill">${fld({n:'fa',l:'Accepted answer(s)',h:'Separate alternatives with |  e.g.  select | SELECT statement'},v.qtype==='fill'?v.answer:'')}</div>

 <div class="w2" id="g_essay">${fld({n:'ea',l:'Marking guide / model answer',t:'textarea',rows:3},v.qtype==='essay'?v.answer:'')}</div></div>

 <div class="row end"><button type="button" class="btn ghost" data-act="close">Cancel</button><button class="btn">Save question</button></div></form>`,true);

 const f=$('#qf'),sw=()=>{['mcq','tf','fill','essay'].forEach(t=>$('#g_'+t).style.display=f.elements.qtype.value===t?'block':'none')};f.elements.qtype.onchange=sw;sw();

 f.onsubmit=async e=>{e.preventDefault();const t=f.elements.qtype.value;const d={id:q?q.id:null,course_id:f.elements.course_id.value,topic:f.elements.topic.value,qtype:t,difficulty:f.elements.difficulty.value,marks:f.elements.marks.value,text:f.elements.text.value};

  if(t==='mcq'){d.options=$$('.mo',f).map(x=>x.value);d.answer=(f.querySelector('[name=mc]:checked')||{}).value||''}else if(t==='tf')d.answer=f.elements.tfa.value;else if(t==='fill')d.answer=f.elements.fa.value;else d.answer=f.elements.ea.value;

  if(await call('q_save',d,'Question saved')){closeModal();PAGES.bank()}}};

ACT.q_del=async id=>{if(confirm('Delete this question?')&&await call('q_delete',{id},'Deleted'))PAGES.bank()};

// ---------- exams (lecturer + officer) ----------

PAGES.exams=async()=>{const r=await api('exam_list');D.exams=r.rows;const lec=S.user.role==='lecturer';if(lec){D.mycourses=(await api('my_courses')).rows;D.sessions=(await api('list',{e:'sessions'})).rows}

 main(`<div class="ph"><h2>${lec?'Exams & Papers':'Exam Papers'}</h2><p class="muted">${lec?'Create an exam, build its paper from your question bank, then submit it for approval.':'Review papers submitted by lecturers. Approved papers can be scheduled in the Timetable.'}</p></div>`+

 dtable([{t:'Exam',v:r=>r.title},{t:'Course',v:r=>r.code},{t:'Lecturer',v:r=>r.lecturer||''},{t:'Session',v:r=>r.session},{t:'Duration',v:r=>r.duration_min+' min'},{t:'Questions',v:r=>r.nq},{t:'Marks',v:r=>r.total_marks},{t:'Status',v:r=>r.status,h:r=>pill(r.status)+(r.review_note?`<div class="muted" style="font-size:12px">${esc(r.review_note)}</div>`:'')},{t:'Scheduled',v:r=>r.start_time||'-'},

 {t:'',h:r=>lec?`<div class="row"><button class="btn ghost xs" data-act="ex_edit" data-id="${r.id}" ${['draft','rejected'].includes(r.status)?'':'disabled'}>Settings</button><button class="btn ind xs" data-act="pb_open" data-id="${r.id}">Paper</button>${['draft','rejected'].includes(r.status)?`<button class="btn xs" data-act="ex_sub" data-id="${r.id}">Submit</button><button class="btn bad xs" data-act="ex_del" data-id="${r.id}">✕</button>`:''}</div>`:`<div class="row"><button class="btn ind xs" data-act="ex_rev" data-id="${r.id}">${r.status==='pending'?'Review':'View'}</button></div>`}],D.exams,lec?{name:'exams',add:['ex_edit','＋ New exam','']}:{name:'exams'}))};

ACT.ex_edit=id=>{const r=id?byId(D.exams,id):null;if(!D.mycourses.length)return toast('No course assigned to you yet','err');const cur=D.sessions.find(s=>s.is_current);

 formModal({title:r?'Exam settings':'New exam',fields:[{n:'course_id',l:'Course',t:'select',req:1,o:D.mycourses.map(c=>[c.id,c.code+' - '+c.title])},{n:'session_id',l:'Academic session',t:'select',req:1,o:D.sessions.map(s=>[s.id,s.name]),d:cur?cur.id:''},{n:'title',l:'Exam title',req:1,w:1,ph:'e.g. ICT101 End of Term Exam'},{n:'duration_min',l:'Duration (minutes)',t:'number',req:1,min:5,max:480,d:60},{n:'pass_pct',l:'Pass mark (%)',t:'number',req:1,min:0,max:100,d:40},{n:'shuffle',l:'Randomise question order',t:'select',req:1,o:[['1','Yes'],['0','No']],d:'1'},{n:'instructions',l:'Instructions to students',t:'textarea',w:1,rows:3}],values:r||{},onSave:async d=>{if(!await call('exam_save',{...d,id:r?r.id:null},'Exam saved'))return false;PAGES.exams()}})};

ACT.ex_sub=async id=>{if(confirm('Submit this paper to the examination officer? You will not be able to edit it afterwards.')&&await call('exam_submit',{id},'Submitted for approval'))PAGES.exams()};

ACT.ex_del=async id=>{if(confirm('Delete this exam?')&&await call('exam_delete',{id},'Deleted'))PAGES.exams()};

let PB={};

ACT.pb_open=async id=>{const r=await call('exam_paper',{exam_id:+id});if(!r)return;PB={ex:r.exam,paper:r.paper,bank:r.bank,locked:!['draft','rejected'].includes(r.exam.status)};pbDraw()};

function pbDraw(){const{ex,paper,bank,locked}=PB;const tot=paper.reduce((a,q)=>a+(+q.marks||0),0);const sn=t=>esc(t.length>80?t.slice(0,80)+'…':t);

 openModal(`<div class="pb"><h3>Paper builder - ${esc(ex.title)}</h3><p class="muted">${pill(ex.status)} &nbsp; <b>${paper.length}</b> question(s) &middot; <b>${tot}</b> total marks ${locked?' &middot; paper is locked':''}</p><div class="cols2">

 <div><h4>Question bank (${bank.length})</h4>${locked?'':`<div class="row" style="margin-bottom:.4rem"><select id="rt" style="width:auto"><option value="">Any type</option><option value="mcq">MCQ</option><option value="tf">T/F</option><option value="fill">Fill-in</option><option value="essay">Essay</option></select><input id="rn" type="number" min="1" value="3" style="width:70px"><button class="btn ghost sm" data-act="pb_rand">🎲 Add random</button><button class="btn ghost sm" data-act="pb_all">Add all</button></div>`}

 <div class="list">${bank.map((q,i)=>`<div class="qi"><span class="tag">${q.qtype}</span><span style="flex:1">${sn(q.text)}</span><b>${q.marks}</b>${locked?'':`<button class="btn xs" data-act="pb_add" data-id="${i}">＋</button>`}</div>`).join('')||'<p class="muted pad">No more questions for this course.</p>'}</div></div>

 <div><h4>In this paper</h4><div class="list">${paper.map((q,i)=>`<div class="qi"><b>${i+1}.</b><span class="tag">${q.qtype}</span><span style="flex:1">${sn(q.text)}</span>${locked?`<b>${q.marks}</b>`:`<input class="mk" type="number" step="0.5" min="0.5" data-mk="${i}" value="${q.marks}"><button class="btn bad xs" data-act="pb_rm" data-id="${i}">✕</button>`}</div>`).join('')||'<p class="muted pad">Empty - add questions from the bank.</p>'}</div></div></div>

 <div class="row end"><button class="btn ghost" data-act="close">Close</button>${locked?'':'<button class="btn" data-act="pb_save">Save paper</button>'}</div></div>`,true)}

ACT.pb_add=i=>{PB.paper.push(PB.bank.splice(+i,1)[0]);pbDraw()};ACT.pb_rm=i=>{PB.bank.unshift(PB.paper.splice(+i,1)[0]);pbDraw()};ACT.pb_all=()=>{PB.paper.push(...PB.bank.splice(0));pbDraw()};

ACT.pb_rand=()=>{const t=$('#rt').value,n=+$('#rn').value||1;const pool=PB.bank.filter(q=>!t||q.qtype===t).sort(()=>Math.random()-.5).slice(0,n);pool.forEach(q=>{PB.bank.splice(PB.bank.indexOf(q),1);PB.paper.push(q)});pbDraw()};

ACT.pb_save=async()=>{if(await call('exam_set_questions',{exam_id:PB.ex.id,items:PB.paper.map(q=>({question_id:q.id,marks:q.marks}))},'Paper saved')){closeModal();PAGES.exams()}};

ACT.ex_rev=async id=>{const r=await call('exam_paper',{exam_id:+id});if(!r)return;const ex=r.exam,TN={mcq:'MCQ',tf:'T/F',fill:'Fill-in',essay:'Essay'};

 openModal(`<h3>${esc(ex.title)} ${pill(ex.status)}</h3><p class="muted">${esc(ex.code)} - ${esc(ex.ctitle)} &middot; ${esc(ex.lecturer||'')} &middot; ${ex.duration_min} min &middot; ${ex.total_marks} marks &middot; pass ${ex.pass_pct}%</p>

 ${r.paper.map((q,i)=>`<div class="qcard"><b>${i+1}. [${TN[q.qtype]} - ${q.marks} mk]</b> ${esc(q.text)}${q.qtype==='mcq'?'<ol type="A">'+q.options.map(o=>`<li>${esc(o)}</li>`).join('')+'</ol>':''}<div class="muted">Answer: ${esc(q.qtype==='mcq'?'ABCDEF'[+q.answer]:q.answer)}</div></div>`).join('')||'<p class="muted">No questions.</p>'}

 ${ex.status==='pending'?`<form id="rf"><div class="grid2">${fld({n:'note',l:'Comment (required when rejecting)',t:'textarea',w:1})}</div><div class="row end"><button type="button" class="btn ghost" data-act="close">Close</button><button class="btn bad" data-d="reject">Reject</button><button class="btn" data-d="approve">Approve paper</button></div></form>`:'<div class="row end"><button class="btn ghost" data-act="close">Close</button></div>'}`,true);

 const f=$('#rf');if(f)f.onsubmit=async e=>{e.preventDefault();const d=e.submitter.dataset.d;if(await call('exam_review',{id:ex.id,decision:d,note:f.elements.note.value},d==='approve'?'Paper approved':'Paper rejected')){closeModal();PAGES.exams()}}};

// ---------- timetable ----------

PAGES.timetable=async()=>{const r=await api('timetable');D.sched=r.rows;const role=S.user.role,off=role==='officer';

 main(`<div class="ph"><h2>${role==='invigilator'?'My Invigilation Assignments':'Examination Timetable'}</h2><p class="muted">${off?'Schedule approved papers. The system blocks venue, invigilator and programme clashes and checks venue capacity.':'Dates, venues and exam windows.'}</p></div>`+

 dtable([{t:'Start',v:r=>r.start_time},{t:'End',v:r=>r.end_time},{t:'Course',v:r=>r.code+' '+r.ctitle},{t:'Exam',v:r=>r.title},{t:'Venue',v:r=>r.venue},{t:'Invigilator',v:r=>r.invigilator},{t:'Programme',v:r=>r.programme},{t:'Students',v:r=>r.registered},{t:'Duration',v:r=>r.duration_min+' min'},{t:'State',v:r=>r.state,h:r=>pill(r.state)}]

 .concat(off?[{t:'',h:r=>`<div class="row"><button class="btn ghost xs" data-act="sc_edit" data-id="${r.sid}">Edit</button><button class="btn bad xs" data-act="sc_del" data-id="${r.sid}">✕</button></div>`}]:[]),D.sched.map(x=>({...x,id:x.sid})),off?{name:'timetable',add:['sc_edit','＋ Schedule exam','']}:{name:'timetable'}))};

ACT.sc_edit=async id=>{const[ex,vn,iv]=await Promise.all([api('exam_list'),api('list',{e:'venues'}),api('list',{e:'invigilators'})]);const s=id?byId(D.sched.map(x=>({...x,id:x.sid})),id):null;

 const ap=ex.rows.filter(e=>e.status==='approved'&&(s?e.id===s.exam_id:!e.sid));if(!ap.length&&!s)return toast('No approved, unscheduled papers. Approve a paper first.','err');

 formModal({title:s?'Reschedule exam':'Schedule exam',fields:[{n:'exam_id',l:'Approved exam',t:'select',req:1,w:1,o:ap.map(e=>[e.id,`${e.code} - ${e.title} (${e.duration_min} min)`])},{n:'venue_id',l:'Venue',t:'select',req:1,o:vn.rows.map(v=>[v.id,`${v.name} (${v.capacity} seats)`])},{n:'invigilator_id',l:'Invigilator',t:'select',req:1,o:iv.rows.map(v=>[v.id,v.full_name])},{n:'start_time',l:'Window opens',t:'datetime-local',req:1},{n:'end_time',l:'Window closes',t:'datetime-local',req:1,h:'Students may start any time in this window; each has the full duration, capped at closing time.'}],

 values:s?{...s,start_time:s.start_time.replace(' ','T'),end_time:s.end_time.replace(' ','T')}:{},onSave:async d=>{if(!await call('schedule_save',d,'Exam scheduled - students notified'))return false;PAGES.timetable()}})};

ACT.sc_del=async id=>{if(confirm('Remove this exam from the timetable?')&&await call('schedule_delete',{id},'Removed'))PAGES.timetable()};

// ---------- student ----------

PAGES.register=async()=>{const r=await api('reg_options');D.rc=r.courses;const n=r.courses.filter(c=>c.registered).length;

 main(`<div class="ph"><h2>Course Registration</h2><p class="muted">Session: <b>${esc(r.session.name)}</b> &middot; registered for <b>${n}</b> of ${r.courses.length} course(s). You can only write exams for courses you register.</p></div>

 <div class="stats">${r.courses.map(c=>`<div class="stat ${c.registered?'green':''}"><div style="font-weight:700;font-size:16px">${esc(c.code)}</div><div>${esc(c.title)}</div><div class="muted">${esc(c.lecturer||'No lecturer yet')} &middot; ${c.credits} credits</div><div style="margin-top:.7rem"><button class="btn ${c.registered?'ghost':''} sm" data-act="reg_t" data-id="${c.id}">${c.registered?'✔ Registered - Unregister':'Register'}</button></div></div>`).join('')||'<p class="muted">No courses available for your programme yet.</p>'}</div>`)};

ACT.reg_t=async id=>{const c=byId(D.rc,id);if(await call('reg_toggle',{course_id:+id,register:!c.registered},c.registered?'Unregistered':'Registered'))PAGES.register()};

PAGES.myexams=async()=>{const r=await api('my_exams');D.me=r.rows.map(x=>({...x,id:x.exam_id}));

 main(`<div class="ph"><h2>My Exams</h2><p class="muted">Exams for your registered courses. The exam window must be open to start. Stay on the exam page - leaving it is recorded.</p></div><div class="stats" style="grid-template-columns:repeat(auto-fit,minmax(300px,1fr))">${D.me.map(x=>`<div class="stat ${x.state==='open'||x.state==='in_progress'?'green':x.state==='missed'?'rose':'indigo'}"><div class="row" style="justify-content:space-between"><b>${esc(x.code)}</b>${pill(x.state)}</div><div style="font-size:17px;font-weight:700;margin:.3rem 0">${esc(x.title)}</div><div class="muted">🗓 ${esc(x.start_time)} → ${esc(x.end_time)}<br>📍 ${esc(x.venue)} &middot; ⏱ ${x.duration_min} min</div>

 <div style="margin-top:.8rem">${x.state==='open'?`<button class="btn" data-act="ex_go" data-id="${x.exam_id}">Start exam</button>`:x.state==='in_progress'?`<button class="btn amb" data-act="ex_go" data-id="${x.exam_id}">Resume exam</button>`:x.state==='submitted'?'<span class="muted">Submitted ✔ - results appear after approval</span>':x.state==='upcoming'?'<span class="muted">Opens at the time shown</span>':'<span class="muted">Window closed</span>'}</div></div>`).join('')||'<p class="muted">No exams scheduled for your courses yet.</p>'}</div>`)};

ACT.ex_go=id=>{const x=byId(D.me,id);openModal(`<h3>${esc(x.title)}</h3><p class="muted">${esc(x.code)} - ${esc(x.ctitle)}</p><div class="note info">Duration <b>${x.duration_min} minutes</b>. The timer starts now and cannot be paused. Answers auto-save and the exam submits automatically when time ends. Only one session is allowed; leaving the page is logged.</div>${x.instructions?`<p><b>Instructions:</b> ${esc(x.instructions)}</p>`:''}<div class="row end"><button class="btn ghost" data-act="close">Cancel</button><button class="btn" data-act="ex_begin" data-id="${id}">I understand - begin</button></div>`)};

ACT.ex_begin=async id=>{const p=await call('exam_start',{exam_id:+id});if(!p)return;closeModal();startExam(p)};

PAGES.myresults=async()=>{const r=await api('my_results');D.mr=r.rows;main(`<div class="ph"><h2>My Results</h2><p class="muted">Only approved and released results are shown.</p></div>`+dtable([{t:'Course',v:r=>r.code+' '+r.ctitle},{t:'Exam',v:r=>r.exam},{t:'Score',v:r=>`${r.total}/${r.max_marks}`},{t:'%',v:r=>r.pct},{t:'Grade',v:r=>r.grade,h:r=>`<b>${esc(r.grade)}</b> <span class="muted">${esc(r.remark||'')}</span>`},{t:'Outcome',v:r=>r.passed?'Passed':'Failed',h:r=>pill(r.passed?'passed':'failed')},{t:'Released',v:r=>r.released_at},

 {t:'',h:r=>`<div class="row"><button class="btn ghost xs" data-act="mr_view" data-id="${r.id}">Details</button><button class="btn ghost xs" data-act="mr_slip" data-id="${r.id}">🖨 Slip</button>${r.appeal==='pending'?'<span class="pill warn">Appeal pending</span>':`<button class="btn amb xs" data-act="ap_new" data-id="${r.id}">Appeal</button>`}</div>`}],D.mr,{name:'my_results'}))};

async function detail(id){const r=await call('result_detail',{id:+id});if(!r)return null;const x=r.result;return{x,items:r.items,html:`<table><thead><tr><th>#</th><th>Question</th><th>Your answer</th><th>Score</th><th>Comment</th></tr></thead><tbody>${r.items.map((i,n)=>`<tr><td>${n+1}</td><td>${esc(i.text)}</td><td>${esc(i.answer||'(blank)')}</td><td>${i.score??'-'}/${i.marks}</td><td>${esc(i.comment||'')}</td></tr>`).join('')}</tbody></table>`}}

ACT.mr_view=async id=>{const d=await detail(id);if(!d)return;openModal(`<h3>${esc(d.x.exam)}</h3><p class="muted">${esc(d.x.student)} &middot; ${d.x.total}/${d.x.max_marks} (${d.x.pct}%) &middot; Grade <b>${esc(d.x.grade)}</b></p><div class="scroll">${d.html}</div><div class="row end"><button class="btn ghost" data-act="close">Close</button></div>`,true)};

ACT.mr_slip=async id=>{const d=await detail(id);if(!d)return;printHTML('Result slip',`<p><b>${esc(d.x.student)}</b> (${esc(d.x.student_no||'')}) - ${esc(d.x.programme||'')}</p><p>${esc(d.x.code)} ${esc(d.x.ctitle)} - ${esc(d.x.exam)}</p><p>Score: <b>${d.x.total}/${d.x.max_marks}</b> &nbsp; Percentage: <b>${d.x.pct}%</b> &nbsp; Grade: <b>${esc(d.x.grade)}</b> &nbsp; Outcome: <b>${d.x.passed?'PASS':'FAIL'}</b></p>${d.html}`)};

ACT.ap_new=id=>formModal({title:'Request a result review',intro:'Explain why you believe your result should be reviewed.',fields:[{n:'reason',l:'Reason',t:'textarea',req:1,w:1,rows:4}],ok:'Submit appeal',onSave:async d=>{if(!await call('appeal_create',{attempt_id:+id,...d},'Appeal submitted'))return false;PAGES.myresults()}});

// ---------- appeals ----------

PAGES.appeals=async()=>{const r=await api('appeal_list');D.ap=r.rows;const off=S.user.role==='officer';

 main(`<div class="ph"><h2>${S.user.role==='student'?'My Appeals':'Result Appeals'}</h2></div>`+dtable([{t:'Date',v:r=>r.created_at},{t:'Student',v:r=>r.student+' ('+(r.student_no||'')+')'},{t:'Exam',v:r=>r.code+' '+r.exam},{t:'Current',v:r=>`${r.total}/${r.max_marks} (${r.grade})`},{t:'Reason',v:r=>r.reason},{t:'Status',v:r=>r.status,h:r=>pill(r.status)},{t:'Response',v:r=>r.response||''}].concat(off?[{t:'',h:r=>r.status==='pending'?`<button class="btn xs" data-act="ap_h" data-id="${r.id}">Respond</button>`:''}]:[]),D.ap,{name:'appeals'}))};

ACT.ap_h=id=>{const a=byId(D.ap,id);formModal({title:'Respond to appeal',intro:`${a.student} - ${a.exam}. Current total ${a.total}/${a.max_marks}. Reason: ${a.reason}`,fields:[{n:'decision',l:'Decision',t:'select',req:1,o:[['accept','Accept'],['reject','Reject']]},{n:'new_total',l:'Corrected total (if accepted)',t:'number',step:.5,min:0,max:a.max_marks},{n:'response',l:'Response to student',t:'textarea',req:1,w:1}],onSave:async d=>{if(!await call('appeal_handle',{id:a.id,...d},'Appeal handled'))return false;PAGES.appeals()}})};

// ---------- marking ----------

PAGES.marking=async()=>{const ex=(await api('exam_list')).rows;const r=await api('mark_list',{exam_id:S.f.me||null,pending:S.f.mp!=='all'});D.ml=r.rows;

 main(`<div class="ph"><h2>Marking</h2><p class="muted">Objective questions are marked automatically. Mark essay answers here; the total, grade and pass/fail update instantly.</p></div><div class="row" style="margin-bottom:1rem"><select id="mex" style="max-width:300px"><option value="">All my exams</option>${ex.map(e=>`<option value="${e.id}" ${String(e.id)===String(S.f.me)?'selected':''}>${esc(e.code)} - ${esc(e.title)}</option>`).join('')}</select><select id="mpd" style="max-width:200px"><option value="pend">Pending only</option><option value="all" ${S.f.mp==='all'?'selected':''}>All essay answers</option></select></div>

 ${D.ml.map(a=>`<div class="qcard"><div class="row" style="justify-content:space-between"><b>${esc(a.student)} <span class="muted">${esc(a.student_no||'')}</span></b><span>${esc(a.code)} - ${esc(a.exam)} ${a.marked?pill('marked'):pill('pending')}</span></div><p><b>Q:</b> ${esc(a.qtext)}</p><div class="ans">${esc(a.answer)}</div>${a.guide?`<p class="muted"><b>Guide:</b> ${esc(a.guide)}</p>`:''}

 <div class="row" style="margin-top:.6rem"><input type="number" id="sc${a.id}" step="0.5" min="0" max="${a.maxm}" value="${a.score??''}" placeholder="Score" style="width:110px"><span class="muted">/ ${a.maxm}</span><input id="cm${a.id}" value="${esc(a.comment||'')}" placeholder="Comment for the student" style="flex:1;min-width:200px"><button class="btn sm" data-act="mk_save" data-id="${a.id}">Save mark</button></div></div>`).join('')||'<div class="card pad"><p class="muted">🎉 No essay answers waiting for marking.</p></div>'}`);

 $('#mex').onchange=e=>{S.f.me=e.target.value;PAGES.marking()};$('#mpd').onchange=e=>{S.f.mp=e.target.value==='all'?'all':'p';PAGES.marking()}};

ACT.mk_save=async id=>{const r=await call('mark_save',{id:+id,score:$('#sc'+id).value,comment:$('#cm'+id).value},'Mark saved');if(r){const a=byId(D.ml,id);a.marked=1}};

// ---------- results ----------

PAGES.results=async()=>{const ex=(await api('exam_list')).rows;const eid=S.f.re||'';const r=await api('result_list',{exam_id:eid||null});D.rs=r.rows;const off=S.user.role==='officer';

 const cnt=s=>D.rs.filter(x=>x.result_state===s).length;

 main(`<div class="ph"><h2>Results</h2><p class="muted">Workflow: marked → <b>approved</b> by the examination officer → <b>released</b> to students.</p></div>

 <div class="row" style="margin-bottom:1rem"><select id="rex" style="max-width:340px"><option value="">All exams</option>${ex.map(e=>`<option value="${e.id}" ${String(e.id)===String(eid)?'selected':''}>${esc(e.code)} - ${esc(e.title)}</option>`).join('')}</select>

 <span class="pill">${cnt('pending')} awaiting marking</span><span class="pill info">${cnt('marked')} marked</span><span class="pill warn">${cnt('approved')} approved</span><span class="pill ok">${cnt('released')} released</span>

 ${off&&eid?`<button class="btn amb sm" data-act="rs_ap">✔ Approve marked results</button><button class="btn sm" data-act="rs_rel">📢 Release approved results</button>`:''}</div>`+

 dtable([{t:'Student No',v:r=>r.student_no||''},{t:'Student',v:r=>r.student},{t:'Course',v:r=>r.code},{t:'Exam',v:r=>r.exam},{t:'Score',v:r=>r.total==null?'':`${r.total}/${r.max_marks}`},{t:'%',v:r=>r.pct??''},{t:'Grade',v:r=>r.grade||''},{t:'Outcome',v:r=>r.passed==null?'':(r.passed?'Pass':'Fail'),h:r=>r.passed==null?'':pill(r.passed?'passed':'failed')},{t:'Tab leaves',v:r=>r.leave_count,h:r=>r.leave_count>=3?`<span class="pill bad">${r.leave_count}</span>`:r.leave_count},{t:'State',v:r=>r.result_state,h:r=>pill(r.result_state)},{t:'',h:r=>`<button class="btn ghost xs" data-act="rs_view" data-id="${r.id}">Script</button>`}],D.rs,{name:'results',extra:`<a class="btn ghost sm" href="/export/results.csv${eid?'?exam_id='+eid:''}">⬇ Server export</a>`}));

 $('#rex').onchange=e=>{S.f.re=e.target.value;PAGES.results()}};

ACT.rs_view=async id=>{const r=await call('result_detail',{id:+id});if(!r)return;const x=r.result;openModal(`<h3>${esc(x.student)} - ${esc(x.exam)}</h3><p class="muted">${x.total==null?'Not fully marked':`${x.total}/${x.max_marks} (${x.pct}%) - Grade ${esc(x.grade)}`}</p><div class="scroll"><table><thead><tr><th>#</th><th>Question</th><th>Answer</th><th>Score</th><th>Comment</th></tr></thead><tbody>${r.items.map((i,n)=>`<tr><td>${n+1}</td><td>${esc(i.text)}</td><td>${esc(i.answer||'(blank)')}</td><td>${i.score??'-'}/${i.marks}</td><td>${esc(i.comment||'')}</td></tr>`).join('')}</tbody></table></div><div class="row end"><button class="btn ghost" data-act="close">Close</button></div>`,true)};

ACT.rs_ap=async()=>{const r=await call('result_approve',{exam_id:+S.f.re});if(r){toast(`${r.approved} result(s) approved`+(r.still_pending?` - ${r.still_pending} still awaiting marking`:''));PAGES.results()}};

ACT.rs_rel=async()=>{if(!confirm('Release all approved results to students now?'))return;const r=await call('result_release',{exam_id:+S.f.re});if(r){toast(`${r.released} result(s) released`);PAGES.results()}};

// ---------- invigilator ----------

PAGES.attendance=async()=>{const tt=(await api('timetable')).rows;const eid=S.f.ae||(tt[0]||{}).exam_id;if(!eid){main('<div class="ph"><h2>Attendance & Monitor</h2></div><div class="card pad"><p class="muted">No exams assigned yet.</p></div>');return}S.f.ae=eid;

 const load=async()=>{const r=await api('attendance_list',{exam_id:+eid});D.at=r.rows.map(x=>({...x,id:x.student_id}));const el=$('#attb');if(!el)return;el.innerHTML=dtable([{t:'Student No',v:r=>r.student_no||''},{t:'Student',v:r=>r.full_name},{t:'Present',v:r=>r.present?'Yes':'No',h:r=>`<label><input type="checkbox" style="width:auto" data-act="att" data-id="${r.student_id}" ${r.present?'checked':''}> ${r.present?'Present':'Absent'}</label>`},{t:'Exam status',v:r=>r.astatus||'not started',h:r=>pill(r.astatus||'upcoming').replace('upcoming','not started')},{t:'Progress',v:r=>`${r.answered}/${r.nq||r2.nq}`,h:r=>`${r.answered}/${r2.nq}`},{t:'Tab leaves',v:r=>r.leave_count||0,h:r=>(r.leave_count||0)>=3?`<span class="pill bad">${r.leave_count}</span>`:(r.leave_count||0)},{t:'',h:r=>`<button class="btn ghost xs" data-act="inc_for" data-id="${r.student_id}">Report incident</button>`}],D.at,{name:'attendance',extra:`<a class="btn ghost sm" href="/export/attendance.csv?exam_id=${eid}">⬇ Server export</a>`});r2.nq=r.nq};

 const r2={nq:0};main(`<div class="ph"><h2>Attendance & Live Monitor</h2><p class="muted">Refreshes every 10 seconds. Students who start the exam are marked present automatically.</p></div><div class="row" style="margin-bottom:1rem"><select id="aex" style="max-width:380px">${tt.map(t=>`<option value="${t.exam_id}" ${String(t.exam_id)===String(eid)?'selected':''}>${esc(t.code)} - ${esc(t.title)} (${esc(t.start_time)})</option>`).join('')}</select><button class="btn sm" data-act="inc_for" data-id="">🚨 Report incident</button></div><div id="attb"></div>`);

 $('#aex').onchange=e=>{S.f.ae=e.target.value;PAGES.attendance()};const pre=await api('attendance_list',{exam_id:+eid});r2.nq=pre.nq;await load();S.timer=setInterval(()=>{if(!$('#attb')||document.activeElement?.type==='checkbox')return;load().catch(()=>{})},10000)};

ACT.att=async(id,b)=>{if(await call('attendance_mark',{exam_id:+S.f.ae,student_id:+id,present:b.checked}))PAGES.attendance()};

ACT.inc_for=async id=>{const eid=S.f.ae;const st=(D.at||[]);formModal({title:'Report an incident',fields:[{n:'student_id',l:'Student (optional)',t:'select',o:st.map(s=>[s.student_id,s.full_name]),d:id||''},{n:'description',l:'What happened?',t:'textarea',req:1,w:1,rows:4}],values:{},ok:'Submit report',onSave:async d=>{if(!await call('incident_save',{exam_id:+eid,...d},'Incident reported'))return false}})};

PAGES.incidents=async()=>{const r=await api('incident_list');main(`<div class="ph"><h2>Incident Reports</h2><p class="muted">Irregularities reported by invigilators during examinations.</p></div>`+dtable([{t:'Time',v:r=>r.created_at},{t:'Exam',v:r=>r.code+' '+r.exam},{t:'Student',v:r=>r.student?r.student+' ('+(r.student_no||'')+')':'-'},{t:'Invigilator',v:r=>r.invigilator},{t:'Description',v:r=>r.description}],r.rows,{name:'incidents',extra:S.user.role==='invigilator'?'':'<a class="btn ghost sm" href="/export/incidents.csv">⬇ Server export</a>'}))};

// ---------- announcements / audit / settings ----------

PAGES.announce=async()=>{main(`<div class="ph"><h2>Announcements</h2><p class="muted">Send an in-app notice to everyone or to one group.</p></div><div class="card pad" style="max-width:640px"><form id="anf"><div class="grid2">${fld({n:'audience',l:'Send to',t:'select',req:1,o:[['all','Everyone'],['student','Students'],['lecturer','Lecturers'],['invigilator','Invigilators'],['officer','Examination officers']]})}${fld({n:'title',l:'Title',req:1})}${fld({n:'body',l:'Message',t:'textarea',w:1,rows:4})}</div><div class="row end"><button class="btn">📣 Send</button></div></form></div>`);

 $('#anf').onsubmit=async e=>{e.preventDefault();const d={};new FormData(e.target).forEach((v,k)=>d[k]=v);const r=await call('announce',d);if(r){toast(`Sent to ${r.sent} user(s)`);e.target.reset()}}};

PAGES.audit=async()=>{const r=await api('audit_list');main(`<div class="ph"><h2>Audit Log</h2><p class="muted">Who did what, and when (latest 500 actions).</p></div>`+dtable([{t:'Time',v:r=>r.created_at},{t:'User',v:r=>r.username},{t:'Action',v:r=>r.action,h:r=>`<span class="pill info">${esc(r.action)}</span>`},{t:'Detail',v:r=>r.detail||''},{t:'IP',v:r=>r.ip||''}],r.rows,{name:'audit_log',extra:'<a class="btn ghost sm" href="/export/audit.csv">⬇ Full export</a>'}))};

PAGES.settings=async()=>{const r=await api('settings_get');main(`<div class="ph"><h2>Settings & Backup</h2></div><div class="cols">

 <div class="card pad"><h3>System settings</h3><form id="sf">${fld({n:'college',l:'Institution name',d:r.college,req:1})}<label class="row" style="margin:.8rem 0"><input type="checkbox" name="allow_registration" style="width:auto" ${r.allow_registration?'checked':''}> Allow public self-registration</label><button class="btn">Save settings</button></form></div>

 <div class="card pad"><h3>Backup & data</h3><p class="muted">Automatic daily backups are kept in the <code>eemps_backups</code> folder (${r.backups.count} stored${r.backups.last?', latest: '+esc(r.backups.last):''}).</p><div class="row"><button class="btn ind sm" data-act="bk">💾 Back up now</button><a class="btn ghost sm" href="/export/backup">⬇ Download database</a><a class="btn ghost sm" href="/export/registrations.csv">⬇ Registrations CSV</a></div>

 <hr style="border:0;border-top:1px solid var(--line);margin:1rem 0"><h3>Demo data</h3><p class="muted">Load sample departments, courses, users (password <code>Pass@1234</code>) and a ready-to-write exam so you can try every dashboard. Only works on an empty system.</p><button class="btn amb sm" data-act="demo">Load demo data</button></div>

 <div class="card pad"><h3>Database records</h3>${Object.entries(r.counts).map(([k,v])=>`<div class="list-item" style="cursor:default"><div class="t">${esc(k.replace('_',' '))}</div><b>${v}</b></div>`).join('')}</div></div>`);

 $('#sf').onsubmit=async e=>{e.preventDefault();const f=e.target;if(await call('settings_save',{college:f.elements.college.value,allow_registration:f.elements.allow_registration.checked},'Settings saved')){S.boot=await api('boot')}}};

ACT.bk=async()=>{const r=await call('backup_now',{});if(r){toast('Backup created: '+r.file);PAGES.settings()}};

ACT.demo=async()=>{if(!confirm('Load demo data?'))return;const r=await call('demo_load',{});if(r){alert('Demo data loaded.\n\nAccounts (password '+r.password+'):\nofficer1, lecturer1, lecturer2, invig1, student1, student2, student3');PAGES.settings()}};

// ---------- analysis dashboard ----------

PAGES.analysis=async()=>{const f=S.f.an||{};const a=await api('analytics',f);const k=a.kpi,fl=a.filters;const sel=(n,l,arr,lab)=>`<select data-af="${n}" style="max-width:220px"><option value="">${l}</option>${arr.map(x=>`<option value="${x.id}" ${String(f[n])===String(x.id)?'selected':''}>${esc(lab(x))}</option>`).join('')}</select>`;

 const q=Object.entries(f).filter(([k,v])=>v).map(([k,v])=>k+'='+encodeURIComponent(v)).join('&');

 const kp=[['Students',k.students,'teal'],['Courses',k.courses,'indigo'],['Exams',k.exams,'amber'],['Scripts marked',k.sat,'teal'],['Average %',k.avg,'indigo'],['Pass rate %',k.pass_rate,k.pass_rate>=50?'green':'rose'],['Highest %',k.highest,'green'],['Lowest %',k.lowest,'rose'],['Answers to mark',k.to_mark,'amber'],['Integrity flags',k.flagged,k.flagged?'rose':'green']];

 const cd=(id,t)=>`<div class="card cbox"><div class="chead"><h3>${t}</h3><button class="btn ghost xs" data-act="png" data-id="${id}">⬇ PNG</button></div><canvas id="${id}"></canvas></div>`;

 main(`<div class="ph"><h2>Analysis Dashboard</h2><p class="muted">Performance, participation and integrity indicators. Filter, then export or print.</p></div>

 <div class="card pad" style="margin-bottom:1rem"><div class="row">${sel('session_id','All sessions',fl.sessions,x=>x.name)}${sel('course_id','All courses',fl.courses,x=>x.code+' - '+x.title)}${sel('exam_id','All exams',fl.exams,x=>x.title)}<button class="btn ghost sm" data-act="an_clear">Clear</button><span style="flex:1"></span>

 <a class="btn sm" href="/export/report.csv?${q}">⬇ Full report (CSV)</a><a class="btn ghost sm" href="/export/summary.csv?${q}">⬇ Exam summary</a><a class="btn ghost sm" href="/export/results.csv?${q}">⬇ All results</a><button class="btn ind sm" data-act="an_print">🖨 Print / PDF</button></div></div>

 <div class="stats" id="kp">${kp.map(x=>`<div class="stat ${x[2]}"><div class="n">${esc(x[1])}</div><div class="l">${x[0]}</div></div>`).join('')}</div>

 <div class="cols">${cd('c1','Grade distribution')}${cd('c2','Score distribution (% bands)')}${cd('c3','Pass rate by course (%)')}${cd('c4','Average score by course (%)')}${cd('c5','Exam attempts - last 14 days')}${cd('c6','Exam papers by status')}${S.user.role==='lecturer'?'':cd('c7','Course registrations by programme')}</div>

 <div style="margin-top:1rem">`+dtable([{t:'Exam',v:r=>r.exam},{t:'Course',v:r=>r.code},{t:'Registered',v:r=>r.registered},{t:'Sat',v:r=>r.sat},{t:'Absent',v:r=>r.absent},{t:'Average %',v:r=>r.avg??''},{t:'Highest %',v:r=>r.highest??''},{t:'Lowest %',v:r=>r.lowest??''},{t:'Passed',v:r=>r.passed},{t:'Pass rate %',v:r=>r.pass_rate}],a.summary,{name:'exam_summary'})+'</div>');

 chart($('#c1'),'donut',a.grades.map(x=>x.label),a.grades.map(x=>x.n));chart($('#c2'),'bar',a.hist.map((_,i)=>`${i*10}-${i===9?100:i*10+9}`),a.hist,{c:PAL[1]});

 chart($('#c3'),'bar',a.courses.map(x=>x.label),a.courses.map(x=>x.pass_rate),{max:100,u:'%'});chart($('#c4'),'bar',a.courses.map(x=>x.label),a.courses.map(x=>x.avg),{max:100,u:'%',c:PAL[2]});

 chart($('#c5'),'line',a.trend.map(x=>x.label),a.trend.map(x=>x.n),{c:PAL[0]});chart($('#c6'),'donut',a.exam_status.map(x=>x.label),a.exam_status.map(x=>x.n));if($('#c7'))chart($('#c7'),'bar',a.regs.map(x=>x.label),a.regs.map(x=>x.n),{c:PAL[5]});

 $$('[data-af]').forEach(s=>s.onchange=()=>{S.f.an={...(S.f.an||{}),[s.dataset.af]:s.value};PAGES.analysis()})};

ACT.an_clear=()=>{S.f.an={};PAGES.analysis()};

ACT.png=id=>{const a=document.createElement('a');a.href=$('#'+id).toDataURL('image/png');a.download='eemps_chart.png';a.click()};

ACT.an_print=()=>{const k=$('#kp').innerText.replace(/\n+/g,' | ');const imgs=$$('canvas').map(c=>`<img src="${c.toDataURL('image/png')}">`).join('');const t=Object.keys(T).pop();const cs=T[t].cols.filter(c=>c.v);

 printHTML('Examination Analysis Report',`<p>${esc(k)}</p>${imgs}<table><thead><tr>${cs.map(c=>`<th>${esc(c.t)}</th>`).join('')}</tr></thead><tbody>${T[t].rows.map(r=>`<tr>${cs.map(c=>`<td>${esc(c.v(r))}</td>`).join('')}</tr>`).join('')}</tbody></table>`)};

// ---------- exam taking ----------

let EX=null;

function startExam(p){const key='eemps_att_'+p.attempt_id;let local={};try{local=JSON.parse(localStorage.getItem(key)||'{}')}catch(e){}

 EX={p,key,ans:{...p.saved},dirty:new Set(),i:0,flag:new Set(),end:Date.now()+p.remaining*1000,tok:p.token,done:false,lastLeave:0};

 Object.entries(local).forEach(([q,v])=>{if(v!==EX.ans[q]){EX.ans[q]=v;EX.dirty.add(q)}});$('#exam').style.display='block';document.body.style.overflow='hidden';

 EX.t1=setInterval(tick,1000);EX.t2=setInterval(sync,7000);window.onbeforeunload=()=>'Exam in progress';document.addEventListener('visibilitychange',leave);window.addEventListener('blur',leave);drawExam();tick();sync()}

function leave(){if(!EX||EX.done)return;if(document.hidden||!document.hasFocus()){const n=Date.now();if(n-EX.lastLeave<3000)return;EX.lastLeave=n;api('attempt_event',{attempt_id:EX.p.attempt_id,token:EX.tok}).catch(()=>{});const w=$('#wb');if(w){w.style.display='block';w.textContent='⚠ Leaving the exam page has been recorded and is reported to the invigilator.'}}}

function fmt(s){const h=Math.floor(s/3600),m=Math.floor(s%3600/60),x=s%60;return(h?h+':':'')+String(m).padStart(2,'0')+':'+String(x).padStart(2,'0')}

function tick(){if(!EX||EX.done)return;const s=Math.max(0,Math.round((EX.end-Date.now())/1000));const t=$('#tm');if(t){t.textContent=fmt(s);t.classList.toggle('low',s<300)}if(s<=0)finish(true)}

async function sync(){if(!EX||EX.done||!EX.dirty.size)return;const batch={};EX.dirty.forEach(q=>batch[q]=EX.ans[q]);try{const r=await api('answer_save',{attempt_id:EX.p.attempt_id,token:EX.tok,answers:batch});EX.dirty.forEach(q=>{if(EX.ans[q]===batch[q])EX.dirty.delete(q)});st('Saved ✔ '+new Date().toLocaleTimeString(),1)}catch(e){if(e.status===409){EX.done=true;alert(e.message);closeExam();go('myexams')}else st('Offline - answers kept on this computer, retrying...',0)}}

function st(m,ok){const e=$('#sv');if(e){e.textContent=m;e.style.color=ok?'var(--ok)':'var(--bad)'}}

function setAns(q,v){EX.ans[q]=v;EX.dirty.add(String(q));try{localStorage.setItem(EX.key,JSON.stringify(EX.ans))}catch(e){}st('Unsaved changes...',1);clearTimeout(EX.deb);EX.deb=setTimeout(sync,1500);const n=$$('.qn')[EX.i];if(n)n.classList.toggle('done',!!String(v).trim())}

function drawExam(){const{p}=EX,qs=p.questions,q=qs[EX.i];const a=EX.ans[q.id]??'';

 let body='';if(q.qtype==='mcq')body=q.options.map((o,i)=>o?`<label class="opt ${String(a)===String(i)?'sel':''}"><input type="radio" name="o" value="${i}" ${String(a)===String(i)?'checked':''}><span><b>${'ABCDEF'[i]}.</b> ${esc(o)}</span></label>`:'').join('');

 else if(q.qtype==='tf')body=['True','False'].map(o=>`<label class="opt ${a===o?'sel':''}"><input type="radio" name="o" value="${o}" ${a===o?'checked':''}><span>${o}</span></label>`).join('');

 else if(q.qtype==='fill')body=`<input id="fa" value="${esc(a)}" placeholder="Type your answer" autocomplete="off">`;else body=`<textarea id="fa" rows="12" placeholder="Write your answer here...">${esc(a)}</textarea>`;

 $('#exam').innerHTML=`<div class="eh"><div><b>${esc(p.exam.title)}</b><div class="muted">${esc(p.exam.code)} - ${esc(p.exam.ctitle)}</div></div><span style="flex:1"></span><span id="sv" class="muted"></span><div class="timer" id="tm">--:--</div><button class="btn" data-act="ex_fin">Submit exam</button></div><div class="warnbar" id="wb" style="margin:.8rem 1.4rem 0"></div>

 <div class="eb"><div><div class="muted" style="margin-bottom:.4rem">Questions (${qs.filter(x=>String(EX.ans[x.id]??'').trim()).length}/${qs.length} answered)</div><div class="qnav">${qs.map((x,i)=>`<div class="qn ${String(EX.ans[x.id]??'').trim()?'done':''} ${EX.flag.has(x.id)?'flag':''} ${i===EX.i?'cur':''}" data-act="ex_q" data-id="${i}">${i+1}</div>`).join('')}</div></div>

 <div class="card pad"><div class="row" style="justify-content:space-between"><b>Question ${EX.i+1} of ${qs.length}</b><span class="pill info">${q.marks} mark(s)</span></div><p style="font-size:17px;margin:1rem 0;white-space:pre-wrap">${esc(q.text)}</p>${body}

 <div class="row" style="margin-top:1.2rem"><button class="btn ghost" data-act="ex_prev" ${EX.i?'':'disabled'}>← Previous</button><button class="btn ghost" data-act="ex_flag">${EX.flag.has(q.id)?'Unflag':'🚩 Flag for review'}</button><span style="flex:1"></span><button class="btn" data-act="ex_next" ${EX.i<qs.length-1?'':'disabled'}>Next →</button></div></div></div>`;

 $$('#exam input[name=o]').forEach(i=>i.onchange=()=>{setAns(q.id,i.value);$$('#exam .opt').forEach(o=>o.classList.toggle('sel',o.contains(i)&&i.checked))});const f=$('#fa');if(f)f.oninput=()=>setAns(q.id,f.value);tick()}

ACT.ex_q=i=>{EX.i=+i;drawExam()};ACT.ex_prev=()=>{EX.i--;drawExam()};ACT.ex_next=()=>{EX.i++;drawExam()};ACT.ex_flag=()=>{const id=EX.p.questions[EX.i].id;EX.flag.has(id)?EX.flag.delete(id):EX.flag.add(id);drawExam()};

ACT.ex_fin=()=>finish(false);

async function finish(auto){if(!EX||EX.done||EX.busy)return;const un=EX.p.questions.filter(x=>!String(EX.ans[x.id]??'').trim()).length;

 if(!auto&&!confirm(un?`You have ${un} unanswered question(s). Submit the exam now?`:'Submit your exam now? You cannot change answers afterwards.'))return;EX.busy=true;

 for(let n=0;n<(auto?60:3);n++){try{await api('attempt_submit',{attempt_id:EX.p.attempt_id,token:EX.tok,answers:EX.ans});EX.done=true;break}catch(e){if(e.status===409&&/already/.test(e.message)){EX.done=true;break}if(!auto&&n===2){toast('Could not submit - check your connection and try again','err');EX.busy=false;return}st('Submitting... retrying',0);await new Promise(r=>setTimeout(r,3000))}}

 if(!EX.done){EX.busy=false;return}try{localStorage.removeItem(EX.key)}catch(e){}closeExam();toast(auto?'Time is up - your exam was submitted':'Exam submitted successfully ✔');go('myexams')}

function closeExam(){clearInterval(EX.t1);clearInterval(EX.t2);EX=null;window.onbeforeunload=null;document.removeEventListener('visibilitychange',leave);window.removeEventListener('blur',leave);$('#exam').style.display='none';$('#exam').innerHTML='';document.body.style.overflow=''}

boot();

</script></body></html>

'''



if __name__ == '__main__':

    main()
